import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { corsHeaders } from "./cors.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import Stripe from "https://esm.sh/stripe@14.10.0?target=deno";

// This is how Deno accesses environment variables
const STRIPE_SECRET_KEY = Deno.env.get("STRIPE_SECRET_KEY");
const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY");
const SITE_URL = Deno.env.get("SITE_URL") || 'http://localhost:5173';


const stripe = Stripe(STRIPE_SECRET_KEY, {
  httpClient: Stripe.createFetchHttpClient(),
  apiVersion: "2023-10-16",
});

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  const supabase = createClient(
    SUPABASE_URL,
    SUPABASE_ANON_KEY,
    { global: { headers: { Authorization: req.headers.get("Authorization") } } }
  );

  try {
    const { 
      userId, 
      userEmail, 
      lineItemsPayload, 
      checkoutMode, 
      metadata = {} 
    } = await req.json();

    if (!userId || !userEmail || !lineItemsPayload || !checkoutMode) {
      return new Response(JSON.stringify({ error: "Missing required parameters (userId, userEmail, lineItemsPayload, checkoutMode)." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    
    if (!Array.isArray(lineItemsPayload) || lineItemsPayload.length === 0) {
        return new Response(JSON.stringify({ error: "lineItemsPayload must be a non-empty array." }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
    }

    let stripeCustomerId = null;
    const { data: userProfile, error: profileError } = await supabase
      .from("user_profiles")
      .select("stripe_customer_id")
      .eq("user_id", userId)
      .single();

    if (profileError && profileError.code !== 'PGRST116') { 
      console.error("Error fetching user profile:", profileError);
      throw profileError;
    }

    if (userProfile && userProfile.stripe_customer_id) {
      stripeCustomerId = userProfile.stripe_customer_id;
    } else {
      const customer = await stripe.customers.create({
        email: userEmail,
        metadata: { user_id: userId },
      });
      stripeCustomerId = customer.id;
      const { error: updateError } = await supabase
        .from("user_profiles")
        .update({ stripe_customer_id: stripeCustomerId })
        .eq("user_id", userId);
      if (updateError) {
        console.error("Error updating user profile with Stripe customer ID:", updateError);
      }
    }

    const line_items = [];
    let mode = 'payment'; 
    
    for (const item of lineItemsPayload) {
        if (checkoutMode === 'agents_only' || (checkoutMode === 'mixed' && item.agent_product_id)) {
            if (!item.agent_product_id || !item.quantity) {
                 return new Response(JSON.stringify({ error: `Agent item must include 'agent_product_id' and 'quantity'. Received: ${JSON.stringify(item)}` }), {
                    status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
                });
            }
            const { data: agentProduct, error: productError } = await supabase
                .from('ai_agents_list')
                .select('agent_name, price_one_time, stripe_price_id')
                .eq('id', item.agent_product_id)
                .single();

            if (productError || !agentProduct) {
                 return new Response(JSON.stringify({ error: `Agent product not found or error fetching: ${item.agent_product_id}` }), {
                    status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
                });
            }
            
            if (agentProduct.stripe_price_id) {
                 line_items.push({ price: agentProduct.stripe_price_id, quantity: item.quantity });
            } else {
                 line_items.push({
                    price_data: {
                        currency: 'usd',
                        product_data: { name: agentProduct.agent_name },
                        unit_amount: Math.round(agentProduct.price_one_time * 100), 
                    },
                    quantity: item.quantity,
                });
            }
        } else if (checkoutMode === 'subscription_only' || (checkoutMode === 'mixed' && item.tier_name)) {
            mode = 'subscription';
            if (!item.tier_name || !item.quantity) {
                return new Response(JSON.stringify({ error: `Subscription item must include 'tier_name' and have a quantity. Received: ${JSON.stringify(item)}` }), {
                   status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
               });
            }
            const { data: tier, error: tierError } = await supabase
                .from('subscription_tiers')
                .select('price_id, tier_name')
                .eq('tier_name', item.tier_name)
                .single();

            if (tierError || !tier || !tier.price_id) {
                 return new Response(JSON.stringify({ error: `Subscription tier '${item.tier_name}' not found, error fetching, or missing Stripe Price ID.` }), {
                    status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
                });
            }
            line_items.push({ price: tier.price_id, quantity: item.quantity });
        } else {
            return new Response(JSON.stringify({ error: `Invalid item in payload for checkoutMode '${checkoutMode}'. Item: ${JSON.stringify(item)}` }), {
                status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
            });
        }
    }


    if (line_items.length === 0) {
        return new Response(JSON.stringify({ error: "No valid line items could be processed for checkout." }), {
           status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
       });
    }

    const sessionPayload = {
      customer: stripeCustomerId,
      payment_method_types: ["card"],
      line_items,
      mode,
      success_url: `${SITE_URL}/billing?tier_upgrade_success=true&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${SITE_URL}/billing?tier_upgrade_cancel=true`,
      metadata: metadata.session_metadata || {}, 
    };

    if (mode === 'subscription') {
      sessionPayload.subscription_data = {
        metadata: metadata.subscription_metadata || {}, 
      };
    } else { 
      sessionPayload.payment_intent_data = {
         metadata: metadata.payment_intent_metadata || {}, 
      };
    }
    
    if (mode === 'subscription' && metadata.subscription_metadata?.trial_period_days) {
      sessionPayload.subscription_data.trial_period_days = parseInt(metadata.subscription_metadata.trial_period_days, 10);
    }

    const session = await stripe.checkout.sessions.create(sessionPayload);

    return new Response(JSON.stringify({ sessionId: session.id }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("Error in create-stripe-checkout-session:", error);
    const errorMessage = error.message || "An unexpected error occurred.";
    return new Response(JSON.stringify({ error: errorMessage, type: error.type }), {
      status: error.statusCode || 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});