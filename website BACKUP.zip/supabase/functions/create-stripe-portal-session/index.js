import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { corsHeaders } from "./cors.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import Stripe from "https://esm.sh/stripe@14.10.0?target=deno";

// This is how Deno accesses environment variables
const STRIPE_SECRET_KEY = Deno.env.get("STRIPE_SECRET_KEY");
const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY");
const SITE_URL = Deno.env.get("SITE_URL") || 'http://localhost:5173';


const stripe = Stripe(STRIPE_SECRET_KEY, {
  httpClient: Stripe.createFetchHttpClient(),
  apiVersion: "2023-10-16",
});

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { return_url } = await req.json();

    const supabase = createClient(
      SUPABASE_URL,
      SUPABASE_ANON_KEY,
      { global: { headers: { Authorization: req.headers.get("Authorization") } } }
    );

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "User not authenticated." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: profile, error: profileError } = await supabase
      .from("user_profiles")
      .select("stripe_customer_id")
      .eq("user_id", user.id)
      .single();

    if (profileError && profileError.code !== 'PGRST116') {
      console.error("Error fetching user profile:", profileError);
      return new Response(JSON.stringify({ error: "Error fetching user profile." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    
    if (!profile || !profile.stripe_customer_id) {
      return new Response(JSON.stringify({ error: "Stripe customer ID not found for this user. Please complete a purchase to activate billing portal." }), {
        status: 404, 
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    
    const stripeCustomerId = profile.stripe_customer_id;

    const portalSession = await stripe.billingPortal.sessions.create({
      customer: stripeCustomerId,
      return_url: return_url || `${SITE_URL}/billing`,
    });

    return new Response(JSON.stringify({ portalUrl: portalSession.url }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("Error creating Stripe portal session:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: error.statusCode || 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});