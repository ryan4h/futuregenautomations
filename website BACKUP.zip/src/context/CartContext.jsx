import React, { createContext, useState, useEffect, useContext } from 'react';
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/lib/supabaseClient"; 

const CartContext = createContext();

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const savedCart = localStorage.getItem('fga_cart');
    if (savedCart) {
      try {
        const parsedCart = JSON.parse(savedCart);
        if (Array.isArray(parsedCart)) {
          setCartItems(parsedCart);
        }
      } catch (error) {
        console.error("Failed to parse cart from localStorage:", error);
        localStorage.removeItem('fga_cart');
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('fga_cart', JSON.stringify(cartItems));
  }, [cartItems]);

  const addToCart = (product) => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => item.id === product.id);
      if (existingItem) {
        toast({
          title: `${product.agent_name || product.name} is already in your cart.`,
          variant: "default"
        });
        return prevItems;
      }
      
      if (!product.stripe_price_id) {
        toast({
          title: "Cannot Add to Cart",
          description: `${product.agent_name || product.name} is missing a Stripe Price ID and cannot be purchased.`,
          variant: "destructive"
        });
        return prevItems;
      }

      return [...prevItems, { 
        id: product.id, 
        agent_name: product.agent_name || product.name, 
        description: product.description,
        price_one_time: product.price_one_time, 
        category: product.category, 
        icon_name: product.icon_name || product.iconName,
        stripe_price_id: product.stripe_price_id, 
      }];
    });
    toast({
      title: `${product.agent_name || product.name} added to cart!`,
      description: "You can view your cart or continue shopping.",
    });
  };


  const removeFromCart = (productId) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== productId));
    toast({
      title: "Item Removed",
      description: "The item has been removed from your cart.",
    });
  };

  const clearCart = () => {
    setCartItems([]);
    localStorage.removeItem('fga_cart');
    toast({
      title: "Cart Cleared",
      description: "All items have been removed from your cart.",
    });
  };

  const legacyCheckout = async (userId) => {
    if (!supabase) {
      toast({ title: "Database Error", description: "Cannot connect to the database.", variant: "destructive" });
      return false;
    }
    if (!userId) {
      toast({ title: "Authentication Required", description: "Please log in.", variant: "destructive" });
      return false;
    }
    if (cartItems.length === 0) {
      toast({ title: "Empty Cart", description: "Your cart is empty.", variant: "destructive" });
      return false;
    }

    setLoading(true);
    let allSuccessful = true;

    for (const item of cartItems) {
      try {
        if (!item.agent_name || !item.category) {
            throw new Error(`Agent name or category is missing for item ID ${item.id}.`);
        }

        const { data: existingAssignment, error: checkError } = await supabase
          .from('user_assigned_agents')
          .select('assigned_agent_id')
          .eq('user_id', userId)
          .eq('agent_product_id', item.id)
          .maybeSingle();

        if (checkError) throw checkError;

        if (existingAssignment) {
          toast({ title: "Agent Already Owned", description: `${item.agent_name} is already in your collection. Skipping.`, variant: "default" });
          continue; 
        }

        const { error: assignError } = await supabase
          .from("user_assigned_agents")
          .insert({
            user_id: userId,
            agent_product_id: item.id,
            agent_name: item.agent_name, 
            status: "active", 
            one_time_purchase_price: item.price_one_time,
            purchased_at: new Date().toISOString(),
            activated_at: new Date().toISOString(),
            category: item.category,
          });

        if (assignError) throw assignError;
        
        const { error: transactionError } = await supabase
          .from("user_transactions")
          .insert({
            user_id: userId,
            transaction_type: "agent_purchase_direct_db", 
            related_agent_product_id: item.id,
            amount: item.price_one_time,
            currency: "USD",
            transaction_status: "succeeded", 
            description: `Direct DB: Purchased ${item.agent_name}`,
            mrr_impact: 0,
          });
        
        if (transactionError) {
          console.warn(`Transaction logging failed for ${item.agent_name}: ${transactionError.message}`);
        }

      } catch (error) {
        allSuccessful = false;
        toast({
          title: `Error Processing ${item.agent_name || `Item ID ${item.id}`}`,
          description: error.message,
          variant: "destructive",
        });
      }
    }

    setLoading(false);
    if (allSuccessful) {
      toast({ title: "Checkout Successful (Direct DB)!", description: "Agents processed." });
      clearCart(); 
      return true;
    } else {
      toast({ title: "Partial Checkout (Direct DB)", description: "Some items could not be processed.", variant: "warning" });
      return false;
    }
  };

  const cartTotal = cartItems.reduce((sum, item) => sum + (item.price_one_time || 0), 0);
  const itemCount = cartItems.length;

  return (
    <CartContext.Provider value={{ cartItems, addToCart, removeFromCart, clearCart, checkout: legacyCheckout, loading, cartTotal, itemCount }}>
      {children}
    </CartContext.Provider>
  );
};