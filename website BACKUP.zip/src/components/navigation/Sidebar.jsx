import React, { useState, useEffect } from "react";
import { NavLink, useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { 
  LayoutDashboard, CheckSquare, Bot, BarChart3, Zap, FileText, MessageSquare, ShoppingBag, ShoppingCart, User, LogOut
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/lib/supabaseClient";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useCart } from "@/context/CartContext";

const baseNavItems = [
  { name: "Dashboard", icon: LayoutDashboard, path: "/dashboard" },
  { name: "Tasks", icon: CheckSquare, path: "/tasks" },
  { name: "My Agents", icon: Bot, path: "/agents" },
  { name: "Ad Campaigns", icon: BarChart3, path: "/ad-campaigns" },
  { name: "Integrations", icon: Zap, path: "/integrations" },
  { name: "Reports & Analytics", icon: FileText, path: "/reports-analytics" },
  { name: "Browse Automations", icon: ShoppingBag, path: "/products" },
  { name: "Contact", icon: MessageSquare, path: "/contact" },
];

const Sidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const { itemCount } = useCart();
  const [userProfile, setUserProfile] = useState(null);
  const [authUser, setAuthUser] = useState(null);
  const logoImageUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/6cdb6db2-4a4b-4b53-a9b9-880b70d4c6e8/54bb1584c4452161177f754bb28f3988.png";

  const browseAutomationsIndex = baseNavItems.findIndex(item => item.name === "Browse Automations");
  const navItems = [
    ...baseNavItems.slice(0, browseAutomationsIndex + 1),
    { name: "Cart", icon: ShoppingCart, path: "/cart" },
    ...baseNavItems.slice(browseAutomationsIndex + 1)
  ];


  useEffect(() => {
    const fetchUserProfile = async (userId) => {
      if (!supabase) return;
      const { data, error } = await supabase
        .from("user_profiles")
        .select("avatar_url, full_name")
        .eq("user_id", userId)
        .maybeSingle();
      if (error) {
        console.error("Error fetching user profile for sidebar:", error);
      } else {
        setUserProfile(data);
      }
    };
    
    const getSession = async () => {
      if (!supabase) return;
      const { data: { session } } = await supabase.auth.getSession();
      setAuthUser(session?.user || null);
      if (session?.user) {
        fetchUserProfile(session.user.id);
      }
    };
    getSession();

    if (!supabase) return;
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      setAuthUser(session?.user || null);
      if (session?.user) {
        fetchUserProfile(session.user.id);
      } else {
        setUserProfile(null);
      }
    });

    return () => {
      authListener?.subscription.unsubscribe();
    };
  }, []);


  const handleLogout = async () => {
    if (!supabase) {
      toast({
        title: "Logout Failed",
        description: "Supabase client not available.",
        variant: "destructive",
      });
      return;
    }
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast({
        title: "Logout Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Logged Out",
        description: "You have been successfully logged out.",
      });
      setUserProfile(null); 
      navigate("/login");
    }
  };

  const getInitials = (name) => {
    if (!name) return "?";
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const handleLogoClick = (e) => {
    e.preventDefault();
    navigate("/dashboard");
  };

  return (
    <motion.div
      initial={{ x: -256 }}
      animate={{ x: 0 }}
      transition={{ type: "spring", stiffness: 120, damping: 20 }}
      className="fixed left-0 top-0 h-full w-64 bg-black text-foreground border-r-2 border-white flex flex-col shadow-lg z-50 md:translate-x-0"
    >
      <a href="/dashboard" onClick={handleLogoClick} className="p-4 flex items-center gap-3 border-b-2 border-white h-16 cursor-pointer hover:bg-white/5 transition-colors">
        <img src={logoImageUrl} alt="Future Gen Automations Logo" className="h-9 w-9 object-contain rounded flex-shrink-0" />
        <span className="font-normal text-sm text-foreground whitespace-nowrap overflow-hidden text-ellipsis">Future Gen Automations</span>
      </a>

      <nav className="flex-grow p-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              `nav-link-underline flex items-center px-3 py-2.5 rounded-md text-sm font-medium transition-colors group relative
               ${isActive
                 ? "text-primary font-semibold" // Active state: primary color text, underline applied by CSS
                 : "text-muted-foreground hover:text-foreground"}` // Default: muted, hover to foreground
            }
          >
            {({ isActive }) => ( 
              <>
                <item.icon className={
                  `mr-3 h-5 w-5 flex-shrink-0 ${isActive ? 'text-primary' : 'text-muted-foreground group-hover:text-foreground'}`
                } />
                {item.name}
                {item.name === "Cart" && itemCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-xs font-bold text-destructive-foreground text-[10px] p-0.5">
                    {itemCount > 9 ? '9+' : itemCount}
                  </span>
                )}
                 {isActive && <motion.div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" layoutId="underline" />}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      <Separator className="my-2 bg-white/20" />

      <div className="p-4 space-y-2">
        <NavLink
          to="/profile"
          className={({ isActive }) =>
            `nav-link-underline flex items-center px-3 py-2.5 rounded-md text-sm font-medium transition-colors group relative
             ${isActive
               ? "text-primary font-semibold"
               : "text-muted-foreground hover:text-foreground"}`
          }
        >
           {({ isActive }) => (
            <>
              <Avatar className="h-6 w-6 mr-3 border-2 border-transparent group-hover:border-primary transition-colors">
                <AvatarImage src={userProfile?.avatar_url} alt={userProfile?.full_name || authUser?.email} />
                <AvatarFallback className="text-xs bg-muted text-muted-foreground">
                  {userProfile?.full_name ? getInitials(userProfile.full_name) : (authUser?.email ? authUser.email[0].toUpperCase() : <User className="h-4 w-4"/>)}
                </AvatarFallback>
              </Avatar>
              Profile
              {isActive && <motion.div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" layoutId="underline-profile" />}
            </>
           )}
        </NavLink>
        <Button
          variant="ghost"
          className="w-full justify-start px-3 py-2.5 text-sm font-medium text-muted-foreground hover:text-foreground group border-none"
          onClick={handleLogout}
        >
          <LogOut className="mr-3 h-5 w-5 text-muted-foreground group-hover:text-foreground" />
          Logout
        </Button>
      </div>
    </motion.div>
  );
};

export default Sidebar;