import React, { useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import Sidebar from "@/components/navigation/Sidebar";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const MainLayout = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const location = useLocation();

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="flex h-screen bg-background text-foreground">
      {/* Sidebar for larger screens */}
      <div className="hidden md:block">
        <Sidebar />
      </div>

      {/* Mobile Sidebar */}
      {isSidebarOpen && (
        <div className="md:hidden fixed inset-0 z-50">
          <div 
            className="absolute inset-0 bg-black/50 backdrop-blur-sm" 
            onClick={toggleSidebar}
          ></div>
          <Sidebar />
        </div>
      )}
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile Header */}
        <header className="md:hidden bg-card text-card-foreground border-b border-border p-4 flex items-center justify-between sticky top-0 z-40">
          <span className="font-semibold">Future Gen Automations</span>
          <Button variant="ghost" size="icon" onClick={toggleSidebar} className="text-foreground">
            {isSidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </header>

        <main className="flex-1 overflow-x-hidden overflow-y-auto md:ml-64 bg-background">
           <div className="md:container md:mx-auto md:px-0 px-0"> {/* Adjust padding for mobile vs desktop */}
             <Outlet />
           </div>
        </main>
      </div>
    </div>
  );
};

export default MainLayout;