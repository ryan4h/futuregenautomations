import React from "react";
import { Outlet } from "react-router-dom";

const LandingLayout = () => {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <main className="flex-grow">
        <Outlet />
      </main>
    </div>
  );
};

export default LandingLayout;