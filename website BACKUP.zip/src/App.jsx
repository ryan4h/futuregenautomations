import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, useLocation, Navigate } from "react-router-dom";
import { Toaster } from "@/components/ui/toaster";
import { motion } from "framer-motion";
import { supabase } from "@/lib/supabaseClient";
import { CartProvider } from "@/context/CartContext"; 

// Layouts
import MainLayout from "@/layouts/MainLayout";
import AuthLayout from "@/layouts/AuthLayout";
import LandingLayout from "@/layouts/LandingLayout";

// Pages
import HomePage from "@/pages/HomePage";
import DashboardPage from "@/pages/DashboardPage";
import TasksPage from "@/pages/TasksPage";
import AgentsPage from "@/pages/AgentsPage";
import AdCampaignsPage from "@/pages/AdCampaignsPage";
import IntegrationsPage from "@/pages/IntegrationsPage";
import ReportsAnalyticsPage from "@/pages/ReportsAnalyticsPage";
import ContactPage from "@/pages/ContactPage";
import ProfilePage from "@/pages/ProfilePage";
import ProductsPage from "@/pages/ProductsPage";
import ProductDetailPage from "@/pages/ProductDetailPage";
import CartPage from "@/pages/CartPage";
import LoginPage from "@/pages/LoginPage";
import SignUpPage from "@/pages/SignUpPage";
import NotFoundPage from "@/pages/NotFoundPage";
import BillingPage from "@/pages/BillingPage"; // New Billing Page

const ProtectedRoute = ({ children }) => {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!supabase) {
      setLoading(false);
      return;
    }
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setSession(session);
      setLoading(false);
    };

    getSession();

    const { data: authListener } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        setSession(session);
        setLoading(false); 
      }
    );

    return () => {
      authListener?.subscription.unsubscribe();
    };
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background text-foreground">
        Authenticating...
      </div>
    );
  }
  
  if (!supabase) {
     return <Navigate to="/login?error=supabase_disconnected" replace />;
  }

  if (!session) {
    return <Navigate to="/login" replace />;
  }
  return children;
};


function App() {
  return (
    <Router>
      <CartProvider> 
        <AppContent />
      </CartProvider>
    </Router>
  );
}

function AppContent() {
  const location = useLocation();
  const [session, setSession] = useState(null);
  const [loadingAuth, setLoadingAuth] = useState(true);


  useEffect(() => {
    if (!supabase) {
      setLoadingAuth(false);
      return;
    }
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setSession(session);
      setLoadingAuth(false);
    };
    getSession();

    const { data: authListener } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        setSession(session);
        setLoadingAuth(false);
      }
    );
    return () => {
      authListener?.subscription.unsubscribe();
    };
  }, []);


  const isAuthPage = location.pathname === "/login" || location.pathname === "/signup";
  const isLandingPage = location.pathname === "/";

  let LayoutComponent;
  if (isLandingPage) {
    LayoutComponent = LandingLayout;
  } else if (isAuthPage) {
    LayoutComponent = AuthLayout;
  } else {
    LayoutComponent = MainLayout;
  }
  
  if (loadingAuth && supabase) { 
     return (
      <div className="flex items-center justify-center h-screen bg-background text-foreground">
        Initializing Application...
      </div>
    );
  }

  return (
    <motion.div
      key={location.pathname}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="bg-background text-foreground min-h-screen"
    >
      <Routes>
        <Route element={<LayoutComponent />}>
          <Route index element={<HomePage />} />
          <Route path="login" element={<LoginPage />} />
          <Route path="signup" element={<SignUpPage />} />
          
          <Route path="dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
          <Route path="tasks" element={<ProtectedRoute><TasksPage /></ProtectedRoute>} />
          <Route path="agents" element={<ProtectedRoute><AgentsPage /></ProtectedRoute>} />
          <Route path="ad-campaigns" element={<ProtectedRoute><AdCampaignsPage /></ProtectedRoute>} />
          <Route path="integrations" element={<ProtectedRoute><IntegrationsPage /></ProtectedRoute>} />
          <Route path="reports-analytics" element={<ProtectedRoute><ReportsAnalyticsPage /></ProtectedRoute>} />
          <Route path="contact" element={<ProtectedRoute><ContactPage /></ProtectedRoute>} />
          <Route path="profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
          <Route path="billing" element={<ProtectedRoute><BillingPage /></ProtectedRoute>} /> 
          <Route path="products" element={<ProtectedRoute><ProductsPage /></ProtectedRoute>} />
          <Route path="products/:id" element={<ProtectedRoute><ProductDetailPage /></ProtectedRoute>} />
          <Route path="cart" element={<ProtectedRoute><CartPage /></ProtectedRoute>} />
          
          <Route path="*" element={<NotFoundPage />} />
        </Route>
      </Routes>
      <Toaster />
    </motion.div>
  );
}

export default App;