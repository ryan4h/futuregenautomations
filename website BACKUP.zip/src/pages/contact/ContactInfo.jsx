import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Mail, Phone, MapPin, Clock, ExternalLink, Instagram } from "lucide-react";
import { Button } from "@/components/ui/button";

const InfoItem = ({ icon, title, children }) => (
  <div className="flex items-start">
    <div className="rounded-full bg-primary/10 p-3 mr-4 text-primary">
      {icon}
    </div>
    <div>
      <h3 className="font-semibold text-card-foreground">{title}</h3>
      {children}
    </div>
  </div>
);

const ContactInfo = ({ details }) => {
  return (
    <Card className="h-full bg-card border-border shadow-xl">
      <CardHeader className="border-b border-border">
        <CardTitle className="text-2xl text-card-foreground">Contact Details</CardTitle>
        <CardDescription className="text-muted-foreground">
          Reach out to us through any of these channels.
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <InfoItem icon={<Mail className="h-5 w-5" />} title="Email">
          <a href={`mailto:${details.email}`} className="text-sm text-primary hover:underline">
            {details.email}
          </a>
        </InfoItem>
        <InfoItem icon={<Phone className="h-5 w-5" />} title="Phone">
          <p className="text-sm text-muted-foreground">{details.phone}</p>
          {details.phoneDesc && <p className="text-xs text-muted-foreground">{details.phoneDesc}</p>}
        </InfoItem>
        <InfoItem icon={<MapPin className="h-5 w-5" />} title="Location">
          <p className="text-sm text-muted-foreground">{details.location}</p>
        </InfoItem>
        <InfoItem icon={<Clock className="h-5 w-5" />} title="Business Hours">
          {details.businessHours.map((line, index) => (
            <p key={index} className="text-sm text-muted-foreground">{line}</p>
          ))}
        </InfoItem>
      </CardContent>
      {details.socialMedia && details.socialMedia.length > 0 && (
        <CardFooter className="border-t border-border p-6">
          <div className="flex space-x-4">
            {details.socialMedia.map((social) => (
              <Button
                key={social.name}
                variant="outline"
                size="icon"
                className="btn-minimal rounded-full hover:bg-accent"
                asChild
              >
                <a href={social.url} target="_blank" rel="noopener noreferrer" aria-label={social.name}>
                  {social.icon}
                </a>
              </Button>
            ))}
          </div>
        </CardFooter>
      )}
    </Card>
  );
};

export default ContactInfo;