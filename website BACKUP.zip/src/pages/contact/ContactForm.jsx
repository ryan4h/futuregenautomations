import React, { useState, useEffect } from "react";
import { Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";

const ContactForm = ({ onSubmit, isSubmitting, initialData = {} }) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  useEffect(() => {
    setFormData(prev => ({
      ...prev,
      name: initialData.name || "",
      email: initialData.email || "",
      subject: initialData.subject || "",
      message: initialData.message || ""
    }));
  }, [initialData]);


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Missing Fields",
        description: "Please fill in your name, email, and message.",
        variant: "destructive",
      });
      return;
    }
    const result = await onSubmit(formData);
    if (result?.success) {
      // Clear form only if submission was successful and not prefilled for a specific purpose
      if (!initialData.subject) { 
          setFormData({ name: "", email: "", subject: "", message: "" });
      }
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2">
        <div>
          <Label htmlFor="name" className="text-card-foreground">Full Name</Label>
          <Input
            id="name"
            name="name"
            placeholder="e.g., Jane Doe"
            value={formData.name}
            onChange={handleChange}
            required
            className="mt-1 bg-input border-border text-foreground placeholder:text-muted-foreground"
          />
        </div>
        <div>
          <Label htmlFor="email" className="text-card-foreground">Email Address</Label>
          <Input
            id="email"
            name="email"
            type="email"
            placeholder="e.g., jane.doe@example.com"
            value={formData.email}
            onChange={handleChange}
            required
            className="mt-1 bg-input border-border text-foreground placeholder:text-muted-foreground"
          />
        </div>
      </div>
      <div>
        <Label htmlFor="subject" className="text-card-foreground">Subject</Label>
        <Input
          id="subject"
          name="subject"
          placeholder="What is this regarding?"
          value={formData.subject}
          onChange={handleChange}
          className="mt-1 bg-input border-border text-foreground placeholder:text-muted-foreground"
        />
      </div>
      <div>
        <Label htmlFor="message" className="text-card-foreground">Message</Label>
        <Textarea
          id="message"
          name="message"
          placeholder="How can we help you today?"
          rows={6}
          value={formData.message}
          onChange={handleChange}
          required
          className="mt-1 bg-input border-border text-foreground placeholder:text-muted-foreground"
        />
      </div>
      <Button 
        type="submit" 
        className="w-full btn-minimal text-lg py-3" 
        disabled={isSubmitting}
      >
        {isSubmitting ? (
          <>
            <span className="animate-spin mr-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4"
              >
                <path d="M21 12a9 9 0 1 1-6.219-8.56" />
              </svg>
            </span>
            Sending...
          </>
        ) : (
          <>
            <Send className="h-5 w-5 mr-2" />
            Send Message
          </>
        )}
      </Button>
    </form>
  );
};

export default ContactForm;