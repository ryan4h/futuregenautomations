import React, { useState } from "react";
import { motion } from "framer-motion";
import { 
  Plus, Search, Filter, MoreHorizontal, 
  Edit, Trash2, Play, Pause, Copy, 
  ChevronDown, ArrowUpDown, Download
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";

const CampaignsPage = () => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPlatform, setSelectedPlatform] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");

  // Mock campaign data
  const allCampaigns = [
    {
      id: 1,
      name: "Summer Sale Promotion",
      platform: "Google Ads",
      status: "Active",
      budget: "$2,500.00",
      spent: "$1,243.45",
      impressions: "45,678",
      clicks: "2,345",
      conversions: 128,
      ctr: "5.13%",
      cpc: "$0.53",
      cpa: "$9.71",
      lastUpdated: "2 hours ago",
    },
    {
      id: 2,
      name: "New Product Launch",
      platform: "Meta Ads",
      status: "Active",
      budget: "$3,000.00",
      spent: "$2,854.12",
      impressions: "78,912",
      clicks: "4,567",
      conversions: 215,
      ctr: "5.79%",
      cpc: "$0.63",
      cpa: "$13.27",
      lastUpdated: "5 hours ago",
    },
    {
      id: 3,
      name: "Retargeting Campaign",
      platform: "Google Ads",
      status: "Paused",
      budget: "$1,500.00",
      spent: "$876.33",
      impressions: "23,456",
      clicks: "1,234",
      conversions: 94,
      ctr: "5.26%",
      cpc: "$0.71",
      cpa: "$9.32",
      lastUpdated: "1 day ago",
    },
    {
      id: 4,
      name: "Brand Awareness",
      platform: "Meta Ads",
      status: "Active",
      budget: "$2,000.00",
      spent: "$1,654.87",
      impressions: "123,456",
      clicks: "3,456",
      conversions: 0,
      ctr: "2.80%",
      cpc: "$0.48",
      cpa: "$0.00",
      lastUpdated: "12 hours ago",
    },
    {
      id: 5,
      name: "Holiday Special",
      platform: "Google Ads",
      status: "Draft",
      budget: "$4,000.00",
      spent: "$0.00",
      impressions: "0",
      clicks: "0",
      conversions: 0,
      ctr: "0.00%",
      cpc: "$0.00",
      cpa: "$0.00",
      lastUpdated: "3 days ago",
    },
    {
      id: 6,
      name: "Competitor Keywords",
      platform: "Google Ads",
      status: "Active",
      budget: "$1,800.00",
      spent: "$954.23",
      impressions: "15,678",
      clicks: "789",
      conversions: 45,
      ctr: "5.03%",
      cpc: "$1.21",
      cpa: "$21.20",
      lastUpdated: "1 day ago",
    },
    {
      id: 7,
      name: "Video Testimonials",
      platform: "Meta Ads",
      status: "Paused",
      budget: "$2,200.00",
      spent: "$1,432.67",
      impressions: "56,789",
      clicks: "2,345",
      conversions: 87,
      ctr: "4.13%",
      cpc: "$0.61",
      cpa: "$16.47",
      lastUpdated: "2 days ago",
    },
  ];

  // Filter campaigns based on search query, platform, and status
  const filteredCampaigns = allCampaigns.filter((campaign) => {
    const matchesSearch = campaign.name
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesPlatform =
      selectedPlatform === "all" || campaign.platform === selectedPlatform;
    const matchesStatus =
      selectedStatus === "all" || campaign.status === selectedStatus;
    return matchesSearch && matchesPlatform && matchesStatus;
  });

  const handleCreateCampaign = () => {
    toast({
      title: "Create Campaign",
      description: "Campaign creation functionality would be implemented here.",
    });
  };

  const handleCampaignAction = (action, campaign) => {
    toast({
      title: `${action} Campaign`,
      description: `${action} action for "${campaign.name}" would be implemented here.`,
    });
  };

  return (
    <div className="container py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Campaigns</h1>
          <p className="text-muted-foreground">
            Manage and optimize your advertising campaigns.
          </p>
        </div>
        <Button onClick={handleCreateCampaign}>
          <Plus className="h-4 w-4 mr-2" />
          Create Campaign
        </Button>
      </div>

      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search campaigns..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <div className="relative">
                <select
                  className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 appearance-none pr-8"
                  value={selectedPlatform}
                  onChange={(e) => setSelectedPlatform(e.target.value)}
                >
                  <option value="all">All Platforms</option>
                  <option value="Google Ads">Google Ads</option>
                  <option value="Meta Ads">Meta Ads</option>
                </select>
                <ChevronDown className="absolute right-3 top-3 h-4 w-4 text-muted-foreground pointer-events-none" />
              </div>
              <div className="relative">
                <select
                  className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 appearance-none pr-8"
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                >
                  <option value="all">All Statuses</option>
                  <option value="Active">Active</option>
                  <option value="Paused">Paused</option>
                  <option value="Draft">Draft</option>
                </select>
                <ChevronDown className="absolute right-3 top-3 h-4 w-4 text-muted-foreground pointer-events-none" />
              </div>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Download className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList>
          <TabsTrigger value="all">All Campaigns</TabsTrigger>
          <TabsTrigger value="google">Google Ads</TabsTrigger>
          <TabsTrigger value="meta">Meta Ads</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-6">
          <Card>
            <CardContent className="p-0">
              <div className="rounded-md">
                <div className="grid grid-cols-7 gap-4 p-4 font-medium border-b">
                  <div className="flex items-center">
                    Campaign Name
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </div>
                  <div>Platform</div>
                  <div>Status</div>
                  <div>Budget</div>
                  <div>Spent</div>
                  <div>Conversions</div>
                  <div>Actions</div>
                </div>
                <div className="divide-y">
                  {filteredCampaigns.length > 0 ? (
                    filteredCampaigns.map((campaign) => (
                      <motion.div
                        key={campaign.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="grid grid-cols-7 gap-4 p-4 items-center"
                      >
                        <div className="font-medium">{campaign.name}</div>
                        <div>{campaign.platform}</div>
                        <div>
                          <Badge
                            variant={
                              campaign.status === "Active"
                                ? "success"
                                : campaign.status === "Paused"
                                ? "secondary"
                                : "outline"
                            }
                          >
                            {campaign.status}
                          </Badge>
                        </div>
                        <div>{campaign.budget}</div>
                        <div>{campaign.spent}</div>
                        <div>{campaign.conversions}</div>
                        <div className="flex items-center gap-2">
                          {campaign.status === "Active" ? (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleCampaignAction("Pause", campaign)}
                            >
                              <Pause className="h-4 w-4" />
                            </Button>
                          ) : (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleCampaignAction("Activate", campaign)}
                            >
                              <Play className="h-4 w-4" />
                            </Button>
                          )}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleCampaignAction("Edit", campaign)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleCampaignAction("Duplicate", campaign)}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleCampaignAction("Delete", campaign)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </motion.div>
                    ))
                  ) : (
                    <div className="p-8 text-center">
                      <p className="text-muted-foreground">No campaigns found.</p>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="google" className="mt-6">
          <Card>
            <CardContent className="p-6">
              <div className="text-center py-8">
                <h3 className="text-lg font-medium mb-2">Google Ads Campaigns</h3>
                <p className="text-muted-foreground">
                  Filter by platform "Google Ads" to see campaigns.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="meta" className="mt-6">
          <Card>
            <CardContent className="p-6">
              <div className="text-center py-8">
                <h3 className="text-lg font-medium mb-2">Meta Ads Campaigns</h3>
                <p className="text-muted-foreground">
                  Filter by platform "Meta Ads" to see campaigns.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CampaignsPage;