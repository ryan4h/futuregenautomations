import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from "@/components/ui/use-toast";
import TaskPageHeader from '@/pages/tasks/components/TaskPageHeader';
import TaskSummaryCards from '@/pages/tasks/components/TaskSummaryCards';
import TaskList from '@/pages/tasks/components/TaskList'; 
import NoTasksPlaceholder from '@/pages/tasks/components/NoTasksPlaceholder';
import AgentTaskStatsDialog from '@/pages/tasks/components/AgentTaskStatsDialog';
import { Loader2 } from 'lucide-react';

const TasksPage = () => {
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [agentFilter, setAgentFilter] = useState('all');
  const [availableAgents, setAvailableAgents] = useState([]);

  const [isStatsDialogOpen, setIsStatsDialogOpen] = useState(false);
  const [selectedAgentForStats, setSelectedAgentForStats] = useState(null);
  const [tasksForSelectedAgent, setTasksForSelectedAgent] = useState([]);

  const fetchTasks = useCallback(async (userId) => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from('zapier_task_data') // This is the table name for automation task data
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      toast({ title: "Error fetching tasks", description: error.message, variant: "destructive" });
      setTasks([]);
    } else {
      setTasks(data || []);
      const uniqueAgentNames = Array.from(new Set(data.map(task => task.agent_name).filter(Boolean)));
      setAvailableAgents(uniqueAgentNames);
    }
    setIsLoading(false);
  }, [toast]);

  useEffect(() => {
    const getCurrentUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        setUser(session.user);
        fetchTasks(session.user.id);
      } else {
        setIsLoading(false);
      }
    };
    getCurrentUser();
  }, [fetchTasks]);

  const handleViewAgentStats = (agentName, agentTasks) => {
    setSelectedAgentForStats(agentName);
    setTasksForSelectedAgent(agentTasks);
    setIsStatsDialogOpen(true);
  };

  // Group tasks by agent_name for the new card display
  const tasksByAgent = tasks.reduce((acc, task) => {
    const agentName = task.agent_name || 'Unknown Agent';
    if (!acc[agentName]) {
      acc[agentName] = [];
    }
    acc[agentName].push(task);
    return acc;
  }, {});

  const filteredAgentTaskGroups = Object.entries(tasksByAgent)
    .filter(([agentName, agentTasks]) => {
      const matchesSearch = agentName.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesAgentFilter = agentFilter === 'all' || agentName === agentFilter;
      
      // For status filter, check if any task for this agent matches the status
      const matchesStatus = statusFilter === 'all' || agentTasks.some(task => task.status?.toLowerCase() === statusFilter);
      
      return matchesSearch && matchesAgentFilter && matchesStatus;
    })
    .reduce((obj, [key, val]) => {
      obj[key] = val;
      return obj;
    }, {});


  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background text-foreground">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="ml-4 text-lg">Loading tasks...</p>
      </div>
    );
  }

  return (
    <motion.div 
      className="container mx-auto p-4 md:p-8 bg-background text-foreground"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <TaskPageHeader 
        searchTerm={searchTerm}
        onSearchTermChange={setSearchTerm}
        statusFilter={statusFilter}
        onStatusFilterChange={setStatusFilter}
        agentFilter={agentFilter}
        onAgentFilterChange={setAgentFilter}
        availableAgents={availableAgents}
      />
      <TaskSummaryCards tasks={tasks} />

      {Object.keys(filteredAgentTaskGroups).length > 0 ? (
        <TaskList 
          tasksByAgent={filteredAgentTaskGroups} 
          onViewAgentStats={handleViewAgentStats} 
        />
      ) : (
        <NoTasksPlaceholder 
            onClearFilters={() => {
                setSearchTerm('');
                setStatusFilter('all');
                setAgentFilter('all');
            }}
            hasActiveFilters={searchTerm !== '' || statusFilter !== 'all' || agentFilter !== 'all'}
        />
      )}
      
      {selectedAgentForStats && (
        <AgentTaskStatsDialog
          open={isStatsDialogOpen}
          onOpenChange={setIsStatsDialogOpen}
          agentName={selectedAgentForStats}
          tasks={tasksForSelectedAgent}
        />
      )}
    </motion.div>
  );
};

export default TasksPage;