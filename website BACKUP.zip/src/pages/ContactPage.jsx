import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Send, CheckCircle, Instagram } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import ContactForm from "./contact/ContactForm";
import ContactInfo from "./contact/ContactInfo";
import FaqSection from "./contact/FaqSection";
import { supabase } from "@/lib/supabaseClient";


const ContactPage = () => {
  const { toast } = useToast();
  const location = useLocation();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);

  const contactDetails = {
    email: "contact@futuregenautomations.com",
    phone: "+1 (951) 622-4965",
    phoneDesc: "Mon-Fri 9am-5pm PST",
    location: "Los Angeles, CA",
    businessHours: [
      "Mon - Fri: 9am-5pm PST",
      "Sat - Sun: 9am-3pm PST"
    ],
    socialMedia: [
      { name: "Instagram", url: "https://www.instagram.com/futuregenautomations/", icon: <Instagram className="h-5 w-5" /> },
    ],
  };

  const faqs = [
    {
      question: "How quickly can I expect a response?",
      answer: "We typically respond to all inquiries within 24 business hours. For urgent matters, please call our support line during business hours.",
    },
    {
      question: "Do you offer custom AI agent solutions?",
      answer: "Yes, we specialize in creating tailored AI solutions to meet your specific business needs. Contact us to discuss your requirements.",
    },
    {
      question: "What kind of businesses can benefit from your services?",
      answer: "Any business looking to automate tasks, improve customer service, manage data efficiently, or streamline financial processes can benefit from our AI agents.",
    },
    {
      question: "How do I get technical support for my agents?",
      answer: `Existing customers can access support through their dashboard or by emailing ${contactDetails.email} with their account details.`,
    },
  ];

  useEffect(() => {
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setCurrentUser(session?.user || null);
      if (session?.user) {
        const { data: profileData } = await supabase
          .from('user_profiles')
          .select('full_name')
          .eq('user_id', session.user.id)
          .single();
        setUserProfile(profileData);
      }
    };
    getSession();
  }, []);

  const prefillData = location.state || {};
   const initialFormValues = {
    name: prefillData.name || userProfile?.full_name || currentUser?.user_metadata?.full_name || "",
    email: prefillData.email || currentUser?.email || "",
    subject: prefillData.subject || "",
    message: prefillData.message || "",
  };


  const handleFormSubmit = async (formData) => {
    setIsSubmitting(true);
    try {
        const { error } = await supabase.from('contact_requests').insert([
        { 
            full_name: formData.name, 
            company_email: formData.email, // Assuming company_email is okay for general contact
            message: formData.message,
            subject: formData.subject,
            status: 'new_contact_form_submission' // Differentiate from signup requests
        }
      ]);
      if (error) throw error;

      setSubmitted(true);
      toast({
        title: "Message Sent",
        description: "We've received your message and will get back to you soon.",
      });
      return { success: true };
    } catch (error) {
      toast({
        title: "Submission Error",
        description: error.message || "Could not send your message. Please try again.",
        variant: "destructive",
      });
      return { success: false };
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setSubmitted(false);
    // If navigated from Ad Campaigns, clear specific state but not all if user is logged in
    if (location.state?.subject === "Interested in starting a new campaign") {
      navigate(location.pathname, { replace: true, state: {} });
    }
  };

  return (
    <div className="container py-8 bg-background text-foreground">
      <div className="mb-12 text-center">
        <motion.h1 
          className="text-4xl font-bold tracking-tight sm:text-5xl mb-3 text-white"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Get in Touch
        </motion.h1>
        <motion.p 
          className="text-muted-foreground max-w-2xl mx-auto text-lg"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          Have questions about our AI solutions or need assistance? Our dedicated team is ready to help you harness the power of automation.
        </motion.p>
      </div>

      <div className="grid gap-8 md:grid-cols-3 lg:gap-12 mb-12">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="md:col-span-2"
        >
          <Card className="h-full bg-card border-border shadow-xl">
            {submitted ? (
              <div className="flex flex-col items-center justify-center p-12 h-full text-center">
                <div className="rounded-full bg-green-500/10 p-4 mb-6 inline-block">
                  <CheckCircle className="h-10 w-10 text-green-500" />
                </div>
                <h2 className="text-2xl font-bold mb-3 text-card-foreground">Message Received!</h2>
                <p className="text-muted-foreground mb-8 max-w-md">
                  Thank you for reaching out. We've got your message and one of our specialists will contact you shortly.
                </p>
                <Button onClick={resetForm} variant="outline" className="btn-minimal">Send Another Message</Button>
              </div>
            ) : (
              <>
                <CardHeader className="border-b border-border">
                  <CardTitle className="text-2xl text-card-foreground">Send Us a Message</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Fill out the form, and we'll respond as soon as possible.
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <ContactForm onSubmit={handleFormSubmit} isSubmitting={isSubmitting} initialData={initialFormValues} />
                </CardContent>
              </>
            )}
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <ContactInfo details={contactDetails} />
        </motion.div>
      </div>

      <FaqSection faqs={faqs} />
      
    </div>
  );
};

export default ContactPage;