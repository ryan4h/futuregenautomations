import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Settings } from "lucide-react";

const IntegrationCard = ({ integration, onOpenRequestForm, disabled }) => {
  return (
    <Card className="bg-card border-border hover:shadow-lg transition-shadow flex flex-col">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-medium text-card-foreground">{integration.name}</CardTitle>
        <div className={`h-10 w-10 rounded-full flex items-center justify-center text-sm font-bold ${integration.category === "Platform" ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>
          {integration.logo}
        </div>
      </CardHeader>
      <CardContent className="flex-grow flex flex-col justify-between">
        <CardDescription className="text-muted-foreground mb-4 flex-grow">{integration.description}</CardDescription>
        {integration.connected ? (
          <div className="flex items-center space-x-2 mt-auto">
            <span className="h-2 w-2 rounded-full bg-green-500"></span>
            <span className="text-sm text-green-400">Connected</span>
            <Button variant="ghost" size="sm" className="ml-auto text-muted-foreground hover:text-foreground">
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <Button 
            variant="outline" 
            className="w-full mt-auto border-2 border-white bg-transparent hover:bg-white/10" 
            onClick={() => onOpenRequestForm(integration.name)} 
            disabled={disabled}
          >
            Request Connection
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

export default IntegrationCard;