import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";

const IntegrationRequestForm = ({ open, onOpenChange, onSubmit, loading, initialIntegrationName = "", userAgents = [] }) => {
  const [formData, setFormData] = useState({
    requested_integration_name: "",
    selected_agent_id: "",
    use_case: "",
    business_need: "" 
  });

  useEffect(() => {
    if (open) {
      setFormData({ 
        requested_integration_name: initialIntegrationName, 
        selected_agent_id: "",
        use_case: "",
        business_need: ""
      });
    }
  }, [open, initialIntegrationName]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAgentSelectChange = (value) => {
    setFormData(prev => ({ ...prev, selected_agent_id: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[525px] bg-card border-border text-card-foreground">
        <DialogHeader>
          <DialogTitle>Request New Integration</DialogTitle>
          <DialogDescription>
            Tell us about the integration you need, and we'll look into it.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div>
            <Label htmlFor="requested_integration_name" className="text-muted-foreground">Integration Name</Label>
            <Input 
              id="requested_integration_name" 
              name="requested_integration_name" 
              value={formData.requested_integration_name} 
              onChange={handleChange} 
              required 
              placeholder="e.g., Salesforce, HubSpot, Mailchimp"
              className="bg-input border-border focus:border-primary text-foreground" 
            />
          </div>
          <div>
            <Label htmlFor="selected_agent_id" className="text-muted-foreground">Agent (Optional)</Label>
            <Select
              value={formData.selected_agent_id}
              onValueChange={handleAgentSelectChange}
            >
              <SelectTrigger className="w-full bg-input border-border focus:border-primary text-foreground">
                <SelectValue placeholder="Select an agent to associate" />
              </SelectTrigger>
              <SelectContent>
                <ScrollArea className="h-auto max-h-48">
                  <SelectItem value="">None</SelectItem>
                  {userAgents.map(agent => (
                    <SelectItem key={agent.assigned_agent_id} value={agent.assigned_agent_id}>
                      {agent.agent_name}
                    </SelectItem>
                  ))}
                </ScrollArea>
              </SelectContent>
            </Select>
          </div>
           <div>
            <Label htmlFor="use_case" className="text-muted-foreground">Use Case</Label>
            <Textarea 
              id="use_case" 
              name="use_case" 
              value={formData.use_case} 
              onChange={handleChange} 
              required 
              placeholder="Describe how this integration would be used with the selected agent or generally."
              className="bg-input border-border focus:border-primary text-foreground" 
              rows={3}
            />
          </div>
          <div>
            <Label htmlFor="business_need" className="text-muted-foreground">Business Need (Additional Details)</Label>
            <Textarea 
              id="business_need" 
              name="business_need" 
              value={formData.business_need} 
              onChange={handleChange} 
              placeholder="Provide any other relevant business context or specific requirements."
              className="bg-input border-border focus:border-primary text-foreground" 
              rows={3}
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="border-2 border-white bg-transparent hover:bg-white/10">Cancel</Button>
            <Button type="submit" disabled={loading} className="bg-primary text-primary-foreground hover:bg-primary/90">
              {loading ? "Submitting..." : "Submit Request"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default IntegrationRequestForm;