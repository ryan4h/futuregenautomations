import React from 'react';
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Loader2, ExternalLink } from 'lucide-react';

const TierDowngradeDialog = ({ 
    open, 
    onOpenChange, 
    currentSubscription, 
    onManageSubscription, 
    isLoading 
}) => {
  const nextBillingDate = currentSubscription?.next_billing_date 
    ? new Date(currentSubscription.next_billing_date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) 
    : 'N/A';

  return (
    <AlertDialog open={open} onOpenChange={(isOpen) => {
      if (!isLoading) onOpenChange(isOpen);
    }}>
      <AlertDialogContent className="sm:max-w-[525px] bg-card border-border text-card-foreground">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-2xl">Manage Subscription</AlertDialogTitle>
          <AlertDialogDescription className="mt-2">
            Your current billing cycle ends on <span className="font-semibold text-primary">{nextBillingDate}</span>. 
            <br /><br />
            To change your plan (downgrade/upgrade) or cancel your subscription, please manage your account directly in the Stripe Customer Portal.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="mt-4">
          <AlertDialogCancel asChild>
             <Button variant="outline" disabled={isLoading} className="text-white border-white hover:bg-white/10">Cancel</Button>
          </AlertDialogCancel>
          <Button 
            onClick={onManageSubscription} 
            disabled={isLoading}
            className="min-w-[200px] bg-transparent hover:bg-white/10 text-white border-white/70 hover:border-white"
          >
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <>
                Go to Stripe Portal <ExternalLink className="ml-2 h-4 w-4" />
              </>
            )}
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default TierDowngradeDialog;