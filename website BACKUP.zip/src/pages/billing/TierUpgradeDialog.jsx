import React, { useState, useEffect } from "react";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/lib/supabaseClient";
import { loadStripe } from "@stripe/stripe-js";
import { Loader2, CheckCircle, ArrowRight, Info } from "lucide-react";

const STRIPE_PUBLISHABLE_KEY = 'pk_live_51RQ3IkDm0AzRryHihPdGiAwNeQyHy6xPOLPqYDf8aH0RnyODqxI3Rl8EqkaigYwFMBCudcGmulJp67UbitXTGM8q00a1m4j3TB'; 
const stripePromise = loadStripe(STRIPE_PUBLISHABLE_KEY);

const TierUpgradeDialog = ({
  open,
  onOpenChange,
  currentSubscription,
  allSubscriptionTiers,
  userId,
  userEmail,
}) => {
  const { toast } = useToast();
  const [selectedTier, setSelectedTier] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    if (open && allSubscriptionTiers && allSubscriptionTiers.length > 0) {
      if (!selectedTier) {
        const firstPurchasableAndDifferentTier = allSubscriptionTiers.find(
          tier => tier.tier_name && tier.price_id && tier.tier_name !== currentSubscription?.current_tier_name
        ) || allSubscriptionTiers.find(tier => tier.tier_name && tier.price_id);

        if (firstPurchasableAndDifferentTier) {
          setSelectedTier(firstPurchasableAndDifferentTier);
          console.log("TierUpgradeDialog: Auto-selected initial tier:", firstPurchasableAndDifferentTier);
        }
      }
    }
    if (!open) {
      setSelectedTier(null); 
      setIsProcessing(false);
    }
  }, [open, allSubscriptionTiers, currentSubscription]);
  
  const handleTierSelect = (tier) => {
    if (tier && tier.tier_name && tier.price_id) {
      setSelectedTier(tier);
      console.log("TierUpgradeDialog: User selected tier:", tier);
    } else {
      console.warn("TierUpgradeDialog: Selected tier is missing tier_name or price_id:", tier);
      toast({ title: "Tier Information Missing", description: "Selected tier data is incomplete. Please try another tier or contact support.", variant: "warning" });
    }
  };

  const handleConfirmUpgrade = async () => {
    console.log("TierUpgradeDialog: handleConfirmUpgrade called.");
    console.log("TierUpgradeDialog: Current selectedTier before sending:", selectedTier);

    if (!selectedTier) {
      toast({ title: "Selection Error", description: "Please select a tier to upgrade.", variant: "destructive" });
      return;
    }
    
    if (!selectedTier.price_id) {
      toast({ title: "Configuration Error", description: `The selected tier "${selectedTier.tier_name}" is missing crucial payment information (Price ID). Please contact support.`, variant: "destructive" });
      return;
    }
    
    if (!selectedTier.tier_name || typeof selectedTier.tier_name !== 'string' || selectedTier.tier_name.trim() === '') {
      toast({ title: "Configuration Error", description: "The selected tier is missing a valid name. Please ensure the tier configuration is correct.", variant: "destructive" });
      return;
    }

    if (!userId || !userEmail) {
      toast({ title: "Authentication Error", description: "Missing user ID or email information. Please re-login and try again.", variant: "destructive" });
      return;
    }
    
    setIsProcessing(true);
    try {
      const lineItems = [{ 
        tier_name: selectedTier.tier_name, 
        quantity: 1
      }];
      
      const payload = {
        userId,
        userEmail,
        lineItemsPayload: lineItems, 
        checkoutMode: 'subscription_only',
        metadata: {
          session_metadata: { 
            new_tier_name: selectedTier.tier_name, 
            old_tier_name: currentSubscription?.current_tier_name || "None", 
            user_id: userId 
          },
          subscription_metadata: { 
            user_id: userId, 
            current_tier_name: selectedTier.tier_name 
          }
        }
      };
      
      console.log("TierUpgradeDialog: Payload to Edge Function:", JSON.stringify(payload, null, 2));

      const { data, error: functionError, status } = await supabase.functions.invoke('create-stripe-checkout-session', {
        body: JSON.stringify(payload),
      });
      
      let errorBody = { message: "Failed to create Stripe checkout session." };
      if (functionError) {
        if (functionError.context && typeof functionError.context.json === 'function') {
            try { errorBody = await functionError.context.json(); } catch (e) { /* ignore parsing error */ }
        } else {
            errorBody.message = functionError.message || errorBody.message;
        }
      } else if (data && status !== 200 && typeof data === 'object') { 
         try { errorBody = data; } catch (e) { /* ignore */ }
      }


      if (functionError || status !== 200 || (data && !data.sessionId) ) {
        console.error("TierUpgradeDialog: Error invoking create-stripe-checkout-session:", errorBody, "Status:", status);
        const displayError = errorBody?.error || errorBody?.message || `Function returned status ${status || 'unknown'}`;
        toast({ title: "Upgrade Failed", description: displayError, variant: "destructive", duration: 7000 });
        setIsProcessing(false);
        return;
      }
      
      if (!data || !data.sessionId) {
        console.error("TierUpgradeDialog: No sessionId received from Edge Function:", data);
        throw new Error("Failed to get checkout session ID from the server.");
      }

      const stripe = await stripePromise;
      if (!stripe) {
        throw new Error("Stripe.js failed to load.");
      }
      const { error: stripeError } = await stripe.redirectToCheckout({ sessionId: data.sessionId });

      if (stripeError) {
        toast({ title: "Stripe Error", description: stripeError.message, variant: "destructive" });
        setIsProcessing(false); 
      }
    } catch (err) {
      toast({ title: "Upgrade Error", description: err.message, variant: "destructive" });
      console.error("TierUpgradeDialog: Full error during upgrade:", err);
      setIsProcessing(false);
    }
  };


  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="bg-card border-border text-card-foreground sm:max-w-2xl">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-2xl font-bold text-center">Change Your Plan</AlertDialogTitle>
          <AlertDialogDescription className="text-center text-muted-foreground">
            Choose any available tier. Your subscription will be updated accordingly.
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4 max-h-[60vh] overflow-y-auto">
          {(!allSubscriptionTiers || allSubscriptionTiers.length === 0) && (
            <div className="col-span-full flex flex-col items-center justify-center text-muted-foreground p-8">
              <Info className="h-10 w-10 mb-4 text-primary" />
              <p className="text-lg font-semibold">No Tiers Available</p>
              <p className="text-sm text-center">Subscription tiers are currently unavailable. Please try again later or contact support.</p>
            </div>
          )}
          {allSubscriptionTiers && allSubscriptionTiers.map((tier) => {
            const isCurrent = tier.tier_name === currentSubscription?.current_tier_name && currentSubscription?.subscription_status === 'active';
            const isSelected = selectedTier?.id === tier.id;
            const isPurchasable = !!tier.tier_name && !!tier.price_id; 

            return (
              <Card
                key={tier.id}
                className={`cursor-pointer transition-all duration-200 ease-in-out hover:shadow-xl 
                  ${isCurrent ? 'border-primary ring-2 ring-primary opacity-80' : 'border-border hover:border-primary'}
                  ${!isPurchasable ? 'opacity-50 cursor-not-allowed border-dashed' : ''}
                  ${isSelected && isPurchasable ? 'border-primary ring-2 ring-primary bg-primary/10' : ''}`}
                onClick={() => {
                  if (isPurchasable) {
                    handleTierSelect(tier);
                  } else {
                    toast({ title: "Tier Not Available", description: `This tier "${tier.tier_name || 'Unnamed'}" is not currently configured for purchase (missing name or price ID).`, variant: "warning" });
                  }
                }}
              >
                <CardHeader className="relative">
                  <CardTitle className="flex items-center text-xl">
                    {tier.tier_name || "Unnamed Tier"}
                    {isCurrent && <Badge variant="outline" className="ml-2 border-green-500 text-green-500 bg-green-500/10">Current Plan</Badge>}
                  </CardTitle>
                  <CardDescription className="text-sm">{tier.features?.short_description || `Up to ${tier.agent_limit_max} agents.`}</CardDescription>
                  {!isPurchasable && (
                    <Badge variant="destructive" className="absolute top-2 right-2">Not Configured</Badge>
                  )}
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-primary">${tier.monthly_rate}<span className="text-sm font-normal text-muted-foreground">/mo</span></p>
                  <ul className="mt-2 space-y-1 text-xs text-muted-foreground">
                    {Array.isArray(tier.features?.list) && tier.features.list.slice(0,3).map((feature, idx) => (
                        <li key={idx} className="flex items-center"><CheckCircle className="h-3 w-3 mr-2 text-green-500 flex-shrink-0" /> {feature}</li>
                    ))}
                     <li>Supports {tier.agent_limit_min} - {tier.agent_limit_max} agents</li>
                  </ul>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <AlertDialogFooter className="mt-6">
          <AlertDialogCancel asChild>
            <Button variant="outline" disabled={isProcessing} onClick={() => onOpenChange(false)} className="text-white border-white hover:bg-white/10">Cancel</Button>
          </AlertDialogCancel>
          <Button
            onClick={handleConfirmUpgrade}
            disabled={!selectedTier || isProcessing || !allSubscriptionTiers || allSubscriptionTiers.length === 0 || !selectedTier?.price_id || !selectedTier?.tier_name || (selectedTier?.tier_name === currentSubscription?.current_tier_name && currentSubscription?.subscription_status === 'active') }
            className="bg-transparent hover:bg-white/10 text-white border-white/70 hover:border-white"
          >
            {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ArrowRight className="mr-2 h-4 w-4" />}
            {selectedTier?.tier_name === currentSubscription?.current_tier_name ? 'Re-subscribe to ' : 'Switch to '} {selectedTier?.tier_name || "Selected Tier"}
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default TierUpgradeDialog;