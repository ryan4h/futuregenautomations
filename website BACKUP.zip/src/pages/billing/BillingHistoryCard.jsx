import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const BillingHistoryCard = ({ billingHistory = [] }) => {
  return (
    <Card className="mt-8 bg-card border-border shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl text-card-foreground">Billing History</CardTitle>
        <CardDescription className="text-muted-foreground">Overview of your past invoices.</CardDescription>
      </CardHeader>
      <CardContent>
        {billingHistory.length > 0 ? (
          <div className="space-y-3">
            {billingHistory.map(item => (
              <div key={item.id} className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 bg-muted/50 rounded-md">
                <div className="mb-2 sm:mb-0">
                  <p className="text-sm font-medium text-card-foreground">Invoice {item.invoiceId}</p>
                  <p className="text-xs text-muted-foreground">Date: {item.date}</p>
                </div>
                <div className="flex items-center gap-4">
                  <p className="text-sm text-card-foreground">${item.amount.toFixed(2)}</p>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${item.status === "Paid" ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}>
                    {item.status}
                  </span>
                  <Button variant="link" size="sm" className="text-xs text-primary p-0 h-auto">
                    View Invoice
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground text-center py-4">Detailed invoice history is available in the Stripe customer portal.</p>
        )}
      </CardContent>
    </Card>
  );
};

export default BillingHistoryCard;