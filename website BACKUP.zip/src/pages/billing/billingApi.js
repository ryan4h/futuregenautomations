import { supabase } from "@/lib/supabaseClient";

export const fetchBillingDetails = async (userId, toast) => {
  let subscriptionData = null;
  let activeAgents = 0;

  const { data: subData, error: subError } = await supabase
    .from('user_agent_subscriptions')
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();

  if (subError && subError.code !== 'PGRST116') {
    toast({ title: "Error fetching subscription", description: subError.message, variant: "destructive" });
  } else {
    subscriptionData = subData;
  }

  const { count, error: agentsError } = await supabase
    .from('user_assigned_agents')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('status', 'active');
  
  if (agentsError) {
    toast({ title: "Error fetching active agents count", description: agentsError.message, variant: "destructive" });
  } else {
    activeAgents = count || 0;
  }

  return { subscriptionData, activeAgents };
};