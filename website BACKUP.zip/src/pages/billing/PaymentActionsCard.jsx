import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CreditCard, ShieldCheck, Loader2, ArrowUpCircle, ArrowDownCircle, Settings } from "lucide-react";

const PaymentActionsCard = ({ 
  onManageSubscription, 
  onUpgradeAccount,
  onDowngradeAccount, 
  isLoadingPortal, 
  hasActiveSubscription 
}) => {
  return (
    <Card className="bg-card border-border shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl text-card-foreground">Subscription & Payment</CardTitle>
        <CardDescription className="text-muted-foreground">Manage your subscription tier and payment methods.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        
        <Button 
          className="w-full btn-minimal" 
          onClick={onUpgradeAccount} 
          disabled={isLoadingPortal}
        >
          <ArrowUpCircle className="mr-2 h-4 w-4" /> Upgrade Account Tier
        </Button>

        <Button 
          className="w-full btn-minimal" 
          onClick={onDowngradeAccount} // Explicit Downgrade button
          disabled={isLoadingPortal || !hasActiveSubscription} // Disable if no active sub or loading
        >
          <ArrowDownCircle className="mr-2 h-4 w-4" /> Downgrade Account
        </Button>
        
        <div className="pt-4 border-t border-border">
          <p className="text-sm text-muted-foreground mb-3">
            To manage payment methods, view billing history, or cancel your subscription, please use the Stripe customer portal.
          </p>
          <Button 
            className="w-full btn-minimal" 
            onClick={onManageSubscription} // This handler now should directly open portal, not another dialog for downgrade
            disabled={isLoadingPortal}
          >
            {isLoadingPortal ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Settings className="mr-2 h-4 w-4" />}
             Manage Subscription in Stripe
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default PaymentActionsCard;