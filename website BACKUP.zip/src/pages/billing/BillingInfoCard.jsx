import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertTriangle } from "lucide-react";

const BillingInfoCard = ({ subscription, activeAgentsCount, isLoading }) => {
  if (isLoading) {
    return (
      <Card className="md:col-span-1 bg-card border-border shadow-lg">
        <CardHeader>
          <Skeleton className="h-6 w-3/4 mb-2" />
          <Skeleton className="h-4 w-1/2" />
        </CardHeader>
        <CardContent className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i}>
              <Skeleton className="h-4 w-1/4 mb-1" />
              <Skeleton className="h-5 w-1/2" />
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  if (!subscription) {
    return (
      <Card className="md:col-span-1 bg-card border-border shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl text-card-foreground flex items-center">
            <AlertTriangle className="mr-2 h-5 w-5 text-yellow-500" />
            Subscription Information
          </CardTitle>
          <CardDescription className="text-muted-foreground">Details about your current plan.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">No active subscription found or an error occurred while fetching details.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="md:col-span-1 bg-card border-border shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl text-card-foreground">Current Subscription</CardTitle>
        <CardDescription className="text-muted-foreground">Your active plan details.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div>
          <p className="text-sm text-muted-foreground">Plan</p>
          <p className="text-lg font-semibold text-primary">{subscription.current_tier_name || 'N/A'}</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Price</p>
          <p className="text-md font-medium text-card-foreground">${parseFloat(subscription.current_tier_monthly_rate || 0).toFixed(2)} / Month</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Active Agents</p>
          <p className="text-md font-medium text-card-foreground">{activeAgentsCount || 0}</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Next Billing Date</p>
          <p className="text-md font-medium text-card-foreground">{subscription.next_billing_date ? new Date(subscription.next_billing_date).toLocaleDateString() : 'N/A'}</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Status</p>
          <p className={`text-md font-medium ${(subscription.subscription_status || '').toLowerCase() === "active" ? "text-green-500" : "text-yellow-500"}`}>{subscription.subscription_status || 'Unknown'}</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default BillingInfoCard;