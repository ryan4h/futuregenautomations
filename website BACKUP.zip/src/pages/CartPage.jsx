import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { ShoppingCart, ArrowLeft, Trash2 } from "lucide-react";

import CartItemCard from "./cart/CartItemCard"; 
import OrderSummaryCard from "./cart/OrderSummaryCard"; 
import CartCheckoutActions from "./cart/CartCheckoutActions";
import CurrentTierInfoCard from "./cart/CurrentTierInfoCard";

import { useCart } from "@/context/CartContext";
import { useCartUserData } from "./cart/hooks/useCartUserData";
import { useStripeCheckout } from "./cart/hooks/useStripeCheckout";

const CartPage = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const { cartItems, removeFromCart, clearCart } = useCart();
  
  const { 
    user, 
    currentActiveAgentCount, 
    currentSubscription, 
    isLoadingUserDetails,
    fetchInitialData 
  } = useCartUserData();
  
  const { isProcessingCheckout, processCheckout } = useStripeCheckout();
  const [needsUpgradeForCart, setNeedsUpgradeForCart] = useState(false);

  useEffect(() => {
    if (isLoadingUserDetails || cartItems.length === 0) {
      setNeedsUpgradeForCart(false);
      return;
    }

    const agentsBeingPurchased = cartItems.length; 
    const newTotalProjectedAgentCount = currentActiveAgentCount + agentsBeingPurchased;
    
    if (currentSubscription && typeof currentSubscription.max_agents === 'number') {
      if (currentSubscription.max_agents === 0 && newTotalProjectedAgentCount > 0) {
        setNeedsUpgradeForCart(true);
      } else {
        setNeedsUpgradeForCart(newTotalProjectedAgentCount > currentSubscription.max_agents);
      }
    } else { 
      setNeedsUpgradeForCart(newTotalProjectedAgentCount > 0);
      if (newTotalProjectedAgentCount > 0 && !currentSubscription) {
        setTimeout(() => {
          if (!currentSubscription) {
            toast({ 
              title: "Subscription Info Pending", 
              description: "Your agent limit is being determined. If this persists, please check your Billing page.", 
              variant: "default",
              duration: 7000 
            });
          }
        }, 1500);
      }
    }
  }, [cartItems, currentActiveAgentCount, currentSubscription, isLoadingUserDetails, toast]);
  
  useEffect(() => {
    const queryParams = new URLSearchParams(window.location.search);
    if (queryParams.get('agent_purchase_success') === 'true') {
      toast({
        title: "Purchase Successful!",
        description: "New agents have been added to your account.",
        variant: "success",
      });
      clearCart();
      if(user) fetchInitialData(user.id); 
      navigate('/cart', { replace: true }); 
    } else if (queryParams.get('agent_purchase_cancel') === 'true') {
      toast({
        title: "Purchase Canceled",
        description: "The agent purchase process was canceled.",
        variant: "default",
      });
      navigate('/cart', { replace: true });
    }
  }, [user, fetchInitialData, navigate, toast, clearCart]);

  const handleProceedToCheckout = async () => {
    const result = await processCheckout(
      user, 
      cartItems, 
      needsUpgradeForCart, 
      isLoadingUserDetails,
      setNeedsUpgradeForCart // Pass setter to update state from hook if backend says upgrade needed
    );
    if (!result.success && result.reason === "login_required") {
      navigate("/login");
    }
    // Other error cases are handled by toasts within the hook
  };

  const totalAmount = cartItems.reduce((sum, item) => sum + (item.price_one_time || 0), 0);

  return (
    <div className="container py-8 bg-background text-foreground">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Purchase Agents</h1>
          <Button variant="outline" onClick={() => navigate("/products")}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Find More Agents
          </Button>
        </div>

        {cartItems.length === 0 ? (
          <Card className="bg-transparent border-2 border-white text-white">
            <CardContent className="p-12 text-center">
              <ShoppingCart className="mx-auto h-16 w-16 text-muted-foreground mb-6" />
              <h3 className="text-xl font-semibold mb-2">Your cart is empty</h3>
              <p className="text-muted-foreground mb-4">
                Looks like you haven't added any AI agents yet.
              </p>
              <Button variant="outline" onClick={() => navigate("/products")}>
                Browse Agents
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2 space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Cart Items ({cartItems.length})</h2>
                 <Button variant="outline" size="sm" className="text-destructive border-destructive hover:bg-destructive/10" onClick={clearCart}>
                    <Trash2 className="mr-2 h-4 w-4" /> Clear Cart
                </Button>
              </div>
              {cartItems.map((item) => (
                <CartItemCard
                  key={item.id} 
                  item={{...item, price: item.price_one_time || item.price || 0, quantity: 1}} 
                  onRemoveItem={removeFromCart}
                />
              ))}
            </div>
            <div className="md:col-span-1 space-y-6"> 
              <OrderSummaryCard 
                subtotal={totalAmount}
                total={totalAmount} 
              />
              <CurrentTierInfoCard
                isLoading={isLoadingUserDetails}
                currentSubscription={currentSubscription}
                activeAgentCount={currentActiveAgentCount}
              />
              <CartCheckoutActions
                isLoadingUserDetails={isLoadingUserDetails}
                needsUpgradeForCart={needsUpgradeForCart}
                isProcessingCheckout={isProcessingCheckout}
                cartItemCount={cartItems.length}
                onProceedToCheckout={handleProceedToCheckout}
                onNavigateToBilling={() => navigate("/billing")}
              />
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default CartPage;