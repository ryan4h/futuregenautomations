import React from "react";

const ProductsPageHeader = () => {
  return (
    <div className="text-center mb-12 pt-8">
      <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-primary via-accent to-secondary mb-3">
        Browse AI Agents
      </h1>
      <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
        Get your AI agent today, for optimizing your business's workflow.
      </p>
    </div>
  );
};

export default ProductsPageHeader;