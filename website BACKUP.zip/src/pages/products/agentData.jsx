import React from "react";
import { Users, Mail, Phone, FileText, Star, Calendar, Zap, Brain, DollarSign, ShoppingCart, BarChart, MessageSquare, Briefcase, Settings, Code, Search } from "lucide-react";

const iconMap = {
  Users: <Users />,
  Mail: <Mail />,
  Phone: <Phone />,
  FileText: <FileText />,
  Star: <Star />,
  Calendar: <Calendar />,
  Zap: <Zap />,
  Brain: <Brain />,
  DollarSign: <DollarSign />,
  ShoppingCart: <ShoppingCart />,
  BarChart: <BarChart />,
  MessageSquare: <MessageSquare />,
  Briefcase: <Briefcase />,
  Settings: <Settings />,
  Code: <Code />,
  Search: <Search />,
  Default: <Zap /> 
};

export const getProductIcon = (iconName) => {
  if (typeof iconName === 'string' && iconMap[iconName]) {
    return iconMap[iconName];
  }
  return iconMap.Default;
};

export const mapSupabaseProductToLocal = (supabaseProduct) => {
  return {
    id: supabaseProduct.id,
    uuid_id: supabaseProduct.uuid_id, // Keep the UUID if it exists and is used
    name: supabaseProduct.agent_name,
    description: supabaseProduct.description,
    long_description: supabaseProduct.long_description,
    price: parseFloat(supabaseProduct.price_one_time) || 0, // Ensure it's a number
    price_one_time: parseFloat(supabaseProduct.price_one_time) || 0, // Explicitly map
    category: supabaseProduct.category,
    rating: parseFloat(supabaseProduct.rating) || null, // Can be null if no rating
    reviews_count: parseInt(supabaseProduct.reviews_count, 10) || 0,
    is_popular: supabaseProduct.is_popular || false,
    features: supabaseProduct.features || [], // Expects an array of strings
    benefits: supabaseProduct.benefits || [], // Expects an array of strings
    specifications: supabaseProduct.specifications || {}, // Expects a JSON object
    faqs: supabaseProduct.faqs || [], // Expects an array of {question: string, answer: string}
    iconName: supabaseProduct.icon_name, // Store the name for icon mapping
    // The actual icon component is not stored here, but derived via getProductIcon in the component
  };
};