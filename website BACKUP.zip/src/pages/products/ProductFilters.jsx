import React from "react";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ListFilter, ArrowUpDown } from "lucide-react";

const ProductFilters = ({
  categories,
  selectedCategory,
  setSelectedCategory,
  selectedSort,
  setSelectedSort,
  sortOptions = [
    { value: "popular", label: "Popularity" },
    { value: "price-low", label: "Price: Low to High" },
    { value: "price-high", label: "Price: High to Low" },
    { value: "rating", label: "Rating" },
  ]
}) => {
  return (
    <div className="flex flex-col sm:flex-row gap-4 md:gap-6 items-center justify-center mb-8">
      <div className="w-full sm:w-auto">
        <Label className="text-sm font-medium text-gray-300 flex items-center mb-1.5">
          <ListFilter className="h-4 w-4 mr-2" />
          Filter by Category
        </Label>
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-full sm:w-[200px] bg-transparent border-2 border-white/50 text-white placeholder:text-gray-400 focus:border-primary h-11">
            <SelectValue placeholder="Select category" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((category) => (
              <SelectItem key={category} value={category} className="focus:bg-gray-700 capitalize">
                {category === 'all' ? 'All Categories' : category}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="w-full sm:w-auto">
        <Label className="text-sm font-medium text-gray-300 flex items-center mb-1.5">
          <ArrowUpDown className="h-4 w-4 mr-2" />
          Sort By
        </Label>
        <Select value={selectedSort} onValueChange={setSelectedSort}>
          <SelectTrigger className="w-full sm:w-[200px] bg-transparent border-2 border-white/50 text-white placeholder:text-gray-400 focus:border-primary h-11">
            <SelectValue placeholder="Select sort order" />
          </SelectTrigger>
          <SelectContent>
            {sortOptions.map(option => (
              <SelectItem key={option.value} value={option.value} className="focus:bg-gray-700">
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default ProductFilters;