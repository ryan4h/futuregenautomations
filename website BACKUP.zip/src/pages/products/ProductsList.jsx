import React from "react";
import ProductCard from "./ProductCard";
import { Button } from "@/components/ui/button";
import { Frown, FilterX } from "lucide-react";

const ProductsList = ({ products, onResetFilters, user }) => {
  if (!products || products.length === 0) {
    return (
      <div className="text-center py-10">
        <Frown className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
        <h3 className="text-xl font-semibold text-foreground mb-2">No Agents Found</h3>
        <p className="text-muted-foreground mb-4">
          We couldn't find any agents matching your current filters.
        </p>
        <Button variant="outline" onClick={onResetFilters} className="btn-minimal">
          <FilterX className="mr-2 h-4 w-4" /> Reset Filters
        </Button>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {products.map((product) => (
        <ProductCard 
          key={product.id} 
          product={product} 
          isOwned={product.isOwned}
          user={user}
        />
      ))}
    </div>
  );
};

export default ProductsList;