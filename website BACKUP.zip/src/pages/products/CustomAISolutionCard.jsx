import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const CustomAISolutionCard = () => {
  const navigate = useNavigate();

  return (
    <Card className="bg-transparent border-2 border-white text-white mt-12">
      <CardContent className="p-8">
        <div className="grid gap-8 md:grid-cols-2 items-center">
          <div>
            <h2 className="text-2xl font-bold mb-4 text-white">Need a Custom AI Solution?</h2>
            <p className="text-gray-300 mb-6">
              Our team can build custom AI agents tailored to your specific business needs and goals.
            </p>
            <Button variant="outline" onClick={() => navigate("/contact")}>
              Contact Us for a Quote
            </Button>
          </div>
          <div className="flex justify-center">
            <div className="rounded-lg bg-black/30 p-6 shadow-lg max-w-md border-2 border-white/30">
              <h3 className="font-bold mb-4 text-white">Our Custom AI Development Process</h3>
              <ol className="space-y-3">
                {[
                  "Discovery & Consultation: We discuss your specific needs and goals.",
                  "Solution Design: Our team designs a custom AI solution architecture.",
                  "Agile Development: We build and iteratively test your custom AI agent.",
                  "Deployment & Integration: Seamless integration with your existing systems."
                ].map((step, i) => (
                   <li key={i} className="flex items-start">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-primary bg-primary/20 text-xs text-primary mr-3">
                      {i + 1}
                    </span>
                    <span className="text-gray-300">{step}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CustomAISolutionCard;