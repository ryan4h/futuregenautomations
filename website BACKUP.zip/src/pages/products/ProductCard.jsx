import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, Eye, CheckCircle, Zap } from "lucide-react";
import { getProductIcon } from "./agentData";

const ProductCard = ({ product, onAddToCart, onViewDetails, isOwned, isPurchasable }) => {
  const IconComponent = getProductIcon(product.icon_name) || <Zap className="h-8 w-8 text-primary" />;

  return (
    <motion.div
      className="h-full"
      whileHover={{ y: -5, boxShadow: "0px 10px 20px rgba(0,0,0,0.2)" }}
      transition={{ type: "spring", stiffness: 300 }}
    >
      <Card className="h-full flex flex-col bg-card/70 border-2 border-card-border backdrop-blur-md shadow-xl overflow-hidden transition-all duration-300 hover:border-primary/70">
        <CardHeader className="p-4 border-b border-card-border/50 min-h-[80px]"> {/* Added min-h for header consistency */}
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-md flex-shrink-0">
                {React.cloneElement(IconComponent, { className: "h-6 w-6 text-primary" })}
              </div>
              <CardTitle className="text-lg font-semibold text-card-foreground leading-tight line-clamp-2">{product.agent_name}</CardTitle> {/* Added line-clamp for title consistency */}
            </div>
            {product.is_popular && (
              <Badge variant="outline" className="text-xs border-amber-400 text-amber-400 bg-amber-500/10 shrink-0 ml-2">Popular</Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-4 flex-grow flex flex-col"> {/* Made CardContent flex-col */}
          <p className="text-xs text-muted-foreground mb-3 line-clamp-3 min-h-[3.75em]"> {/* Adjusted min-h for 3 lines of text */}
            {product.description || "No description available."}
          </p>
          <div className="flex items-center justify-between mt-auto pt-2"> {/* Added mt-auto to push this to bottom and pt-2 for spacing */}
            <p className="text-xl font-bold text-primary">
              ${(product.price_one_time || 0).toFixed(2)}
            </p>
            <div className="flex items-center"> 
              <Badge variant="secondary" className="text-xs">{product.category || "General"}</Badge>
            </div>
          </div>
        </CardContent>
        <CardFooter className="p-4 border-t border-card-border/50 grid grid-cols-2 gap-2">
          <Button variant="outline" onClick={onViewDetails} className="w-full border-primary text-primary hover:bg-primary/10">
            <Eye className="mr-2 h-4 w-4" /> View
          </Button>
          {isOwned ? (
            <Button variant="outline" disabled className="w-full border-green-500 text-green-500 bg-green-500/10 cursor-default">
              <CheckCircle className="mr-2 h-4 w-4" /> Owned
            </Button>
          ) : !isPurchasable ? (
            <Button variant="outline" disabled className="w-full">
              Unavailable
            </Button>
          ) : (
            <Button variant="default" onClick={() => onAddToCart(product)} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
              <ShoppingCart className="mr-2 h-4 w-4" /> Get Now
            </Button>
          )}
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default ProductCard;