import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { supabase } from "@/lib/supabaseClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useToast } from "@/components/ui/use-toast";
import { useCart } from "@/context/CartContext";
import { ArrowLeft, ShoppingCart, Zap, CheckCircle, Star, MessageSquare, ShieldCheck, Loader2, AlertTriangle } from "lucide-react";
import { getProductIcon, mapSupabaseProductToLocal } from "./agentData";

const ProductDetailPage = () => {
  const { id } = useParams(); // This 'id' is the integer primary key from ai_agents_list
  const navigate = useNavigate();
  const { toast } = useToast();
  const { addToCart } = useCart(); // Corrected from addItem to addToCart
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProduct = async () => {
      if (!supabase) {
        setError("Supabase client not available.");
        setLoading(false);
        return;
      }
      setLoading(true);
      setError(null);
      
      // Fetch by the integer 'id' column
      const { data, error: dbError } = await supabase
        .from("ai_agents_list")
        .select("*")
        .eq("id", id) // Use the integer ID for lookup
        .single();

      if (dbError) {
        setError(dbError.message);
        toast({
          title: "Error Fetching Product",
          description: dbError.message,
          variant: "destructive",
        });
      } else if (data) {
        setProduct(mapSupabaseProductToLocal(data)); // Map the fetched data
      } else {
        setError("Product not found.");
         toast({
          title: "Product Not Found",
          description: "The requested agent could not be found.",
          variant: "destructive",
        });
      }
      setLoading(false);
    };

    if (id) {
      fetchProduct();
    }
  }, [id, toast]);

  const handleAddToCart = () => {
    if (product) {
      addToCart({ ...product, price: product.price_one_time, quantity: 1 });
      toast({
        title: `${product.name} added to cart!`,
        description: "Your AI agent is ready for deployment.",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-80px)] bg-background text-foreground">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="ml-4 text-lg">Loading agent details...</p>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-80px)] bg-background text-foreground p-4">
        <AlertTriangle className="h-16 w-16 text-destructive mb-6" />
        <h2 className="text-2xl font-semibold mb-2">Agent Not Found</h2>
        <p className="text-muted-foreground mb-6 text-center">
          {error ? error : "We couldn't find the AI agent you're looking for."}
        </p>
        <Button variant="outline" onClick={() => navigate("/products")}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Automations
        </Button>
      </div>
    );
  }

  const IconComponent = getProductIcon(product.iconName) || <Zap className="h-10 w-10 text-primary" />;

  return (
    <div className="container py-12 bg-background text-foreground">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Button variant="outline" onClick={() => navigate("/products")} className="mb-8">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Automations
        </Button>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          <Card className="bg-transparent border-2 border-white text-white">
            <CardContent className="p-6 md:p-8">
              <div className="w-full aspect-square bg-black/30 border border-white/20 rounded-lg flex items-center justify-center mb-6">
                {React.cloneElement(IconComponent, { className: "h-24 w-24 text-white/80" })}
              </div>
              <h1 className="text-3xl lg:text-4xl font-bold text-white mb-3">{product.name}</h1>
              <div className="flex items-center gap-4 mb-4">
                <Badge variant="secondary" className="text-sm bg-white/10 border-white/30 text-gray-300 capitalize">{product.category}</Badge>
                {product.rating && product.reviews_count > 0 && (
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className={`h-5 w-5 ${i < Math.round(product.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-500'}`} />
                    ))}
                    <span className="ml-2 text-sm text-gray-300">({product.reviews_count} reviews)</span>
                  </div>
                )}
              </div>
              <p className="text-gray-300 leading-relaxed mb-6">{product.long_description || product.description}</p>
              <div className="mb-6">
                <p className="text-4xl font-extrabold text-white">${product.price_one_time.toFixed(2)}</p>
                <p className="text-sm text-gray-400">One-time purchase</p>
              </div>
              <Button size="lg" className="w-full text-lg py-3" variant="outline" onClick={handleAddToCart}>
                <ShoppingCart className="mr-2 h-5 w-5" /> Get Now
              </Button>
              <div className="mt-4 flex items-center justify-center text-xs text-gray-400">
                <ShieldCheck className="h-4 w-4 mr-1 text-green-400" />
                <span>Secure Purchase & Instant Deployment</span>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-8">
            {product.features && product.features.length > 0 && (
              <Card className="bg-transparent border-2 border-white text-white">
                <CardHeader>
                  <CardTitle className="text-2xl text-white">Key Features</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {product.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-green-400 mr-3 mt-1 shrink-0" />
                        <span className="text-gray-300">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}

            {product.benefits && product.benefits.length > 0 && (
              <Card className="bg-transparent border-2 border-white text-white">
                <CardHeader>
                  <CardTitle className="text-2xl text-white">Benefits</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {product.benefits.map((benefit, index) => (
                      <li key={index} className="flex items-start">
                        <Star className="h-5 w-5 text-yellow-400 mr-3 mt-1 shrink-0" />
                        <span className="text-gray-300">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}
            
            {product.specifications && Object.keys(product.specifications).length > 0 && (
              <Card className="bg-transparent border-2 border-white text-white">
                <CardHeader>
                  <CardTitle className="text-2xl text-white">Specifications</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3">
                    {Object.entries(product.specifications).map(([key, value]) => (
                      <div key={key} className="text-sm">
                        <span className="font-semibold text-gray-200">{key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}: </span>
                        <span className="text-gray-300">{typeof value === 'boolean' ? (value ? 'Yes' : 'No') : String(value)}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {product.faqs && product.faqs.length > 0 && (
              <Card className="bg-transparent border-2 border-white text-white">
                <CardHeader>
                  <CardTitle className="text-2xl text-white">Frequently Asked Questions</CardTitle>
                </CardHeader>
                <CardContent>
                  <Accordion type="single" collapsible className="w-full">
                    {product.faqs.map((faq, index) => (
                      <AccordionItem key={index} value={`item-${index}`} className="border-white/30">
                        <AccordionTrigger className="text-left text-gray-200 hover:text-white">{faq.question}</AccordionTrigger>
                        <AccordionContent className="text-gray-300">
                          {faq.answer}
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default ProductDetailPage;