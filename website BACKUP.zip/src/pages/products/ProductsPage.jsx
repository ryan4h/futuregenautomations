import React, { useState, useEffect, useMemo, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { Search as SearchIcon, RefreshCw } from "lucide-react";
import ProductFilters from "./ProductFilters";
import ProductsList from "./ProductsList";
import { mapSupabaseProductToLocal } from "./agentData";
import { supabase } from "@/lib/supabaseClient";
import ProductsPageHeader from "./ProductsPageHeader";
import CustomAISolutionCard from "./CustomAISolutionCard";
import { Skeleton } from "@/components/ui/skeleton";

const ProductsPage = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [allProducts, setAllProducts] = useState([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedSort, setSelectedSort] = useState("popular");
  
  const [userAssignedAgents, setUserAssignedAgents] = useState([]);

  const fetchProducts = useCallback(async () => {
    if (isRefreshing) return; 
    setLoadingProducts(true);
    setIsRefreshing(true); 
    if (!supabase) {
      toast({ title: "Error", description: "Supabase client not available.", variant: "destructive" });
      setLoadingProducts(false);
      setIsRefreshing(false);
      return;
    }
    const { data, error } = await supabase
      .from('ai_agents_list')
      .select('*')
      .order('agent_name', { ascending: true });

    if (error) {
      toast({ title: "Error Fetching Products", description: error.message, variant: "destructive" });
      setAllProducts([]);
    } else {
      setAllProducts(data.map(mapSupabaseProductToLocal));
    }
    setLoadingProducts(false);
    setIsRefreshing(false);
  }, [toast, isRefreshing]);


  const fetchUserAssignedAgentIds = useCallback(async (userId) => {
    if (!supabase || !userId) return;
    const { data, error } = await supabase
      .from('user_assigned_agents')
      .select('agent_product_id')
      .eq('user_id', userId)
      .eq('status', 'active');
    if (error) {
      console.error("Error fetching assigned agent IDs:", error);
      toast({ title: "Error", description: "Could not fetch your owned agents list.", variant: "warning" });
    } else {
      setUserAssignedAgents(data.map(item => item.agent_product_id));
    }
  }, [toast]);
  
  useEffect(() => {
    const getSessionAndData = async () => {
      if (!supabase) return;
      setLoadingProducts(true); 
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user || null);
      
      await fetchProducts(); 

      if (session?.user) {
        await fetchUserAssignedAgentIds(session.user.id);
      }
      setLoadingProducts(false);
    };
    getSessionAndData();

    if (!supabase) return;
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null);
      if (session?.user) {
        fetchUserAssignedAgentIds(session.user.id);
      } else {
        setUserAssignedAgents([]);
      }
    });

    return () => {
      authListener?.subscription.unsubscribe();
    };
  }, [fetchProducts, fetchUserAssignedAgentIds]);
  
  const filteredProducts = useMemo(() => {
    return allProducts.filter((product) => {
      const nameMatch = product.name?.toLowerCase().includes(searchQuery.toLowerCase());
      const descriptionMatch = product.description?.toLowerCase().includes(searchQuery.toLowerCase());
      const categoryMatch = product.category?.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesSearch = nameMatch || descriptionMatch || categoryMatch;
      const matchesCategoryFilter = selectedCategory === "all" || product.category === selectedCategory;
      return matchesSearch && matchesCategoryFilter;
    });
  }, [allProducts, searchQuery, selectedCategory]);

  const sortedProductsWithStatus = useMemo(() => {
    const productsWithStatus = filteredProducts.map(p => ({
      ...p,
      isOwned: userAssignedAgents.includes(p.id) // Changed from isAssigned to isOwned
    }));

    return [...productsWithStatus].sort((a, b) => {
      if (selectedSort === "popular") {
        return (b.is_popular ? 1 : 0) - (a.is_popular ? 1 : 0) || (b.rating || 0) - (a.rating || 0);
      } else if (selectedSort === "price-low") {
        return (a.price_one_time || 0) - (b.price_one_time || 0);
      } else if (selectedSort === "price-high") {
        return (b.price_one_time || 0) - (a.price_one_time || 0);
      } else if (selectedSort === "rating") {
        return (b.rating || 0) - (a.rating || 0);
      }
      return 0;
    });
  }, [filteredProducts, selectedSort, userAssignedAgents]);

  const categories = useMemo(() => {
    const uniqueCategories = [...new Set(allProducts.map((product) => product.category))];
    return ["all", ...uniqueCategories.filter(c => c)]; 
  }, [allProducts]);
  
  const resetFilters = () => {
    setSearchQuery("");
    setSelectedCategory("all");
    setSelectedSort("popular");
  };
  
  const renderSkeletons = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
      {[...Array(6)].map((_, index) => (
        <div key={index} className="bg-card border border-border p-4 rounded-lg">
          <Skeleton className="h-24 w-full mb-4" />
          <Skeleton className="h-6 w-3/4 mb-2" />
          <Skeleton className="h-4 w-1/2 mb-4" />
          <div className="flex justify-between items-center">
            <Skeleton className="h-8 w-1/3" />
            <Skeleton className="h-8 w-1/3" />
          </div>
        </div>
      ))}
    </div>
  );


  return (
    <div className="container py-8 bg-background text-foreground">
      <ProductsPageHeader 
        loadingProducts={isRefreshing} // Use isRefreshing for the header spinner
        onRefreshProducts={fetchProducts} 
      />

      <div className="my-8 flex justify-center">
        <div className="relative w-full md:w-3/4 lg:w-2/3 xl:w-1/2">
          <SearchIcon className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <Input
            id="search"
            type="text"
            placeholder="Search agents by name, description, or category..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12 pr-4 py-3 h-12 text-base bg-transparent border-2 border-white/50 text-white placeholder:text-gray-400 focus:border-primary w-full rounded-lg"
          />
        </div>
      </div>
      
      <ProductFilters
        categories={categories}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        selectedSort={selectedSort}
        setSelectedSort={setSelectedSort}
        sortOptions={[
          { value: "popular", label: "Popularity" },
          { value: "price-low", label: "Price: Low to High" },
          { value: "price-high", label: "Price: High to Low" },
          { value: "rating", label: "Rating" },
        ]}
      />

      <div className="mt-8">
        {loadingProducts ? renderSkeletons() : (
          <ProductsList 
            products={sortedProductsWithStatus}
            onResetFilters={resetFilters}
            user={user} 
          />
        )}
      </div>

      <CustomAISolutionCard />
    </div>
  );
};

export default ProductsPage;