import React from "react";
import { Button } from "@/components/ui/button";
import { Filter, PlusCircle } from "lucide-react";

const AdCampaignsHeader = ({ onRefresh, onNewCampaign, loading }) => {
  return (
    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
      <h1 className="text-3xl font-bold text-foreground">Ad Campaigns</h1>
      <div className="flex gap-2 w-full sm:w-auto">
        <Button variant="outline" className="btn-minimal flex-1 sm:flex-none" onClick={onRefresh} disabled={loading}>
          <Filter className="mr-2 h-4 w-4" /> Refresh
        </Button>
        <Button variant="outline" className="btn-minimal flex-1 sm:flex-none" onClick={onNewCampaign}>
          <PlusCircle className="mr-2 h-4 w-4" /> New Campaign
        </Button>
      </div>
    </div>
  );
};

export default AdCampaignsHeader;