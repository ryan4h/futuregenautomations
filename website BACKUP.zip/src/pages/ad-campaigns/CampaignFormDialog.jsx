import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const CampaignFormDialog = ({ open, onOpenChange, onSubmit, campaign, loading }) => {
  const initialFormData = {
    campaign_name: "",
    platform: "Google Ads",
    status: "Draft",
    budget: 0, 
    daily_budget: 0, 
    target_audience: { demographics: "", interests: "" },
    notes: "",
    api_endpoint: "", 
  };
  
  const [formData, setFormData] = useState(initialFormData);

  useEffect(() => {
    if (campaign) {
      setFormData({
        campaign_name: campaign.campaign_name || "",
        platform: campaign.platform || "Google Ads",
        status: campaign.status || "Draft",
        budget: campaign.budget || 0,
        daily_budget: campaign.daily_budget || 0,
        target_audience: campaign.target_audience || { demographics: "", interests: "" },
        notes: campaign.notes || "",
        api_endpoint: campaign.api_endpoint || "",
      });
    } else {
      setFormData(initialFormData);
    }
  }, [campaign, open]);

  const handleChange = (e) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'number' ? parseFloat(value) || 0 : value }));
  };
  
  const handleSelectChange = (name, value) => {
     setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAudienceChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      target_audience: { ...prev.target_audience, [name]: value }
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[525px] bg-card border-border text-card-foreground">
        <DialogHeader>
          <DialogTitle>{campaign ? "Edit Campaign Settings" : "Create New Campaign (Internal)"}</DialogTitle>
          <DialogDescription>
            {campaign ? "Update the settings of your ad campaign." : "Fill in the details for your new ad campaign."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4 max-h-[70vh] overflow-y-auto pr-2">
          <div>
            <Label htmlFor="campaign_name">Campaign Name</Label>
            <Input id="campaign_name" name="campaign_name" value={formData.campaign_name} onChange={handleChange} required className="bg-input border-border focus:border-primary" />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="platform">Platform</Label>
              <Select name="platform" value={formData.platform} onValueChange={(value) => handleSelectChange("platform", value)}>
                <SelectTrigger className="w-full bg-input border-border focus:border-primary">
                  <SelectValue placeholder="Select platform" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Google Ads">Google Ads</SelectItem>
                  <SelectItem value="Meta Ads">Meta Ads</SelectItem>
                  <SelectItem value="LinkedIn Ads">LinkedIn Ads</SelectItem>
                  <SelectItem value="Twitter Ads">Twitter Ads</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="status">Status</Label>
              <Select name="status" value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
                <SelectTrigger className="w-full bg-input border-border focus:border-primary">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Draft">Draft</SelectItem>
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="Paused">Paused</SelectItem>
                  <SelectItem value="Completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="budget">Total Budget ($)</Label>
              <Input id="budget" name="budget" type="number" value={formData.budget} onChange={handleChange} className="bg-input border-border focus:border-primary" />
            </div>
            <div>
              <Label htmlFor="daily_budget">Daily Budget ($)</Label>
              <Input id="daily_budget" name="daily_budget" type="number" value={formData.daily_budget} onChange={handleChange} className="bg-input border-border focus:border-primary" />
            </div>
          </div>

          <div>
            <Label htmlFor="api_endpoint">API Endpoint (Optional)</Label>
            <Input id="api_endpoint" name="api_endpoint" value={formData.api_endpoint} onChange={handleChange} placeholder="e.g., https://your-api.com/webhook" className="bg-input border-border focus:border-primary" />
          </div>

          <div>
            <Label htmlFor="target_audience_demographics">Target Demographics</Label>
            <Input id="target_audience_demographics" name="demographics" value={formData.target_audience.demographics} onChange={handleAudienceChange} placeholder="e.g., Age 25-45, Urban areas" className="bg-input border-border focus:border-primary" />
          </div>
           <div>
            <Label htmlFor="target_audience_interests">Target Interests</Label>
            <Input id="target_audience_interests" name="interests" value={formData.target_audience.interests} onChange={handleAudienceChange} placeholder="e.g., Tech enthusiasts, Small business owners" className="bg-input border-border focus:border-primary" />
          </div>
          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea id="notes" name="notes" value={formData.notes} onChange={handleChange} className="bg-input border-border focus:border-primary" />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="btn-minimal">Cancel</Button>
            <Button type="submit" disabled={loading} className="btn-minimal">
              {loading ? (campaign ? "Saving..." : "Creating...") : (campaign ? "Save Changes" : "Create Campaign")}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CampaignFormDialog;