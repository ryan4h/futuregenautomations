import React from "react";
import { Button } from "@/components/ui/button";
import {
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent as AlertContent,
  AlertDialogDescription as AlertDescription,
  AlertDialogFooter as AlertFooter,
  AlertDialogHeader as AlertHeader,
  AlertDialogTitle as AlertTitle,
} from "@/components/ui/alert-dialog";

const DeleteConfirmationDialog = ({ campaignName, onCancel, onConfirm, loading }) => {
  return (
    <AlertContent className="bg-card border-border text-card-foreground">
      <AlertHeader>
        <AlertTitle>Delete Campaign: {campaignName}?</AlertTitle>
        <AlertDescription className="text-muted-foreground">
          This action cannot be undone. This will permanently delete the campaign and its associated data.
        </AlertDescription>
      </AlertHeader>
      <AlertFooter>
        <AlertDialogCancel asChild>
          <Button variant="outline" className="btn-minimal" onClick={onCancel}>Cancel</Button>
        </AlertDialogCancel>
        <AlertDialogAction asChild>
          <Button variant="destructive" onClick={onConfirm} disabled={loading}>
            {loading ? "Deleting..." : "Confirm Delete"}
          </Button>
        </AlertDialogAction>
      </AlertFooter>
    </AlertContent>
  );
};

export default DeleteConfirmationDialog;