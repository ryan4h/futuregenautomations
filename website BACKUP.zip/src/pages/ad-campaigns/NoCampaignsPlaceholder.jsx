import React from "react";
import { Button } from "@/components/ui/button";
import { Megaphone, PlusCircle } from "lucide-react";

const NoCampaignsPlaceholder = ({ onNewCampaign }) => {
  return (
    <div className="text-center py-12">
      <Megaphone className="mx-auto h-12 w-12 text-muted-foreground" />
      <h3 className="mt-2 text-xl font-semibold text-foreground">No ad campaigns yet</h3>
      <p className="mt-1 text-sm text-muted-foreground">
        Start by creating your first advertising campaign.
      </p>
      <div className="mt-6">
        <Button variant="outline" className="btn-minimal" onClick={onNewCampaign}>
          <PlusCircle className="mr-2 h-4 w-4" /> New Campaign
        </Button>
      </div>
    </div>
  );
};

export default NoCampaignsPlaceholder;