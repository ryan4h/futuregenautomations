import React, {useState} from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Edit2, Trash2, Eye, ExternalLink } from "lucide-react";
import { AlertDialogTrigger } from "@/components/ui/alert-dialog";
import CampaignDetailsDialog from "./CampaignDetailsDialog"; 

const CampaignCard = ({ campaign, onEdit, onDelete }) => {
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);

  const getStatusVariant = (status) => {
    switch (status?.toLowerCase()) {
      case 'active': return 'default';
      case 'paused': return 'secondary';
      case 'completed': return 'success';
      default: return 'outline';
    }
  };

  const getStatusColorClasses = (status) => {
     switch (status?.toLowerCase()) {
      case 'active': return "bg-green-500/20 text-green-400 border-green-500/30";
      case 'paused': return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30";
      case 'completed': return "bg-blue-500/20 text-blue-400 border-blue-500/30";
      default: return "bg-gray-500/20 text-gray-400 border-gray-500/30";
    }
  };
  
  const getPlatformLink = (platform) => {
    platform = platform?.toLowerCase();
    if (platform?.includes("google")) return "https://ads.google.com/";
    if (platform?.includes("meta") || platform?.includes("facebook") || platform?.includes("instagram")) return "https://www.facebook.com/adsmanager/";
    if (platform?.includes("linkedin")) return "https://www.linkedin.com/campaignmanager/";
    if (platform?.includes("twitter") || platform?.includes("x ads")) return "https://ads.twitter.com/";
    return null;
  };

  const platformLink = getPlatformLink(campaign.platform);
  const platformDisplayName = campaign.platform?.replace(" Ads", "")?.replace("Ads", "") || "Platform";

  return (
    <>
      <Card className="bg-card border-border hover:shadow-lg transition-shadow">
        <CardHeader className="flex flex-row justify-between items-start">
          <div>
            <CardTitle className="text-card-foreground">{campaign.campaign_name}</CardTitle>
            <CardDescription className="text-muted-foreground">{campaign.platform}</CardDescription>
          </div>
          <Badge variant={getStatusVariant(campaign.status)} className={getStatusColorClasses(campaign.status)}>
            {campaign.status}
          </Badge>
        </CardHeader>
        <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Budget</p>
            <p className="font-semibold text-card-foreground">${(campaign.budget || 0).toLocaleString()}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Daily Budget</p>
            <p className="font-semibold text-card-foreground">${(campaign.daily_budget || 0).toLocaleString()}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Spend</p>
            <p className="font-semibold text-card-foreground">${(campaign.spent || 0).toLocaleString()}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Conversions</p>
            <p className="font-semibold text-card-foreground">{(campaign.conversions || 0).toLocaleString()}</p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end gap-2 border-t border-border pt-4">
          <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary" onClick={() => setIsDetailsOpen(true)}>
            <Eye className="mr-2 h-4 w-4" /> View Details
          </Button>
          <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary" onClick={onEdit}>
             <Edit2 className="mr-2 h-4 w-4" /> Edit Settings
          </Button>
          {platformLink && (
            <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary" onClick={() => window.open(platformLink, '_blank')}>
              <ExternalLink className="mr-2 h-4 w-4" /> Open {platformDisplayName}
            </Button>
          )}
          <AlertDialogTrigger asChild>
            <Button variant="ghost" size="sm" className="text-destructive hover:bg-destructive/10" onClick={onDelete}>
              <Trash2 className="mr-2 h-4 w-4" /> Delete
            </Button>
          </AlertDialogTrigger>
        </CardFooter>
      </Card>
      <CampaignDetailsDialog
        open={isDetailsOpen}
        onOpenChange={setIsDetailsOpen}
        campaign={campaign}
      />
    </>
  );
};

export default CampaignCard;