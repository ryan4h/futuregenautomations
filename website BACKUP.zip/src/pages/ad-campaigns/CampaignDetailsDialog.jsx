import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { CalendarDays, DollarSign, TrendingUp, Info } from 'lucide-react';

const CampaignDetailsDialog = ({ open, onOpenChange, campaign }) => {
  if (!campaign) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border text-card-foreground sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl">{campaign.campaign_name} Details</DialogTitle>
          <DialogDescription>Platform: {campaign.platform} - Status: {campaign.status}</DialogDescription>
        </DialogHeader>
        <div className="py-4 space-y-4 max-h-[60vh] overflow-y-auto">
          <div className="flex items-center">
            <DollarSign className="h-5 w-5 mr-3 text-primary" />
            <div>
              <p className="text-sm text-muted-foreground">Total Budget</p>
              <p className="font-semibold text-lg">${(campaign.budget || 0).toLocaleString()}</p>
            </div>
          </div>
          <div className="flex items-center">
            <DollarSign className="h-5 w-5 mr-3 text-red-500" />
            <div>
              <p className="text-sm text-muted-foreground">Amount Spent</p>
              <p className="font-semibold text-lg">${(campaign.spent || 0).toLocaleString()}</p>
            </div>
          </div>
          <div className="flex items-center">
            <CalendarDays className="h-5 w-5 mr-3 text-blue-500" />
            <div>
              <p className="text-sm text-muted-foreground">Start Date</p>
              <p className="font-semibold">{campaign.start_date ? new Date(campaign.start_date).toLocaleDateString() : 'N/A'}</p>
            </div>
          </div>
           <div className="flex items-center">
            <CalendarDays className="h-5 w-5 mr-3 text-purple-500" />
            <div>
              <p className="text-sm text-muted-foreground">End Date</p>
              <p className="font-semibold">{campaign.end_date ? new Date(campaign.end_date).toLocaleDateString() : 'Ongoing'}</p>
            </div>
          </div>
          <div className="border-t border-border pt-4 mt-4">
            <h4 className="text-md font-semibold mb-2 text-primary">Placeholder Analytics</h4>
            <p className="text-sm text-muted-foreground mb-1">Daily Spend (Avg): <span className="font-semibold text-card-foreground">$ {( (campaign.spent || 0) / 30 ).toFixed(2)} (mock)</span></p>
            <p className="text-sm text-muted-foreground mb-1">Conversions Today: <span className="font-semibold text-card-foreground">{Math.floor( (campaign.conversions || 0) / 15 )} (mock)</span></p>
            <p className="text-sm text-muted-foreground mb-1">Clicks this Week: <span className="font-semibold text-card-foreground">{Math.floor( (campaign.clicks || 0) / 4 )} (mock)</span></p>
            <div className="mt-2 p-3 bg-muted/50 rounded-md text-xs text-muted-foreground italic">
              <Info className="inline h-4 w-4 mr-1 text-primary" />
              Detailed, real-time analytics and date-stamped performance data will be available upon API integration with {campaign.platform}.
            </div>
          </div>
          
        </div>
        <DialogFooter>
          <Button variant="outline" className="btn-minimal" onClick={() => onOpenChange(false)}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default CampaignDetailsDialog;