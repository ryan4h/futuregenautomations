import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/lib/supabaseClient";
import { UserPlus, Mail, Briefcase, Building, User, Settings2 } from "lucide-react";

const serviceOptions = [
  "AI Agents",
  "Ad Management",
  "Lead Generation",
  "Website Development"
];

const SignUpPage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    fullName: "",
    companyEmail: "",
    companyName: "",
    position: "",
    serviceInterest: "",
  });
  const [loading, setLoading] = useState(false);
  const backgroundVideoUrl = "https://ryan4h.github.io/luxury-home-renovations/scifibackground.mp4"; 

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleServiceChange = (value) => {
    setFormData({ ...formData, serviceInterest: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { error } = await supabase.from("contact_requests").insert([
        {
          full_name: formData.fullName,
          company_email: formData.companyEmail,
          company_name: formData.companyName,
          position: formData.position,
          service_interest: formData.serviceInterest,
          status: "new",
        },
      ]);

      if (error) throw error;

      toast({
        title: "Request Submitted",
        description: "Our sales team will contact you shortly. Thank you!",
      });
      setFormData({ fullName: "", companyEmail: "", companyName: "", position: "", serviceInterest: "" });
    } catch (error) {
      toast({
        title: "Submission Failed",
        description: error.message || "Could not submit your request. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative flex items-center justify-center min-h-screen w-full bg-black text-foreground overflow-hidden py-10">
       <video 
        autoPlay 
        loop 
        muted 
        playsInline
        className="video-background"
        src={backgroundVideoUrl}
      >
        Your browser does not support the video tag.
      </video>
      <div className="absolute inset-0 bg-black/70 z-0"></div>

      <motion.div 
        className="relative z-10 w-full max-w-md p-8 sm:p-10 space-y-6 bg-transparent border-2 border-white rounded-xl shadow-2xl glassmorphism-card"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="text-center">
          <motion.h1 
            className="text-3xl font-bold text-white mb-2" 
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            Request Access
          </motion.h1>
          <p className="text-gray-300 text-sm">
            Fill out the form below and our sales team will get in touch.
          </p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-5">
          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            <Label htmlFor="fullName" className="text-gray-200 text-sm">Full Name</Label>
            <div className="relative mt-1">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                id="fullName"
                name="fullName"
                type="text"
                value={formData.fullName}
                onChange={handleChange}
                placeholder="John Doe"
                required
                className="pl-10 bg-white/5 border-white/30 text-white placeholder:text-gray-400 focus:border-primary focus:ring-primary py-2.5 text-sm"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.5 }}
          >
            <Label htmlFor="companyEmail" className="text-gray-200 text-sm">Company Email</Label>
            <div className="relative mt-1">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                id="companyEmail"
                name="companyEmail"
                type="email"
                value={formData.companyEmail}
                onChange={handleChange}
                placeholder="you@company.com"
                required
                className="pl-10 bg-white/5 border-white/30 text-white placeholder:text-gray-400 focus:border-primary focus:ring-primary py-2.5 text-sm"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            <Label htmlFor="companyName" className="text-gray-200 text-sm">Company Name</Label>
            <div className="relative mt-1">
              <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                id="companyName"
                name="companyName"
                type="text"
                value={formData.companyName}
                onChange={handleChange}
                placeholder="Your Company Inc."
                required
                className="pl-10 bg-white/5 border-white/30 text-white placeholder:text-gray-400 focus:border-primary focus:ring-primary py-2.5 text-sm"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.5 }}
          >
            <Label htmlFor="position" className="text-gray-200 text-sm">Your Position</Label>
            <div className="relative mt-1">
              <Briefcase className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                id="position"
                name="position"
                type="text"
                value={formData.position}
                onChange={handleChange}
                placeholder="e.g., Marketing Manager"
                required
                className="pl-10 bg-white/5 border-white/30 text-white placeholder:text-gray-400 focus:border-primary focus:ring-primary py-2.5 text-sm"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.7, duration: 0.5 }}
          >
            <Label htmlFor="serviceInterest" className="text-gray-200 text-sm">Service of Interest</Label>
            <div className="relative mt-1">
              <Settings2 className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Select value={formData.serviceInterest} onValueChange={handleServiceChange}>
                <SelectTrigger 
                  id="serviceInterest" 
                  className="w-full pl-10 bg-white/5 border-white/30 text-white placeholder:text-gray-400 focus:border-primary focus:ring-primary py-2.5 text-sm"
                >
                  <SelectValue placeholder="Select a service" />
                </SelectTrigger>
                <SelectContent className="bg-card border-white/30 text-foreground">
                  {serviceOptions.map(option => (
                    <SelectItem key={option} value={option} className="hover:bg-white/10">
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </motion.div>

          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.5 }}
          >
            <Button type="submit" variant="outline" className="w-full text-base py-2.5" disabled={loading}>
              {loading ? "Submitting..." : <><UserPlus className="mr-2 h-4 w-4" /> Contact Sales</>}
            </Button>
          </motion.div>
        </form>
        <p className="text-center text-xs text-gray-300">
          Already have access?{" "}
          <a
            href="/login"
            className="font-medium text-primary hover:underline"
            onClick={(e) => { e.preventDefault(); navigate("/login");}}
          >
            Login Here
          </a>
        </p>
      </motion.div>
    </div>
  );
};

export default SignUpPage;