import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { DollarSign, Package, CalendarDays, AlertTriangle, Info } from "lucide-react";

const SubscriptionSummary = ({ subscription, isLoading }) => { 
  if (isLoading) {
    return (
      <Card className="mb-6 bg-card border-border animate-pulse">
        <CardHeader>
          <div className="h-6 bg-muted rounded w-3/4"></div>
          <div className="h-4 bg-muted rounded w-1/2 mt-1"></div>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="h-16 bg-muted rounded"></div>
          <div className="h-16 bg-muted rounded"></div>
          <div className="h-16 bg-muted rounded"></div>
        </CardContent>
      </Card>
    );
  }

  const displayData = subscription || {};
  const activeAgents = displayData.active_agent_count || 0;

  // Scenario: User has no active agents AND no tier name (or it's a placeholder)
  if (activeAgents === 0 && (!displayData.current_tier_name || ['N/A', 'Pending Setup'].includes(displayData.current_tier_name))) {
     return (
        <Card className="mb-6 bg-accent border-primary/20">
            <CardHeader>
                <CardTitle className="text-accent-foreground flex items-center"><Info className="h-5 w-5 mr-2 text-blue-500"/>No Active Subscription</CardTitle>
                <CardDescription className="text-muted-foreground">
                    You currently have no active agents. Add agents from the marketplace to get started with a subscription.
                </CardDescription>
            </CardHeader>
        </Card>
     );
  }
  
  // Scenario: User has active agents but tier name is still pending/placeholder
  // This indicates subscription exists but tier specific details might not be fully synced/determined yet.
  if (activeAgents > 0 && (!displayData.current_tier_name || ['N/A', 'Pending Setup'].includes(displayData.current_tier_name))) { 
    return (
        <Card className="mb-6 bg-card border-border">
            <CardHeader>
                <CardTitle className="text-card-foreground flex items-center"><AlertTriangle className="h-5 w-5 mr-2 text-amber-500"/>Subscription Tier Syncing</CardTitle>
                <CardDescription className="text-muted-foreground">
                    Your subscription details for {activeAgents} active agent(s) are updating. Tier information should appear shortly.
                    Manage your subscription in the Stripe Customer Portal if needed.
                </CardDescription>
            </CardHeader>
        </Card>
    );
  }
  
  // Scenario: User has a fully determined subscription (even if 0 agents, but has a past tier)
  // Or has active agents and a determined tier.
  if (!displayData.current_tier_name) { // If after all checks, still no tier name, show a generic message.
      return (
        <Card className="mb-6 bg-card border-border">
            <CardHeader>
                <CardTitle className="text-card-foreground flex items-center"><Info className="h-5 w-5 mr-2 text-blue-400"/>Subscription Information</CardTitle>
                <CardDescription className="text-muted-foreground">
                    Loading your subscription details. If this persists, please contact support or check the Stripe Customer Portal.
                </CardDescription>
            </CardHeader>
        </Card>
      );
  }


  return (
    <Card className="mb-6 bg-gradient-to-r from-primary/10 via-accent/5 to-background border-primary/30 shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-primary">Your Subscription</CardTitle>
        <CardDescription className="text-muted-foreground">
          Current status of your AI agent subscription.
        </CardDescription>
      </CardHeader>
      <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-x-6 gap-y-4">
        <div className="flex items-center space-x-3 p-3 bg-card rounded-md border border-border">
          <DollarSign className="h-8 w-8 text-green-500" />
          <div>
            <p className="text-xs text-muted-foreground">Monthly Rate</p>
            <p className="text-lg font-semibold text-card-foreground">${parseFloat(displayData.current_tier_monthly_rate || 0).toFixed(2)}</p>
          </div>
        </div>
        <div className="flex items-center space-x-3 p-3 bg-card rounded-md border border-border">
          <Package className="h-8 w-8 text-blue-500" />
          <div>
            <p className="text-xs text-muted-foreground">Tier / Active Agents</p>
            <p className="text-lg font-semibold text-card-foreground">{displayData.current_tier_name} ({activeAgents})</p>
          </div>
        </div>
        <div className="flex items-center space-x-3 p-3 bg-card rounded-md border border-border">
          <CalendarDays className="h-8 w-8 text-purple-500" />
          <div>
            <p className="text-xs text-muted-foreground">Next Billing Date</p>
            <p className="text-lg font-semibold text-card-foreground">
              {displayData.next_billing_date ? new Date(displayData.next_billing_date).toLocaleDateString() : 'N/A'}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SubscriptionSummary;