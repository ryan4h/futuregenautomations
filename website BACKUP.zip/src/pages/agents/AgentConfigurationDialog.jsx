import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";

const formatTime12Hour = (hour, minute) => {
  const h = hour % 12 || 12;
  const m = minute.toString().padStart(2, '0');
  const ampm = hour < 12 || hour === 24 ? 'AM' : 'PM';
  if (hour === 24 && minute === 0) return '12:00 AM';
  return `${h.toString().padStart(2, '0')}:${m} ${ampm}`;
};

const generateStandardTimeSlots = () => {
  const slots = [];
  // From 12 AM to 11:30 PM
  for (let h = 0; h < 24; h++) { 
    for (let m = 0; m < 60; m += 30) {
      const value24Hour = `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
      const display12Hour = formatTime12Hour(h, m);
      slots.push({ value: value24Hour, display: display12Hour });
    }
  }
  // Ensure chronological order, especially if generation logic changes
  slots.sort((a,b) => a.value.localeCompare(b.value));
  return slots;
};

const timeSlots = generateStandardTimeSlots();


const AgentConfigurationDialog = ({ open, onOpenChange, agent, onSave, toast }) => {
  const [configData, setConfigData] = useState({
    customInstructions: "",
    apiEndpoint: "",
    dailyStartTime: "09:00", 
    dailyEndTime: "17:00", 
  });

  useEffect(() => {
    if (agent) {
      const existingConfig = agent.config_details || {};
      setConfigData({ 
        customInstructions: existingConfig.customInstructions || agent.custom_instructions || "",
        apiEndpoint: existingConfig.apiEndpoint || "",
        dailyStartTime: existingConfig.dailyStartTime || "09:00",
        dailyEndTime: existingConfig.dailyEndTime || "17:00",
      });
    } else {
      setConfigData({
        customInstructions: "",
        apiEndpoint: "",
        dailyStartTime: "09:00",
        dailyEndTime: "17:00",
      });
    }
  }, [agent]);

  const handleChange = (e) => {
    setConfigData({ ...configData, [e.target.name]: e.target.value });
  };

  const handleSelectChange = (name, value) => {
    setConfigData({ ...configData, [name]: value });
  };

  const handleSave = async () => {
    if (toast) {
        toast({ title: "Configuration Updated", description: `Settings for ${agent.agent_name} were saved.` });
    }
    onSave(agent.assigned_agent_id, configData);
    onOpenChange(false);
  };

  if (!agent) return null;

  // Create a sub-selection for display, e.g., 9 AM to 1 PM (13:00)
  const defaultStartTimeIndex = timeSlots.findIndex(slot => slot.value === "09:00");
  const defaultEndTimeIndex = timeSlots.findIndex(slot => slot.value === "13:00");
  
  // Ensure indices are valid
  const visibleStartTimeIndex = defaultStartTimeIndex !== -1 ? defaultStartTimeIndex : 0;
  const visibleEndTimeIndex = defaultEndTimeIndex !== -1 ? defaultEndTimeIndex : timeSlots.length -1;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border text-card-foreground sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Configure {agent.agent_name}</DialogTitle>
          <DialogDescription>
            Adjust settings and operational times for this AI agent.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 grid grid-cols-1 gap-6">
          <div>
            <Label htmlFor="customInstructions" className="text-muted-foreground">Custom Instructions</Label>
            <Textarea
              id="customInstructions"
              name="customInstructions"
              value={configData.customInstructions || ""}
              onChange={handleChange}
              placeholder="e.g., Always respond in a friendly tone. Prioritize urgent requests."
              className="mt-1 bg-input border-border min-h-[100px]"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="dailyStartTime" className="text-muted-foreground">Daily Start Time</Label>
              <Select 
                name="dailyStartTime" 
                value={configData.dailyStartTime} 
                onValueChange={(value) => handleSelectChange("dailyStartTime", value)}
              >
                <SelectTrigger className="mt-1 bg-input border-border">
                  <SelectValue placeholder="Select start time" />
                </SelectTrigger>
                <SelectContent>
                  <ScrollArea className="h-[200px]">
                    {timeSlots.map(slot => <SelectItem key={`start-${slot.value}`} value={slot.value}>{slot.display}</SelectItem>)}
                  </ScrollArea>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="dailyEndTime" className="text-muted-foreground">Daily End Time</Label>
              <Select 
                name="dailyEndTime" 
                value={configData.dailyEndTime} 
                onValueChange={(value) => handleSelectChange("dailyEndTime", value)}
              >
                <SelectTrigger className="mt-1 bg-input border-border">
                  <SelectValue placeholder="Select end time" />
                </SelectTrigger>
                <SelectContent>
                  <ScrollArea className="h-[200px]">
                    <SelectItem value="None">None (Runs 24/7)</SelectItem>
                    {timeSlots.map(slot => <SelectItem key={`end-${slot.value}`} value={slot.value}>{slot.display}</SelectItem>)}
                  </ScrollArea>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="apiEndpoint" className="text-muted-foreground">API Endpoint (Optional)</Label>
            <Textarea
              id="apiEndpoint"
              name="apiEndpoint"
              value={configData.apiEndpoint || ""}
              onChange={handleChange}
              placeholder="https://api.example.com/agent-hook"
              className="mt-1 bg-input border-border min-h-[60px]"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" className="btn-minimal" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button className="btn-primary" onClick={handleSave}>Save Configuration</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AgentConfigurationDialog;