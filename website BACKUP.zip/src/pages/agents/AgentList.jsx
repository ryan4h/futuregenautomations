import React from "react";
import AgentCard from "./AgentCard";
import { BarChartHorizontalBig, CheckCircle2, Edit, Mail as MailIcon, FileText } from "lucide-react";

const AgentList = ({ agents, zapierTaskData, onDeactivateOrActivate, onConfigure }) => {
  const combinedAgentData = agents.map(agent => {
    const tasks = zapierTaskData.find(task => task.agent_name === agent.agent_name);
    
    let agentSpecificTaskData = {
      metric1_name: "Tasks Outgoing", metric1_val: tasks?.tasks_outgoing || 0, metric1_icon: <BarChartHorizontalBig className="h-4 w-4 mr-2 text-primary"/>,
      metric2_name: "Tasks Completed", metric2_val: tasks?.tasks_completed || 0, metric2_icon: <CheckCircle2 className="h-4 w-4 mr-2 text-green-500"/>,
    };

    if (agent.agent_name === "Google Review Agent") {
      agentSpecificTaskData = {
        metric1_name: "Reviews Req.", metric1_val: tasks?.reviews_requested || 0, metric1_icon: <Edit className="h-4 w-4 mr-2 text-yellow-500"/>,
        metric2_name: "Emails Sent", metric2_val: tasks?.emails_sent || 0, metric2_icon: <MailIcon className="h-4 w-4 mr-2 text-purple-500"/>,
      };
    } else if (agent.agent_name === "Voice to Invoice Agent") {
      agentSpecificTaskData = {
        metric1_name: "Invoices Created", metric1_val: tasks?.tasks_completed || 0,
        metric1_icon: <FileText className="h-4 w-4 mr-2 text-blue-500"/>,
        metric2_name: "Outgoing (Drafts)", metric2_val: tasks?.tasks_outgoing || 0,
        metric2_icon: <BarChartHorizontalBig className="h-4 w-4 mr-2 text-primary"/>,
      };
    }
    
    return {
      ...agent,
      taskAnalytics: agentSpecificTaskData,
      // iconName is already part of agent object from dataFetchers
    };
  });

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {combinedAgentData.map((agent) => (
        <AgentCard 
          key={agent.assigned_agent_id} 
          agent={agent} 
          onDeactivateOrActivate={onDeactivateOrActivate}
          onConfigure={onConfigure}
        />
      ))}
    </div>
  );
};

export default AgentList;