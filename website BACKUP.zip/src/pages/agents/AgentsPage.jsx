import React, { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabaseClient";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, AlertTriangle } from "lucide-react";

import AgentPageHeader from "./components/AgentPageHeader";
import SubscriptionSummary from "./components/SubscriptionSummary";
import AgentList from "./components/AgentList"; 
import NoAgentsPlaceholder from "./components/NoAgentsPlaceholder";
import AgentActivationDialog from "./components/AgentActivationDialog";
import AgentDeactivationDialog from "./components/AgentDeactivationDialog";
import AgentDowngradeDialog from "./components/AgentDowngradeDialog";
import AgentConfigurationDialog from "./AgentConfigurationDialog";

import { 
  fetchUserAssignedAgents, 
  fetchAutomationTaskDataForAgents, // Renamed
  fetchUserSubscriptionDetails,
  fetchSubscriptionTiers
} from "./services/agentDataService";
import { 
  activateAgent, 
  deactivateAgent,
  updateAgentConfiguration
} from "./services/agentActionService";


const AgentsPage = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null); // Added for stripe_customer_id
  const [assignedAgents, setAssignedAgents] = useState([]);
  const [automationTaskData, setAutomationTaskData] = useState([]); // Renamed
  const [subscriptionDetails, setSubscriptionDetails] = useState(null);
  const [allSubscriptionTiers, setAllSubscriptionTiers] = useState([]);
  
  const [isLoading, setIsLoading] = useState(true);
  const [supabaseError, setSupabaseError] = useState(!supabase);

  const [isActivationDialogOpen, setIsActivationDialogOpen] = useState(false);
  const [isDeactivationDialogOpen, setIsDeactivationDialogOpen] = useState(false);
  const [isDowngradeDialogOpen, setIsDowngradeDialogOpen] = useState(false);
  const [isConfigDialogOpen, setIsConfigDialogOpen] = useState(false);
  
  const [agentToProcess, setAgentToProcess] = useState(null);
  const [activationRequiresUpgrade, setActivationRequiresUpgrade] = useState(false);
  const [newTotalActiveAgents, setNewTotalActiveAgents] = useState(0);
  const [isProcessingAction, setIsProcessingAction] = useState(false);
  const [isPortalLoading, setIsPortalLoading] = useState(false);

  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");

  const activeAgentsCount = assignedAgents.filter(agent => agent.status === 'active').length;

  const loadInitialData = useCallback(async (userId) => {
    if (!userId || !supabase) {
      setIsLoading(false);
      setSupabaseError(true);
      return;
    }
    setSupabaseError(false);
    setIsLoading(true);
    try {
      const { data: profileData, error: profileError } = await supabase
        .from('user_profiles')
        .select('stripe_customer_id')
        .eq('user_id', userId)
        .single();

      if (profileError && profileError.code !== 'PGRST116') {
         console.error("Error fetching user profile for AgentsPage:", profileError);
      } else {
        setUserProfile(profileData);
      }

      const [agents, tasks, subscription, tiers] = await Promise.all([
        fetchUserAssignedAgents(userId, toast),
        fetchAutomationTaskDataForAgents(userId, toast), // Renamed
        fetchUserSubscriptionDetails(userId, toast),
        fetchSubscriptionTiers(toast)
      ]);
      setAssignedAgents(agents);
      setAutomationTaskData(tasks); // Renamed
      setSubscriptionDetails(subscription);
      setAllSubscriptionTiers(tiers);
    } catch (error) {
      toast({ title: "Error loading page data", description: error.message, variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    if (!supabase) {
      setIsLoading(false);
      setSupabaseError(true);
      return;
    }
    setSupabaseError(false);
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user || null);
      if (session?.user) {
        loadInitialData(session.user.id);
      } else {
        setIsLoading(false);
      }
    };
    getSession();
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null);
      if (session?.user) {
        loadInitialData(session.user.id);
      } else {
        setAssignedAgents([]);
        setAutomationTaskData([]); // Renamed
        setSubscriptionDetails(null);
        setAllSubscriptionTiers([]);
        setUserProfile(null);
        setIsLoading(false);
      }
    });
    return () => authListener?.subscription.unsubscribe();
  }, [loadInitialData]);

  const handleDeactivateOrActivate = async (agent, actionType) => {
    setAgentToProcess(agent);
    if (actionType === 'deactivate') {
      setIsDeactivationDialogOpen(true);
    } else if (actionType === 'active') {
      if (!subscriptionDetails || !allSubscriptionTiers.length) {
        toast({ title: "Subscription Info Missing", description: "Cannot determine tier limits. Please check your billing page or try again shortly.", variant: "warning" });
        return;
      }
      
      const currentTierName = subscriptionDetails?.current_tier_name;
      const currentTier = allSubscriptionTiers.find(tier => tier.tier_name === currentTierName);
      
      if (!currentTier) {
        setActivationRequiresUpgrade(true); // Assume upgrade if current tier can't be found
        setNewTotalActiveAgents(activeAgentsCount + 1);
        setIsActivationDialogOpen(true);
        return;
      }
      
      const projectedActiveAgents = activeAgentsCount + 1;
      setNewTotalActiveAgents(projectedActiveAgents);

      if (projectedActiveAgents > currentTier.agent_limit_max) {
        setActivationRequiresUpgrade(true);
      } else {
        setActivationRequiresUpgrade(false);
      }
      setIsActivationDialogOpen(true);
    }
  };

  const confirmActivation = async () => {
    if (!agentToProcess || !user) return;
    setIsProcessingAction(true);
    const success = await activateAgent(agentToProcess.assigned_agent_id, user.id, toast, agentToProcess, () => loadInitialData(user.id));
    if (success) {
      // loadInitialData is already called by callback in activateAgent
    }
    setIsProcessingAction(false);
    setIsActivationDialogOpen(false);
    setAgentToProcess(null);
  };

  const confirmDeactivation = async () => {
    if (!agentToProcess || !user) return;
    setIsProcessingAction(true);
    const success = await deactivateAgent(agentToProcess.assigned_agent_id, user.id, toast, agentToProcess, () => loadInitialData(user.id));
    if (success) {
      // loadInitialData is already called by callback in deactivateAgent
    }
    setIsProcessingAction(false);
    setIsDeactivationDialogOpen(false);
    setAgentToProcess(null);
  };
  
  const handleStripePortalForDowngrade = async () => {
    if (!user) {
      toast({ title: "Not Authenticated", description: "Please log in.", variant: "destructive" });
      return;
    }
    // User profile check is now handled by the Edge Function using auth context.
    setIsPortalLoading(true);
    try {
      const { data, error: functionError } = await supabase.functions.invoke('create-stripe-portal-session', {
        body: JSON.stringify({ return_url: window.location.origin + '/agents' }),
      });

      if (functionError) {
         const errorBody = functionError.context ? await functionError.context.json() : { error: functionError.message };
         throw new Error(errorBody.error || "Failed to create portal session.");
      }
      
      if (data && data.portalUrl) {
        window.location.href = data.portalUrl;
      } else {
        throw new Error("Failed to retrieve Stripe portal URL.");
      }
    } catch (error) {
      toast({ title: "Portal Access Error", description: error.message, variant: "destructive" });
    } finally {
      setIsPortalLoading(false);
      setIsDowngradeDialogOpen(false); 
      setIsDeactivationDialogOpen(false); 
    }
  };

  const handleConfigureAgent = (agent) => {
    setAgentToProcess(agent);
    setIsConfigDialogOpen(true);
  };

  const handleSaveConfiguration = async (assignedAgentId, configData) => { // Changed to receive ID directly
    if (!assignedAgentId || !user) return; // Use assignedAgentId directly
    setIsProcessingAction(true);
    const agentNameForToast = agentToProcess?.agent_name || 'Agent';
    const success = await updateAgentConfiguration(assignedAgentId, user.id, configData, toast, agentNameForToast, () => loadInitialData(user.id));
    if (success) {
      // loadInitialData is called by callback
    }
    setIsProcessingAction(false);
    setIsConfigDialogOpen(false);
    setAgentToProcess(null);
  };

  const filteredAgents = assignedAgents.filter(agent => {
    const searchMatch = agent.agent_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        (agent.description && agent.description.toLowerCase().includes(searchTerm.toLowerCase()));
    const statusMatch = statusFilter === 'all' || agent.status === statusFilter;
    const categoryMatch = categoryFilter === 'all' || agent.category === categoryFilter;
    return searchMatch && statusMatch && categoryMatch;
  });
  
  const uniqueCategories = [...new Set(assignedAgents.map(agent => agent.category).filter(Boolean))];

  if (isLoading) {
    return (
      <div className="container py-8 flex justify-center items-center min-h-[calc(100vh-150px)]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="ml-4 text-lg">Loading your agents...</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="container py-8 bg-background text-foreground"
    >
      {supabaseError && (
        <div className="mb-6 bg-destructive/20 border border-destructive text-destructive-foreground p-4 rounded-md text-sm flex items-center gap-3">
          <AlertTriangle className="h-5 w-5 flex-shrink-0" />
          <span>Database is not connected. Agent management features may be limited.</span>
        </div>
      )}

      <AgentPageHeader
        activeAgentsCount={activeAgentsCount}
        totalAgentsCount={assignedAgents.length}
        onAddNewAgent={() => navigate("/products")}
        searchTerm={searchTerm}
        onSearchTermChange={setSearchTerm}
        statusFilter={statusFilter}
        onStatusFilterChange={setStatusFilter}
        categoryFilter={categoryFilter}
        onCategoryFilterChange={setCategoryFilter}
        availableCategories={uniqueCategories}
      />

      <SubscriptionSummary 
        subscription={subscriptionDetails}
        isLoading={isLoading} // Pass isLoading to SubscriptionSummary
      />

      {filteredAgents.length === 0 && !isLoading && !supabaseError ? (
        <NoAgentsPlaceholder onBrowseAgents={() => navigate("/products")} />
      ) : !supabaseError ? (
        <AgentList 
          agents={filteredAgents} 
          automationTaskData={automationTaskData} // Renamed
          onDeactivateOrActivate={handleDeactivateOrActivate}
          onConfigure={handleConfigureAgent}
        />
      ) : null}
      
      <AgentActivationDialog
        open={isActivationDialogOpen}
        onOpenChange={setIsActivationDialogOpen}
        agentName={agentToProcess?.agent_name}
        isUpgradeRequired={activationRequiresUpgrade}
        newTotalActiveAgents={newTotalActiveAgents}
        onConfirm={confirmActivation}
        onNavigateToBilling={() => navigate("/billing")}
        onCancel={() => { setIsActivationDialogOpen(false); setAgentToProcess(null); }}
        isLoadingConfirm={isProcessingAction}
      />

      <AgentDeactivationDialog
        open={isDeactivationDialogOpen}
        onOpenChange={setIsDeactivationDialogOpen}
        agentName={agentToProcess?.agent_name}
        onConfirm={confirmDeactivation}
        onCancel={() => { setIsDeactivationDialogOpen(false); setAgentToProcess(null); }}
        isLoading={isProcessingAction}
      />
      
      <AgentDowngradeDialog
        open={isDowngradeDialogOpen} 
        onOpenChange={setIsDowngradeDialogOpen}
        agentName={agentToProcess?.agent_name} 
        isBillingCycleToday={
            subscriptionDetails?.next_billing_date ? 
            new Date(subscriptionDetails.next_billing_date).toDateString() === new Date().toDateString() 
            : false
        }
        nextBillingDate={subscriptionDetails?.next_billing_date}
        onConfirmDeactivation={confirmDeactivation} 
        onManageSubscription={handleStripePortalForDowngrade}
        onCancel={() => { setIsDowngradeDialogOpen(false); setAgentToProcess(null); }}
        isLoading={isProcessingAction || isPortalLoading}
      />

      <AgentConfigurationDialog
        open={isConfigDialogOpen}
        onOpenChange={setIsConfigDialogOpen}
        agent={agentToProcess}
        onSave={(assigned_agent_id, configData) => handleSaveConfiguration(assigned_agent_id, configData)} // Updated to pass ID
        toast={toast} // Pass toast
      />

    </motion.div>
  );
};

export default AgentsPage;