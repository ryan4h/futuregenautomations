import React from "react";
import { Button } from "@/components/ui/button";
import { Bot } from "lucide-react";

const NoAgentsPlaceholder = ({ onBrowse }) => {
  return (
    <div className="text-center py-12 bg-card border border-border rounded-lg shadow-sm">
      <Bot className="mx-auto h-16 w-16 text-muted-foreground" />
      <h3 className="mt-4 text-xl font-semibold text-card-foreground">No AI agents assigned yet</h3>
      <p className="mt-2 text-sm text-muted-foreground">
        Explore our marketplace to find agents that can automate your tasks.
      </p>
      <div className="mt-6">
        <Button variant="outline" className="btn-minimal" onClick={onBrowse}>
          Browse AI Agents
        </Button>
      </div>
    </div>
  );
};

export default NoAgentsPlaceholder;