import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Settings, Trash2, PlusCircle, Edit, Users, Mail as MailIcon, FileText, Star, Calendar, Brain, DollarSign, CheckCircle2, BarChartHorizontalBig } from "lucide-react";

const iconMap = {
  Users: <Users className="h-6 w-6 text-primary" />,
  Mail: <MailIcon className="h-6 w-6 text-primary" />,
  FileText: <FileText className="h-6 w-6 text-primary" />,
  Star: <Star className="h-6 w-6 text-primary" />,
  Calendar: <Calendar className="h-6 w-6 text-primary" />,
  Brain: <Brain className="h-6 w-6 text-primary" />,
  DollarSign: <DollarSign className="h-6 w-6 text-primary" />,
  Zap: <BarChartHorizontalBig className="h-6 w-6 text-primary" />,
  Phone: <BarChartHorizontalBig className="h-6 w-6 text-primary" />,
  Default: <BarChartHorizontalBig className="h-6 w-6 text-primary" />
};


const AgentCard = ({ agent, onDeactivateOrActivate, onConfigure }) => {
  let statusVariant = "secondary";
  if (agent.status === "active") statusVariant = "success";
  else if (agent.status === "inactive") statusVariant = "outline";

  const displayIcon = agent.iconName && iconMap[agent.iconName] ? iconMap[agent.iconName] : iconMap.Default;

  return (
    <Card className="bg-card border-border hover:shadow-lg transition-shadow flex flex-col h-full">
      <CardHeader className="border-b border-border pb-4">
        <div className="flex justify-between items-start mb-2">
           {displayIcon}
          <Badge variant={statusVariant} className="text-xs">
             {agent.status.charAt(0).toUpperCase() + agent.status.slice(1)}
          </Badge>
        </div>
        <CardTitle className="text-card-foreground text-lg leading-tight">{agent.agent_name}</CardTitle>
        <CardDescription className="text-muted-foreground text-xs h-10 overflow-y-auto pt-1">
          {agent.description || "No description available."}
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-grow space-y-2 py-4">
        <p className="text-xs text-muted-foreground">Category: {agent.category || 'N/A'}</p>
        
        {agent.taskAnalytics && (
          <div className="pt-2 border-t border-border mt-2">
            <h4 className="text-xs font-semibold text-muted-foreground mb-1 uppercase">Key Metrics</h4>
            <div className="flex items-center text-sm text-card-foreground">
              {agent.taskAnalytics.metric1_icon}
              <span>{agent.taskAnalytics.metric1_name}: {agent.taskAnalytics.metric1_val}</span>
            </div>
            <div className="flex items-center text-sm text-card-foreground">
              {agent.taskAnalytics.metric2_icon}
              <span>{agent.taskAnalytics.metric2_name}: {agent.taskAnalytics.metric2_val}</span>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col sm:flex-row gap-2 items-stretch pt-4 border-t border-border">
        <Button variant="outline" className="btn-minimal flex-1 text-xs" onClick={() => onConfigure(agent)}>
          <Settings className="mr-1.5 h-3.5 w-3.5" /> Configure
        </Button>
        {agent.status === 'active' && (
            <Button variant="outline" className="btn-minimal flex-1 text-xs border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground" onClick={() => onDeactivateOrActivate(agent, 'deactivate')}>
              <Trash2 className="mr-1.5 h-3.5 w-3.5" /> Deactivate
            </Button>
        )}
         {agent.status === 'inactive' && (
           <Button variant="outline" className="btn-minimal flex-1 text-xs border-green-500 text-green-500 hover:bg-green-500 hover:text-white" onClick={() => onDeactivateOrActivate(agent, 'active')}>
            <PlusCircle className="mr-1.5 h-3.5 w-3.5" /> Activate
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default AgentCard;