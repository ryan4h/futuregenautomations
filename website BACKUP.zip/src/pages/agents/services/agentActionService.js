import { supabase } from "@/lib/supabaseClient";

const MAX_MONTHLY_ACTIVATIONS = 3;

const checkAndIncrementActivationCount = async (userId, toast) => {
  const currentMonth = new Date().toISOString().slice(0, 7); 

  const { data: activationRecord, error: fetchError } = await supabase
    .from('user_monthly_agent_activations')
    .select('activation_count')
    .eq('user_id', userId)
    .eq('activation_month', currentMonth)
    .maybeSingle();

  if (fetchError) {
    toast({ title: "Activation Check Error", description: `Failed to check activation limits: ${fetchError.message}`, variant: "destructive" });
    return false; 
  }

  const currentActivations = activationRecord?.activation_count || 0;

  if (currentActivations >= MAX_MONTHLY_ACTIVATIONS) {
    toast({ 
      title: "Activation Limit Reached", 
      description: `You have reached your monthly limit of ${MAX_MONTHLY_ACTIVATIONS} agent reactivations. Please wait until next month or contact support.`, 
      variant: "warning",
      duration: 7000,
    });
    return false; 
  }

  if (activationRecord) {
    const { error: updateError } = await supabase
      .from('user_monthly_agent_activations')
      .update({ activation_count: currentActivations + 1, updated_at: new Date().toISOString() })
      .eq('user_id', userId)
      .eq('activation_month', currentMonth);
    if (updateError) {
      toast({ title: "Activation Error", description: `Failed to update activation count: ${updateError.message}`, variant: "destructive" });
      return false;
    }
  } else {
    const { error: insertError } = await supabase
      .from('user_monthly_agent_activations')
      .insert({ user_id: userId, activation_month: currentMonth, activation_count: 1 });
    if (insertError) {
      toast({ title: "Activation Error", description: `Failed to record activation: ${insertError.message}`, variant: "destructive" });
      return false;
    }
  }
  return true; 
};


const handleAgentStatusChange = async (agent, actionType, userId, toast, refreshDataCallback) => {
  const newStatus = actionType === 'deactivate' ? 'inactive' : 'active';
  const timestampField = newStatus === 'active' ? 'activated_at' : 'deactivated_at';

  if (!agent || !agent.assigned_agent_id) {
    toast({ title: "Action Error", description: "Agent details are missing.", variant: "destructive" });
    return false;
  }
  
  if (!agent.agent_name && newStatus === 'active') {
    toast({ title: "Activation Error", description: "Cannot activate agent without a name. Ensure agent product details are linked.", variant: "destructive" });
    return false;
  }

  if (newStatus === 'active') {
    const canActivate = await checkAndIncrementActivationCount(userId, toast);
    if (!canActivate) {
      return false; 
    }
  }

  const updatePayload = {
    status: newStatus,
    [timestampField]: new Date().toISOString(),
  };

  if (newStatus === 'active') {
    updatePayload.agent_name = agent.agent_name; 
    updatePayload.category = agent.category || 'Default'; 
  }


  const { error } = await supabase
    .from('user_assigned_agents')
    .update(updatePayload)
    .eq('assigned_agent_id', agent.assigned_agent_id)
    .eq('user_id', userId);

  if (error) {
    toast({ title: `Error ${actionType === 'deactivate' ? 'Deactivating' : 'Activating'} Agent`, description: error.message, variant: "destructive" });
    return false;
  } else {
    toast({ title: `Agent ${actionType === 'deactivate' ? 'Deactivated' : 'Activated'}`, description: `${agent.agent_name || 'The agent'} status updated.`, variant: "success" });
    if (refreshDataCallback) refreshDataCallback();
    return true;
  }
};

export const activateAgent = async (assignedAgentId, userId, toast, agentDetails, refreshDataCallback) => {
  const agentForStatusChange = typeof agentDetails === 'object' ? agentDetails : { assigned_agent_id: assignedAgentId, agent_name: 'Agent', category: 'Default' }; 
  if(typeof agentDetails === 'object' && agentDetails.assigned_agent_id !== assignedAgentId){
      agentForStatusChange.assigned_agent_id = assignedAgentId;
  }

  return handleAgentStatusChange(agentForStatusChange, 'active', userId, toast, refreshDataCallback);
};

export const deactivateAgent = async (assignedAgentId, userId, toast, agentDetails, refreshDataCallback) => {
  const agentForStatusChange = typeof agentDetails === 'object' ? agentDetails : { assigned_agent_id: assignedAgentId, agent_name: 'Agent' };
   if(typeof agentDetails === 'object' && agentDetails.assigned_agent_id !== assignedAgentId){
      agentForStatusChange.assigned_agent_id = assignedAgentId;
  }
  return handleAgentStatusChange(agentForStatusChange, 'deactivate', userId, toast, refreshDataCallback);
};

export const updateAgentConfiguration = async (assignedAgentId, userId, configData, toast, agentName, refreshDataCallback) => {
  if (!assignedAgentId) {
    toast({ title: "Configuration Error", description: "Agent ID is missing.", variant: "destructive"});
    return false;
  }
  const { error } = await supabase
    .from('user_assigned_agents')
    .update({ config_details: configData, updated_at: new Date().toISOString() })
    .eq('assigned_agent_id', assignedAgentId)
    .eq('user_id', userId);

  if (error) { 
    toast({ title: "Configuration Error", description: `Failed to save settings: ${error.message}`, variant: "destructive"});
    return false;
  } else { 
    toast({title: "Configuration Updated", description: `Settings for ${agentName || 'the agent'} saved.`, variant: "success"});
    if (refreshDataCallback) refreshDataCallback();
    return true;
  }
};