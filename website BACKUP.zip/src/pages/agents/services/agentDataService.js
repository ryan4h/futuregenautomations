import { supabase } from "@/lib/supabaseClient";

export const fetchUserAssignedAgents = async (userId, toast) => {
  if (!userId) return [];
  const { data, error } = await supabase
    .from('user_assigned_agents')
    .select(`
      assigned_agent_id, 
      user_id,
      agent_product_id,
      agent_name,
      status,
      one_time_purchase_price,
      purchased_at,
      activated_at,
      deactivated_at,
      config_details,
      created_at,
      updated_at,
      category,
      ai_agents_list (
        icon_name,
        description 
      )
    `)
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) {
    toast({ title: "Error fetching agents", description: error.message, variant: "destructive" });
    console.error("Error fetching agents:", error);
    return [];
  }
  
  return (data || []).map(agent => ({
    ...agent,
    description: agent.ai_agents_list?.description || agent.description, 
    iconName: agent.ai_agents_list?.icon_name
  }));
};

export const fetchAutomationTaskDataForAgents = async (userId, toast) => {
  if (!userId) return [];
  const { data, error } = await supabase
    .from('zapier_task_data') // Table name remains zapier_task_data, conceptual change
    .select('agent_name, tasks_outgoing, tasks_completed, emails_sent, reviews_requested, tickets_resolved, leads_captured')
    .eq('user_id', userId);
  
  if (error) {
    toast({ title: "Error fetching task data", description: error.message, variant: "destructive" });
    console.error("Error fetching task data:", error);
    return [];
  }
  return data || [];
};

export const fetchUserSubscriptionDetails = async (userId, toast) => {
  if (!userId) return null;
  const { data, error } = await supabase
    .from('user_agent_subscriptions')
    .select('*, max_agents') // Ensure max_agents is selected
    .eq('user_id', userId)
    .maybeSingle(); 
  
  if (error && error.code !== 'PGRST116') { 
    toast({ title: "Error fetching subscription", description: error.message, variant: "destructive" });
    console.error("Error fetching subscription:", error);
    return null;
  }
  return data;
};

export const checkExistingAgentAssignment = async (userId, agentProductId, toast) => {
  if (!userId || !agentProductId) return null;
  const { data, error, count } = await supabase
    .from('user_assigned_agents')
    .select('assigned_agent_id', { count: 'exact' }) 
    .eq('user_id', userId)
    .eq('agent_product_id', agentProductId)
    .limit(1); 

  if (error) {
    if (toast) { 
        toast({ title: "Error checking agent assignment", description: error.message, variant: "destructive" });
    }
    console.error("Error checking agent assignment:", error);
    return null; 
  }
  return count > 0 ? data[0] : null; 
};

export const fetchSubscriptionTiers = async (toast) => {
  const { data, error } = await supabase
    .from('subscription_tiers')
    .select('*')
    .order('monthly_rate', { ascending: true });

  if (error) {
    toast({ title: "Error fetching subscription tiers", description: error.message, variant: "destructive" });
    console.error("Error fetching subscription tiers:", error);
    return [];
  }
  return data || [];
};