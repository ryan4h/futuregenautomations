import React from "react";
import { Button } from "@/components/ui/button";
import { RefreshCw, PlusCircle } from "lucide-react";

const AgentPageHeader = ({ onRefresh, onAddNew, isLoading }) => {
  return (
    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Your AI Agents</h1>
        <p className="text-muted-foreground">Manage and configure your active AI automations.</p>
      </div>
      <div className="flex gap-2">
         <Button variant="outline" className="btn-minimal" onClick={onRefresh} disabled={isLoading}>
          <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} /> Refresh
        </Button>
        <Button variant="outline" className="btn-minimal" onClick={onAddNew}>
          <PlusCircle className="mr-2 h-4 w-4" /> Add New Agents
        </Button>
      </div>
    </div>
  );
};

export default AgentPageHeader;