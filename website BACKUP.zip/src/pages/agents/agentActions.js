import { supabase } from "@/lib/supabaseClient";

export const handleAgentStatusChange = async (agent, actionType, userId, toast, refreshDataCallback) => {
  const newStatus = actionType === 'deactivate' ? 'inactive' : 'active';
  const timestampField = newStatus === 'active' ? 'activated_at' : 'deactivated_at';

  const { error } = await supabase
    .from('user_assigned_agents')
    .update({ 
      status: newStatus, 
      [timestampField]: new Date().toISOString() 
    })
    .eq('assigned_agent_id', agent.assigned_agent_id)
    .eq('user_id', userId);

  if (error) {
    toast({ title: `Error ${actionType === 'deactivate' ? 'Deactivating' : 'Activating'} Agent`, description: error.message, variant: "destructive" });
  } else {
    toast({ title: `Agent ${actionType === 'deactivate' ? 'Deactivated' : 'Activated'}`, description: `${agent.agent_name} status updated.` });
    if (refreshDataCallback) refreshDataCallback();
  }
};

export const handleAgentConfigurationSave = async (agent, configData, userId, toast, refreshDataCallback) => {
  const { error } = await supabase
    .from('user_assigned_agents')
    .update({ config_details: configData, updated_at: new Date().toISOString() })
    .eq('assigned_agent_id', agent.assigned_agent_id)
    .eq('user_id', userId);

  if (error) { 
    toast({ title: "Configuration Error", description: `Failed to save settings: ${error.message}`, variant: "destructive"});
  } else { 
    toast({title: "Configuration Updated", description: `Settings for ${agent.agent_name} saved.`});
    if (refreshDataCallback) refreshDataCallback();
  }
};