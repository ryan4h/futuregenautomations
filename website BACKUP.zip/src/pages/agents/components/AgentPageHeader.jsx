import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PlusCircle, Search, Filter } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const AgentPageHeader = ({ 
  searchTerm, 
  onSearchTermChange, 
  statusFilter, 
  onStatusFilterChange,
  categoryFilter,
  onCategoryFilterChange,
  availableCategories
}) => {
  const navigate = useNavigate();

  const handleAddNewAgent = () => {
    navigate('/products');
  };

  return (
    <div className="mb-8 p-6 bg-card border border-border rounded-lg shadow-lg">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-primary">My AI Agents</h1>
        <Button 
          onClick={handleAddNewAgent}
          variant="outline"
          className="bg-transparent hover:bg-white/10 text-white border-white hover:border-white transition-colors shadow-md"
        >
          <PlusCircle className="mr-2 h-5 w-5" /> Add New Agent
        </Button>
      </div>
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search agents by name..."
            value={searchTerm}
            onChange={(e) => onSearchTermChange(e.target.value)}
            className="pl-10 bg-input border-border focus:border-primary"
          />
        </div>
        <Select value={statusFilter} onValueChange={onStatusFilterChange}>
          <SelectTrigger className="bg-input border-border focus:border-primary">
            <Filter className="mr-2 h-4 w-4 text-muted-foreground inline-block" />
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
            <SelectItem value="pending_activation">Pending Activation</SelectItem>
          </SelectContent>
        </Select>
        <Select value={categoryFilter} onValueChange={onCategoryFilterChange}>
          <SelectTrigger className="bg-input border-border focus:border-primary">
            <Filter className="mr-2 h-4 w-4 text-muted-foreground inline-block" />
            <SelectValue placeholder="Filter by category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {availableCategories.map(category => (
              <SelectItem key={category} value={category}>{category}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default AgentPageHeader;