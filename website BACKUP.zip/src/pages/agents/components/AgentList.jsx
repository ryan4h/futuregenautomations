import React from 'react';
import AgentCard from '@/pages/agents/AgentCard';

const AgentList = ({ agents, automationTaskData, onDeactivateOrActivate, onConfigure }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
      {agents.map(agent => (
        <AgentCard 
          key={agent.assigned_agent_id} 
          agent={agent} 
          taskData={automationTaskData.find(data => data.agent_name === agent.agent_name)} 
          onDeactivateOrActivate={onDeactivateOrActivate}
          onConfigure={onConfigure}
        />
      ))}
    </div>
  );
};

export default AgentList;