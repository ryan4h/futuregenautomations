import React from "react";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle } from "lucide-react";

const AgentActivationDialog = ({
  open,
  onOpenChange,
  agentName,
  onConfirm,
  onCancel,
  isLoadingConfirm
}) => {

  return (
    <AlertDialog open={open} onOpenChange={(isOpen) => {
      if (!isLoadingConfirm) onOpenChange(isOpen);
    }}>
      <AlertDialogContent className="bg-card border-border text-card-foreground">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-2xl">Confirm Activation</AlertDialogTitle>
          <AlertDialogDescription className="mt-2 text-muted-foreground">
            Are you sure you'd like to activate <strong>{agentName || "this agent"}</strong>? 
            <br />
            You can only activate agents 3 times per month.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="mt-6">
          <Button variant="outline" onClick={onCancel} disabled={isLoadingConfirm} className="text-white border-white hover:bg-white/10">
            Cancel
          </Button>
          <Button 
            onClick={onConfirm} 
            variant="outline" 
            className="text-white border-white hover:bg-white/10 bg-primary hover:bg-primary/90" 
            disabled={isLoadingConfirm}
          >
            {isLoadingConfirm ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle className="mr-2 h-4 w-4"/>}
            Activate Now
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default AgentActivationDialog;