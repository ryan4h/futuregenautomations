import React from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Loader2, AlertTriangle } from 'lucide-react';

const AgentDeactivationDialog = ({ open, onOpenChange, agentName, onConfirm, onCancel, isLoading }) => {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="bg-card border-border">
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center">
            <AlertTriangle className="text-destructive mr-2 h-6 w-6" />
            Deactivate {agentName || "Agent"}?
          </AlertDialogTitle>
          <AlertDialogDescription className="mt-2">
            Are you sure you want to deactivate this agent? It will stop performing its tasks.
            <br /><br />
            <span className="font-semibold text-amber-500">Please note:</span> You can only reactivate an agent a limited number of times per month (currently 3 times).
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel asChild>
            <Button variant="outline" className="btn-minimal" onClick={onCancel} disabled={isLoading}>
              Cancel
            </Button>
          </AlertDialogCancel>
          <AlertDialogAction asChild>
            <Button variant="destructive" onClick={onConfirm} disabled={isLoading} className="btn-destructive">
              {isLoading ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : null}
              Deactivate Agent
            </Button>
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default AgentDeactivationDialog;