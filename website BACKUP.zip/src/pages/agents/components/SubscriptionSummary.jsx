import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { DollarSign, Package, CalendarDays, AlertTriangle } from "lucide-react";

const SubscriptionSummary = ({ subscription, isLoading }) => { 
  if (isLoading) {
    return (
      <Card className="mb-6 bg-card border-border animate-pulse">
        <CardHeader>
          <div className="h-6 bg-muted rounded w-3/4"></div>
          <div className="h-4 bg-muted rounded w-1/2 mt-1"></div>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="h-16 bg-muted rounded"></div>
          <div className="h-16 bg-muted rounded"></div>
          <div className="h-16 bg-muted rounded"></div>
        </CardContent>
      </Card>
    );
  }

  const displayData = subscription || {};
  const activeAgents = displayData.active_agent_count || 0;

  if (activeAgents === 0 && (!displayData.current_tier_name || displayData.current_tier_name === 'N/A' || displayData.current_tier_name === 'Pending Setup')) {
     return (
        <Card className="mb-6 bg-accent border-primary/20">
            <CardHeader>
                <CardTitle className="text-accent-foreground flex items-center"><AlertTriangle className="h-5 w-5 mr-2 text-amber-500"/>No Active Subscription</CardTitle>
                <CardDescription className="text-muted-foreground">
                    You currently have no active agents. Add agents from the marketplace to start your subscription.
                </CardDescription>
            </CardHeader>
        </Card>
     );
  }
  
  if (!displayData.current_tier_name || displayData.current_tier_name === 'N/A' || displayData.current_tier_name === 'Pending Setup') { 
    return (
        <Card className="mb-6 bg-card border-border">
            <CardHeader>
                <CardTitle className="text-card-foreground flex items-center"><AlertTriangle className="h-5 w-5 mr-2 text-destructive"/>Subscription Tier Pending</CardTitle>
                <CardDescription className="text-muted-foreground">
                    Your subscription tier is being determined based on your {activeAgents} active agent(s). It should update shortly or after your next billing cycle.
                    Please manage your subscription in the Stripe Customer Portal if needed.
                </CardDescription>
            </CardHeader>
        </Card>
    );
  }


  return (
    <Card className="mb-6 bg-gradient-to-r from-primary/10 via-accent/5 to-background border-primary/30 shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-primary">Your Subscription</CardTitle>
        <CardDescription className="text-muted-foreground">
          Current status of your AI agent subscription.
        </CardDescription>
      </CardHeader>
      <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-x-6 gap-y-4">
        <div className="flex items-center space-x-3 p-3 bg-card rounded-md border border-border">
          <DollarSign className="h-8 w-8 text-green-500" />
          <div>
            <p className="text-xs text-muted-foreground">Monthly Rate</p>
            <p className="text-lg font-semibold text-card-foreground">${parseFloat(displayData.current_tier_monthly_rate || 0).toFixed(2)}</p>
          </div>
        </div>
        <div className="flex items-center space-x-3 p-3 bg-card rounded-md border border-border">
          <Package className="h-8 w-8 text-blue-500" />
          <div>
            <p className="text-xs text-muted-foreground">Tier / Active Agents</p>
            <p className="text-lg font-semibold text-card-foreground">{displayData.current_tier_name || 'N/A'} ({activeAgents})</p>
          </div>
        </div>
        <div className="flex items-center space-x-3 p-3 bg-card rounded-md border border-border">
          <CalendarDays className="h-8 w-8 text-purple-500" />
          <div>
            <p className="text-xs text-muted-foreground">Next Billing Date</p>
            <p className="text-lg font-semibold text-card-foreground">
              {displayData.next_billing_date ? new Date(displayData.next_billing_date).toLocaleDateString() : 'N/A'}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SubscriptionSummary;