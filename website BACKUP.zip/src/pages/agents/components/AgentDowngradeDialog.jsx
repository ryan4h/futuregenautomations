import React from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

const AgentDowngradeDialog = ({
  open,
  onOpenChange,
  agentName,
  isBillingCycleToday,
  nextBillingDate,
  onConfirmDeactivation,
  onManageSubscription,
  onCancel,
  isLoading
}) => {
  const formattedNextBillingDate = nextBillingDate 
    ? new Date(nextBillingDate).toLocaleDateString() 
    : "N/A";

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Confirm Deactivation & Potential Downgrade</AlertDialogTitle>
          <AlertDialogDescription>
            {isBillingCycleToday ? (
              <>
                Your new billing cycle starts today. Deactivating {agentName || "this agent"} may make you eligible for a lower subscription tier. 
                Would you like to manage your subscription in Stripe to potentially downgrade?
              </>
            ) : (
              <>
                Are you sure you want to deactivate {agentName || "this agent"}? 
                Your next billing cycle is on <strong>{formattedNextBillingDate}</strong>. 
                Downgrades apply from the next cycle. You can manage your subscription in Stripe to prepare for this.
              </>
            )}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="flex-col sm:flex-row gap-2">
          <Button variant="outline" onClick={onCancel} disabled={isLoading}>
            Cancel
          </Button>
          <Button variant="outline" onClick={onManageSubscription} disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Manage Subscription
          </Button>
          {!isBillingCycleToday && (
            <Button onClick={onConfirmDeactivation} className="bg-destructive hover:bg-destructive/90" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Deactivate Agent Now
            </Button>
          )}
           {isBillingCycleToday && (
             <AlertDialogCancel onClick={onCancel} disabled={isLoading} className="mt-0">
                Keep Agent Active
            </AlertDialogCancel>
          )}
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default AgentDowngradeDialog;