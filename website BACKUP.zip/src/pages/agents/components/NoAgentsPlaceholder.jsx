import React from "react";
import { Button } from "@/components/ui/button";
import { Bot } from "lucide-react";

const NoAgentsPlaceholder = ({ onAddNewAgent }) => {
  return (
    <div className="text-center py-16 border-2 border-dashed border-border rounded-lg bg-card/50">
      <Bot className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
      <h2 className="text-xl font-semibold text-card-foreground mb-2">No Agents Yet</h2>
      <p className="text-muted-foreground mb-6">
        It looks like you haven't added any AI agents to your account.
      </p>
      <Button onClick={onAddNewAgent} className="btn-minimal">
        Browse Agent Marketplace
      </Button>
    </div>
  );
};

export default NoAgentsPlaceholder;