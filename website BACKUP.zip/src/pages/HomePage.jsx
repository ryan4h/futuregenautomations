import React from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Zap, LogIn, ArrowRight } from "lucide-react";

const HomePage = () => {
  const navigate = useNavigate();
  const backgroundVideoUrl = "https://ryan4h.github.io/luxury-home-renovations/scifibackground.mp4";

  const handleExploreSolutions = () => {
    window.location.href = "https://futuregenautomations.com/ai-agents";
  };

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen text-center px-4 overflow-hidden">
      <video 
        autoPlay 
        loop 
        muted 
        playsInline
        className="video-background"
        src={backgroundVideoUrl}
      >
        Your browser does not support the video tag.
      </video>
      <div className="absolute inset-0 bg-black/60 z-0"></div> {/* Overlay for text readability */}
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative z-10 flex flex-col items-center max-w-3xl"
      >
        <motion.h1 
          className="text-4xl sm:text-5xl md:text-6xl font-semibold mb-4 text-white uppercase" 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.7, type: "spring", stiffness: 100 }}
        >
          FUTURE GEN AUTOMATIONS
        </motion.h1>
        <motion.p 
          className="text-lg sm:text-xl md:text-2xl text-gray-200 mb-10 leading-relaxed max-w-2xl" 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.7 }}
        >
          Empower your business with AI — streamline workflows, boost productivity, and unlock new potential.
        </motion.p>
        <motion.div 
          className="flex flex-col sm:flex-row w-full sm:w-auto gap-4 sm:gap-6" 
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                delayChildren: 0.6,
                staggerChildren: 0.2,
              },
            },
          }}
        >
          <motion.div variants={{ hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 } }}>
            <Button 
              size="lg" 
              className="w-full sm:w-auto bg-primary hover:bg-primary/80 text-primary-foreground text-lg px-10 py-3 shadow-lg transform hover:scale-105 transition-transform duration-200"
              onClick={() => navigate("/signup")}
            >
              <Zap className="mr-2 h-5 w-5" /> Request Access
            </Button>
          </motion.div>
          <motion.div variants={{ hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 } }}>
            <Button 
              variant="outline" 
              size="lg" 
              className="w-full sm:w-auto text-white border-white/70 hover:bg-white/10 hover:text-white text-lg px-10 py-3 shadow-lg transform hover:scale-105 transition-transform duration-200"
              onClick={() => navigate("/login")}
            >
              <LogIn className="mr-2 h-5 w-5" /> Login
            </Button>
          </motion.div>
        </motion.div>
        <motion.div
          className="mt-16 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.5 }}
        >
          <Button
            variant="link"
            className="text-gray-300 hover:text-primary group text-md"
            onClick={handleExploreSolutions}
          >
            <span className="group-hover:underline decoration-primary underline-offset-4 transition-all">Explore Our Solutions</span>
            <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default HomePage;