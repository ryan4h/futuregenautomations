import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { supabase } from "@/lib/supabaseClient";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, AlertTriangle, Info, Search, Filter, ListOrdered } from "lucide-react";
import ProductsPageHeader from "@/pages/products/ProductsPageHeader";
import ProductCard from "@/pages/products/ProductCard";
import CustomAISolutionCard from "@/pages/products/CustomAISolutionCard";
import { useCart } from "@/context/CartContext";
import { fetchUserAssignedAgents, checkExistingAgentAssignment } from "@/pages/agents/services/agentDataService"; 
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";

const ProductsFilterBar = ({ searchQuery, setSearchQuery, filterCategory, setFilterCategory, sortOrder, setSortOrder, categories }) => {
  return (
    <div className="mb-8 p-4 sm:p-6 bg-card/80 border-2 border-card-border backdrop-blur-sm rounded-lg shadow-lg">
      <div className="flex flex-col sm:flex-row items-center gap-4">
        <div className="relative flex-grow w-full sm:w-auto">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search agents by name or keyword..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-4 py-2 w-full rounded-md border-input bg-background text-foreground focus:border-primary focus:ring-primary"
          />
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="w-full sm:w-[180px] bg-background border-input text-foreground hover:border-primary focus:border-primary focus:ring-primary">
              <Filter className="h-4 w-4 mr-2 text-muted-foreground inline-block" />
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent className="bg-popover text-popover-foreground border-input">
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map(category => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sortOrder} onValueChange={setSortOrder}>
            <SelectTrigger className="w-full sm:w-[180px] bg-background border-input text-foreground hover:border-primary focus:border-primary focus:ring-primary">
              <ListOrdered className="h-4 w-4 mr-2 text-muted-foreground inline-block" />
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent className="bg-popover text-popover-foreground border-input">
              <SelectItem value="popular">Popularity</SelectItem>
              <SelectItem value="newest">Newest</SelectItem>
              <SelectItem value="price_asc">Price: Low to High</SelectItem>
              <SelectItem value="price_desc">Price: High to Low</SelectItem>
              <SelectItem value="name_asc">Name: A-Z</SelectItem>
              <SelectItem value="name_desc">Name: Z-A</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
};


const ProductsPage = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [products, setProducts] = useState([]);
  const [user, setUser] = useState(null);
  const [userAssignedAgents, setUserAssignedAgents] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [sortOrder, setSortOrder] = useState("popular");
  const [categories, setCategories] = useState([]);

  const fetchProducts = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const { data, error: productsError } = await supabase
        .from("ai_agents_list") // Ensure this table name is correct
        .select("*")
        .order("is_popular", { ascending: false })
        .order("created_at", { ascending: false });

      if (productsError) throw productsError;
      
      setProducts(data || []); // Set products with fetched data

      if (data) {
        const uniqueCategories = [...new Set(data.map(p => p.category).filter(Boolean))];
        setCategories(uniqueCategories);
      } else {
        setCategories([]);
      }

    } catch (err) {
      setError(err.message);
      toast({ title: "Error fetching products", description: err.message, variant: "destructive" });
      setProducts([]); // Clear products on error
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  const fetchCurrentUserData = useCallback(async (currentUserId) => {
    if (!currentUserId) return;
    try {
      const assignedAgents = await fetchUserAssignedAgents(currentUserId, toast);
      setUserAssignedAgents(assignedAgents || []);
    } catch (err) {
      // Toast is already handled in fetchUserAssignedAgents
    }
  }, [toast]);

  useEffect(() => {
    fetchProducts();
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user || null);
      if (session?.user) {
        fetchCurrentUserData(session.user.id);
      }
    };
    getSession();

    const { data: authListener } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        setUser(session?.user || null);
        if (session?.user) {
          fetchCurrentUserData(session.user.id);
        } else {
          setUserAssignedAgents([]);
        }
      }
    );
    return () => authListener?.subscription.unsubscribe();
  }, [fetchProducts, fetchCurrentUserData]);

  const handleAddToCart = async (product) => {
    if (!user) {
      toast({ title: "Please Login", description: "You need to be logged in to add items to your cart.", variant: "warning" });
      navigate("/login");
      return;
    }
    
    const isAlreadyOwned = userAssignedAgents.some(agent => agent.agent_product_id === product.id && agent.status === 'active');
    if (isAlreadyOwned) {
        toast({ title: "Already Owned", description: `You already own ${product.agent_name}.`, variant: "info" });
        return;
    }

    const isPurchasedButInactive = userAssignedAgents.some(agent => agent.agent_product_id === product.id && agent.status !== 'active');
    if (isPurchasedButInactive) {
         toast({ title: "Agent Inactive", description: `${product.agent_name} is in your inventory but inactive. Activate it from the Agents page.`, variant: "info" });
         navigate("/agents");
         return;
    }

    const existingAssignment = await checkExistingAgentAssignment(user.id, product.id, toast);
    if (existingAssignment) {
        toast({ title: "Already Purchased", description: `You have already purchased ${product.agent_name}. Check your Agents page.`, variant: "info" });
        navigate("/agents");
        return;
    }

    addToCart(product);
    toast({
      title: `${product.agent_name} Added to Cart!`,
      description: "Proceed to checkout or continue browsing.",
      variant: "success",
      action: <Button variant="outline" size="sm" onClick={() => navigate('/cart')}>View Cart</Button>,
    });
  };
  
  const filteredAndSortedProducts = products
    .filter(product => {
      const matchesCategory = filterCategory === "all" || product.category === filterCategory;
      const matchesSearch = searchQuery.trim() === "" || 
                            (product.agent_name && product.agent_name.toLowerCase().includes(searchQuery.toLowerCase())) ||
                            (product.description && product.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
                            (product.category && product.category.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    })
    .sort((a, b) => {
      switch (sortOrder) {
        case "newest":
          return new Date(b.created_at) - new Date(a.created_at);
        case "price_asc":
          return (a.price_one_time || 0) - (b.price_one_time || 0);
        case "price_desc":
          return (b.price_one_time || 0) - (a.price_one_time || 0);
        case "name_asc":
          return (a.agent_name || "").localeCompare(b.agent_name || "");
        case "name_desc":
          return (b.agent_name || "").localeCompare(a.agent_name || "");
        case "popular":
        default:
          return (b.is_popular ? 1 : 0) - (a.is_popular ? 1 : 0) || (b.reviews_count || 0) - (a.reviews_count || 0);
      }
    });


  return (
    <div className="container mx-auto p-4 md:p-8 text-foreground">
      <ProductsPageHeader />
      <ProductsFilterBar 
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        filterCategory={filterCategory}
        setFilterCategory={setFilterCategory}
        sortOrder={sortOrder}
        setSortOrder={setSortOrder}
        categories={categories}
      />

      {isLoading && (
        <div className="flex justify-center items-center py-20">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="ml-4 text-lg">Loading Agents...</p>
        </div>
      )}
      {error && !isLoading && (
        <div className="text-center py-20 bg-destructive/10 border border-destructive rounded-lg p-6">
          <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" />
          <h2 className="text-xl font-semibold text-destructive-foreground">Failed to load agents</h2>
          <p className="text-destructive-foreground/80">{error}</p>
          <Button variant="outline" onClick={fetchProducts} className="mt-6">Try Again</Button>
        </div>
      )}
      {!isLoading && !error && filteredAndSortedProducts.length === 0 && (
         <div className="text-center py-20 bg-card/80 border-2 border-card-border backdrop-blur-sm rounded-lg p-6 shadow-lg">
          <Info className="mx-auto h-12 w-12 text-primary mb-4" />
          <h2 className="text-xl font-semibold text-card-foreground">No Agents Found</h2>
          <p className="text-muted-foreground">
            {searchQuery || filterCategory !== "all" ? "Try adjusting your search or filters." : "No agents available at the moment. Please check back later."}
          </p>
        </div>
      )}

      {!isLoading && !error && filteredAndSortedProducts.length > 0 && (
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8"
          initial="hidden"
          animate="visible"
          variants={{
            visible: { transition: { staggerChildren: 0.05 } },
          }}
        >
          {filteredAndSortedProducts.map((product) => {
            const isOwned = userAssignedAgents.some(
              (agent) => agent.agent_product_id === product.id 
            );
            return (
              <motion.div
                key={product.id}
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0 },
                }}
              >
                <ProductCard
                  product={product}
                  onAddToCart={handleAddToCart}
                  onViewDetails={() => navigate(`/products/${product.id}`)}
                  isOwned={isOwned}
                  isPurchasable={!!product.stripe_price_id} // Use stripe_price_id from ai_agents_list
                />
              </motion.div>
            );
          })}
        </motion.div>
      )}
      
      <CustomAISolutionCard />
    </div>
  );
};

export default ProductsPage;