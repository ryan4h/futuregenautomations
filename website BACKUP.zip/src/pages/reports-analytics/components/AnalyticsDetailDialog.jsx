import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

const AnalyticsDetailDialog = ({ open, onOpenChange, metricName, metricValue, details, dateRange }) => (
  <Dialog open={open} onOpenChange={onOpenChange}>
    <DialogContent className="bg-card border-border text-card-foreground sm:max-w-lg">
      <DialogHeader>
        <DialogTitle>{metricName} - Detailed Analysis</DialogTitle>
        <DialogDescription>Showing data for: <span className="capitalize font-semibold text-primary">{dateRange.replace('_', ' ')}</span>. Current Total: {metricValue}</DialogDescription>
      </DialogHeader>
      <div className="py-4 max-h-[60vh] overflow-y-auto space-y-3">
        <div className="p-3 bg-muted/50 rounded-md">
            <p className="font-semibold text-card-foreground">{metricName} Today (Mock)</p>
            <p className="text-2xl text-primary">{Math.floor(metricValue / (dateRange === "today" ? 1 : (dateRange === "current_week" ? 7 : 30) ))}</p>
            <p className="text-xs text-muted-foreground">Timestamp examples: 09:15 AM, 11:30 AM, 02:45 PM (Placeholder)</p>
        </div>
        <div className="p-3 bg-muted/50 rounded-md">
            <p className="font-semibold text-card-foreground">{metricName} This Week (Mock)</p>
            <p className="text-2xl text-primary">{Math.floor(metricValue / (dateRange.includes("month") ? 4 : 1))}</p>
            <p className="text-xs text-muted-foreground">Day-by-day breakdown placeholder.</p>
        </div>
         {details && Object.keys(details).length > 0 ? (
            <div>
                <h4 className="font-semibold mt-3 mb-1">Raw Data Snippet (if available)</h4>
                <pre className="text-xs bg-background p-2 rounded max-h-40 overflow-auto">{JSON.stringify(details, null, 2)}</pre>
            </div>
            ) : <p className="text-xs text-muted-foreground mt-2">No specific raw data available for this view.</p>
        }
      </div>
      <DialogFooter>
        <Button variant="outline" className="btn-minimal" onClick={() => onOpenChange(false)}>Close</Button>
      </DialogFooter>
    </DialogContent>
  </Dialog>
);

export default AnalyticsDetailDialog;