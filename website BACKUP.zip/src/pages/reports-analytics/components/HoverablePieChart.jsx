import React, { useState } from 'react';
import { motion } from 'framer-motion';

const HoverablePieChart = ({ data, onHoverSegment }) => {
  const [hoveredSegment, setHoveredSegment] = useState(null);

  if (!data || data.length === 0) {
    return <div className="flex items-center justify-center h-full text-muted-foreground">No data for chart</div>;
  }

  const totalValue = data.reduce((sum, item) => sum + item.value, 0);
  if (totalValue === 0) {
    return <div className="flex items-center justify-center h-full text-muted-foreground">Data values are zero</div>;
  }

  let accumulatedAngle = 0;
  const radius = 40;
  const center = 50;

  const getCoordinatesForPercent = (percent) => {
    const x = center + radius * Math.cos(2 * Math.PI * percent);
    const y = center + radius * Math.sin(2 * Math.PI * percent);
    return [x, y];
  };

  return (
    <div className="w-48 h-48 sm:w-56 sm:h-56 relative">
      <svg viewBox="0 0 100 100" className="transform -rotate-90">
        {data.map((item, index) => {
          const percentage = item.value / totalValue;
          const angle = percentage * 360;
          
          const startAngleRad = (accumulatedAngle * Math.PI) / 180;
          const endAngleRad = ((accumulatedAngle + angle) * Math.PI) / 180;

          const x1 = center + radius * Math.cos(startAngleRad);
          const y1 = center + radius * Math.sin(startAngleRad);
          const x2 = center + radius * Math.cos(endAngleRad);
          const y2 = center + radius * Math.sin(endAngleRad);
          
          const largeArcFlag = angle > 180 ? 1 : 0;
          const pathData = `M ${center},${center} L ${x1},${y1} A ${radius},${radius} 0 ${largeArcFlag} 1 ${x2},${y2} Z`;
          
          const isHovered = hoveredSegment?.key === item.key;
          accumulatedAngle += angle;

          return (
            <motion.path
              key={item.key}
              d={pathData}
              fill={item.color}
              stroke="hsl(var(--card))"
              strokeWidth={isHovered ? 2 : 0.5}
              onMouseEnter={() => {
                setHoveredSegment(item);
                if (onHoverSegment) onHoverSegment(item);
              }}
              onMouseLeave={() => {
                setHoveredSegment(null);
                if (onHoverSegment) onHoverSegment(null);
              }}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: isHovered ? 1.05 : 1 }}
              transition={{ duration: 0.3, ease: "easeInOut" }}
              style={{ cursor: 'pointer', transformOrigin: 'center center' }}
            />
          );
        })}
      </svg>
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-16 h-16 sm:w-20 sm:h-20 bg-card rounded-full shadow-inner"></div>
      </div>
      {hoveredSegment && (
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 p-2 bg-popover text-popover-foreground rounded-md shadow-xl text-center text-xs pointer-events-none z-10">
          <p className="font-bold whitespace-nowrap">{hoveredSegment.label}</p>
          <p className="text-primary">{hoveredSegment.value} ({((hoveredSegment.value / totalValue) * 100).toFixed(1)}%)</p>
        </div>
      )}
    </div>
  );
};

export default HoverablePieChart;