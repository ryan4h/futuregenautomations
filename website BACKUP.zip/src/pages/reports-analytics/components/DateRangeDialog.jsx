import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

const DateRangeDialog = ({ open, onOpenChange, onApply }) => {
  const [selectedRange, setSelectedRange] = useState("current_month");
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border">
        <DialogHeader>
          <DialogTitle>Select Date Range</DialogTitle>
          <DialogDescription>Choose a period for your report.</DialogDescription>
        </DialogHeader>
        <div className="py-4 space-y-3">
          <Button variant={selectedRange === "today" ? "default": "outline"} className="w-full justify-start" onClick={() => setSelectedRange("today")}>Today</Button>
          <Button variant={selectedRange === "current_week" ? "default": "outline"} className="w-full justify-start" onClick={() => setSelectedRange("current_week")}>Current Week</Button>
          <Button variant={selectedRange === "current_month" ? "default": "outline"} className="w-full justify-start" onClick={() => setSelectedRange("current_month")}>Current Month</Button>
          <Button variant={selectedRange === "last_month" ? "default": "outline"} className="w-full justify-start" onClick={() => setSelectedRange("last_month")}>Last Month</Button>
          <Button variant={selectedRange === "last_3_months" ? "default": "outline"} className="w-full justify-start" onClick={() => setSelectedRange("last_3_months")}>Last 3 Months</Button>
        </div>
        <DialogFooter>
          <Button variant="outline" className="btn-minimal" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button className="btn-primary" onClick={() => { onApply(selectedRange); onOpenChange(false); }}>Apply</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default DateRangeDialog;