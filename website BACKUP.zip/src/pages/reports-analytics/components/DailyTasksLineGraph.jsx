import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Info } from 'lucide-react';

const DailyTasksLineGraph = ({ data, dateRangeLabel }) => {
  const [tooltip, setTooltip] = useState(null);
  const containerRef = useRef(null);

  if (!data || data.length === 0) {
    return (
      <div className="h-full w-full flex flex-col items-center justify-center bg-muted/50 rounded-lg p-4">
        <Info className="h-12 w-12 text-muted-foreground mb-3" />
        <p className="text-muted-foreground font-semibold text-center">No daily task data available for the selected period.</p>
        <p className="text-xs text-muted-foreground text-center">Ensure tasks are being completed to see data here.</p>
      </div>
    );
  }

  const PADDING = 40;
  const SVG_HEIGHT = 300;
  const SVG_WIDTH = containerRef.current ? containerRef.current.offsetWidth : 600;

  const maxValue = Math.max(...data.map(d => d.tasksCompleted), 0) || 10; 
  const minValue = 0; 

  const points = data.map((item, index) => {
    const x = PADDING + (index / (data.length - 1 || 1)) * (SVG_WIDTH - 2 * PADDING);
    const y = SVG_HEIGHT - PADDING - ((item.tasksCompleted - minValue) / (maxValue - minValue || 1)) * (SVG_HEIGHT - 2 * PADDING);
    return { x, y, date: item.date, value: item.tasksCompleted };
  });

  const pathD = points.reduce((acc, point, i, a) => {
    if (i === 0) return `M ${point.x},${point.y}`;
    const [cpsX, cpsY] = controlPoint(a[i - 1], a[i - 2], point, false);
    const [cpeX, cpeY] = controlPoint(point, a[i - 1], a[i + 1], true);
    return `${acc} C ${cpsX},${cpsY} ${cpeX},${cpeY} ${point.x},${point.y}`;
  }, "");

  function controlPoint(current, previous, next, isEndControl) {
    const p = previous || current;
    const n = next || current;
    const smoothing = 0.15;
    const o = {
      x: p.x + (n.x - p.x) * 0.5,
      y: p.y + (n.y - p.y) * 0.5,
    };
    const angle = Math.atan2(n.y - p.y, n.x - p.x);
    const length = Math.sqrt((n.x - p.x) ** 2 + (n.y - p.y) ** 2) * smoothing;
    const x = o.x + Math.cos(angle + (isEndControl ? Math.PI : 0)) * length;
    const y = o.y + Math.sin(angle + (isEndControl ? Math.PI : 0)) * length;
    return [x, y];
  }
  
  const handleMouseMove = (e) => {
    if (!containerRef.current) return;
    const svgRect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - svgRect.left;
    
    let closestPoint = null;
    let minDist = Infinity;

    points.forEach(p => {
      const dist = Math.abs(p.x - x);
      if (dist < minDist && dist < 20) { // Check within a 20px horizontal threshold
        minDist = dist;
        closestPoint = p;
      }
    });

    if (closestPoint) {
      setTooltip({
        x: closestPoint.x,
        y: closestPoint.y,
        date: closestPoint.date,
        value: closestPoint.value,
        svgX: e.clientX - svgRect.left,
        svgY: e.clientY - svgRect.top,
      });
    } else {
      setTooltip(null);
    }
  };

  const handleMouseLeave = () => {
    setTooltip(null);
  };

  return (
    <div ref={containerRef} className="relative w-full h-full bg-card p-4 rounded-lg border border-border" 
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      <h3 className="text-lg font-semibold text-card-foreground mb-1">Daily Tasks Completed</h3>
      <p className="text-xs text-muted-foreground mb-4">Range: {dateRangeLabel}</p>
      <svg width="100%" height={SVG_HEIGHT} viewBox={`0 0 ${SVG_WIDTH} ${SVG_HEIGHT}`}>
        <line x1={PADDING} y1={SVG_HEIGHT - PADDING} x2={SVG_WIDTH - PADDING} y2={SVG_HEIGHT - PADDING} stroke="hsl(var(--border))" />
        <line x1={PADDING} y1={PADDING} x2={PADDING} y2={SVG_HEIGHT - PADDING} stroke="hsl(var(--border))" />

        {Array.from({ length: 5 }).map((_, i) => {
          const y = PADDING + i * ((SVG_HEIGHT - 2 * PADDING) / 4);
          const value = Math.round(maxValue - i * (maxValue / 4));
          return (
            <g key={`y-axis-${i}`}>
              <line x1={PADDING - 5} y1={y} x2={SVG_WIDTH - PADDING} y2={y} stroke="hsl(var(--border))" strokeDasharray="2,2" opacity="0.5" />
              <text x={PADDING - 10} y={y + 4} textAnchor="end" fontSize="10" fill="hsl(var(--muted-foreground))">{value}</text>
            </g>
          );
        })}

        {data.map((item, index) => {
          const x = PADDING + (index / (data.length - 1 || 1)) * (SVG_WIDTH - 2 * PADDING);
          const date = new Date(item.date);
          const day = date.getDate(); 
          if (index % Math.max(1, Math.floor(data.length / 10)) === 0 || data.length <= 10 ) {
            return (
              <text key={`x-axis-${index}`} x={x} y={SVG_HEIGHT - PADDING + 15} textAnchor="middle" fontSize="10" fill="hsl(var(--muted-foreground))">
                {day}
              </text>
            );
          }
          return null;
        })}
        
        <motion.path
          d={pathD}
          fill="none"
          stroke="hsl(var(--primary))"
          strokeWidth="2.5"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 1.5, ease: "easeInOut" }}
        />
        
        {points.map((point, index) => (
          <motion.circle
            key={index}
            cx={point.x}
            cy={point.y}
            r="4"
            fill="hsl(var(--primary))"
            stroke="hsl(var(--card))"
            strokeWidth="2"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
            className="cursor-pointer"
          />
        ))}

        {tooltip && (
          <line
            x1={tooltip.x}
            y1={PADDING}
            x2={tooltip.x}
            y2={SVG_HEIGHT - PADDING}
            stroke="hsl(var(--primary))"
            strokeDasharray="3,3"
            strokeWidth="1"
          />
        )}
      </svg>
      {tooltip && (
        <div
          className="absolute bg-popover text-popover-foreground p-2 rounded-md shadow-lg text-xs pointer-events-none"
          style={{
            left: `${tooltip.svgX + 10}px`,
            top: `${tooltip.svgY + 10}px`,
            transform: 'translate(-50%, -100%)',
            minWidth: '120px'
          }}
        >
          <p className="font-semibold">{new Date(tooltip.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</p>
          <p>Tasks: <span className="font-bold text-primary">{tooltip.value}</span></p>
        </div>
      )}
    </div>
  );
};

export default DailyTasksLineGraph;