import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const FilterReportsDialog = ({ open, onOpenChange, onApply, activeAgents }) => {
  const [reportType, setReportType] = useState("overall_performance");
  const [selectedAgent, setSelectedAgent] = useState("all");
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border">
        <DialogHeader>
          <DialogTitle>Filter Reports</DialogTitle>
          <DialogDescription>Select filters for the reports.</DialogDescription>
        </DialogHeader>
        <div className="py-4 space-y-4">
          <div>
            <label className="text-sm font-medium text-muted-foreground">Report Type</label>
            <Select value={reportType} onValueChange={setReportType}>
              <SelectTrigger className="w-full mt-1 bg-input border-border"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="overall_performance">Overall Performance</SelectItem>
                <SelectItem value="ad_campaigns">Ad Campaigns</SelectItem>
                <SelectItem value="agent_overviews">Agent Overviews</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {reportType === "agent_overviews" && (
            <div>
              <label className="text-sm font-medium text-muted-foreground">Select Agent</label>
              <Select value={selectedAgent} onValueChange={setSelectedAgent}>
                <SelectTrigger className="w-full mt-1 bg-input border-border"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Agents</SelectItem>
                  {activeAgents.map(agent => <SelectItem key={agent.assigned_agent_id} value={agent.agent_name}>{agent.agent_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" className="btn-minimal" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button className="btn-primary" onClick={() => { onApply({ reportType, agent: selectedAgent }); onOpenChange(false); }}>Apply Filters</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default FilterReportsDialog;