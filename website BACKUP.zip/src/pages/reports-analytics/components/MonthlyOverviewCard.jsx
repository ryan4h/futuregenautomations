import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { motion } from "framer-motion";

const MonthlyOverviewCard = ({ title, icon, onDownload }) => (
  <Card className="bg-card border-border">
    <CardHeader className="flex flex-row items-center justify-between pb-2">
      <div className="flex items-center">
        {React.cloneElement(icon, { className: "h-6 w-6 mr-3 text-primary"})}
        <CardTitle className="text-lg text-card-foreground">{title}</CardTitle>
      </div>
      <Button variant="ghost" size="sm" onClick={onDownload} className="text-muted-foreground hover:text-primary">
        <Download className="mr-2 h-4 w-4" /> PDF
      </Button>
    </CardHeader>
    <CardContent>
      <div className="h-20 bg-muted rounded-md flex items-center justify-center">
        <p className="text-sm text-muted-foreground">Monthly performance data for {title.replace(" Overview", "")} will appear here.</p>
      </div>
       <div className="mt-3 h-4 bg-primary/20 rounded-full w-full"> 
            <motion.div 
                className="h-4 bg-gradient-to-r from-primary to-sky-400 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${Math.floor(Math.random() * 60) + 30}%` }} 
                transition={{ duration: 1, delay: 0.2 }}
            />
        </div>
        <p className="text-xs text-muted-foreground text-right mt-1">Mock Data Progress</p>
    </CardContent>
  </Card>
);

export default MonthlyOverviewCard;