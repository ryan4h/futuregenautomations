import React from 'react';
import { motion } from 'framer-motion';

const VerticalAnalyticsBar = ({ label, value, maxValue, color, onClick }) => {
  const percentageHeight = maxValue > 0 ? Math.max(5, (value / maxValue) * 100) : 5; // Ensure a minimum visible height

  return (
    <div 
      className="flex flex-col items-center w-12 sm:w-16 cursor-pointer group" 
      onClick={onClick}
      title={`${label}: ${value}`}
    >
      <div
        className="w-full bg-muted rounded-t-md relative"
        style={{ height: '150px' }} 
      >
        <motion.div
          className="w-full rounded-t-md absolute bottom-0 left-0"
          style={{ background: color }}
          initial={{ height: '0%' }}
          animate={{ height: `${percentageHeight}%` }}
          transition={{ duration: 0.8, ease: "circOut" }}
        />
      </div>
      <div className="mt-2 text-center">
        <p className="text-xs font-medium text-foreground truncate w-full group-hover:text-primary">{label}</p>
        <p className="text-sm font-bold text-foreground group-hover:text-primary">{value}</p>
      </div>
    </div>
  );
};

export default VerticalAnalyticsBar;