import React from 'react';
import { motion } from 'framer-motion';

const PerformancePieChart = ({ data }) => {
  if (!data || data.length === 0) {
    return <div className="flex items-center justify-center h-full text-muted-foreground">No data for chart</div>;
  }

  const totalValue = data.reduce((sum, item) => sum + item.value, 0);
  if (totalValue === 0) {
    return <div className="flex items-center justify-center h-full text-muted-foreground">Data values are zero</div>;
  }

  let accumulatedAngle = 0;

  return (
    <div className="w-48 h-48 sm:w-56 sm:h-56 relative">
      <svg viewBox="0 0 100 100" className="transform -rotate-90">
        {data.map((item, index) => {
          const percentage = (item.value / totalValue) * 100;
          const angle = (percentage / 100) * 360;
          
          const startAngle = accumulatedAngle;
          const endAngle = accumulatedAngle + angle;
          accumulatedAngle += angle;

          const x1 = 50 + 40 * Math.cos(Math.PI * startAngle / 180);
          const y1 = 50 + 40 * Math.sin(Math.PI * startAngle / 180);
          const x2 = 50 + 40 * Math.cos(Math.PI * endAngle / 180);
          const y2 = 50 + 40 * Math.sin(Math.PI * endAngle / 180);
          const largeArcFlag = angle > 180 ? 1 : 0;

          return (
            <motion.path
              key={item.key}
              d={`M 50 50 L ${x1} ${y1} A 40 40 0 ${largeArcFlag} 1 ${x2} ${y2} Z`}
              fill={item.color}
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            />
          );
        })}
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-16 h-16 sm:w-20 sm:h-20 bg-card rounded-full"></div>
      </div>
    </div>
  );
};

export default PerformancePieChart;