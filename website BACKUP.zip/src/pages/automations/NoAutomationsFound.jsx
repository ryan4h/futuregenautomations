import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, Plus } from "lucide-react";

const NoAutomationsFound = ({ handleCreateAutomation, isFiltering }) => {
  return (
    <div className="col-span-full">
      <Card className="bg-card/70 border-2 border-card-border backdrop-blur-md shadow-lg">
        <CardContent className="p-6 flex flex-col items-center justify-center text-center py-12">
          <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-xl font-medium mb-2 text-card-foreground">
            {isFiltering ? "No Automations Match Your Filters" : "No Automations Yet"}
          </h3>
          <p className="text-muted-foreground mb-6 max-w-md">
            {isFiltering 
              ? "Try adjusting your search or filter criteria to find what you're looking for." 
              : "Get started by creating your first automation to streamline your workflows."}
          </p>
          {!isFiltering && (
            <Button variant="outline" onClick={handleCreateAutomation} className="border-primary text-primary hover:bg-primary/10">
              <Plus className="h-4 w-4 mr-2" />
              Create Automation
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default NoAutomationsFound;