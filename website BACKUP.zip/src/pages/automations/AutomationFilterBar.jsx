import React from 'react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Search, Filter as FilterIcon, ListOrdered } from "lucide-react";

const AutomationFilterBar = ({ 
  searchQuery, 
  setSearchQuery, 
  selectedType, 
  setSelectedType, 
  selectedStatus, 
  setSelectedStatus,
  sortOrder,
  setSortOrder
}) => {
  const automationTypes = ["Zapier", "Custom", "API Based", "Scheduled"];
  const automationStatuses = ["Active", "Paused", "Draft", "Error"];
  const sortOptions = [
    { value: "name_asc", label: "Name (A-Z)" },
    { value: "name_desc", label: "Name (Z-A)" },
    { value: "last_run_newest", label: "Last Run (Newest)" },
    { value: "last_run_oldest", label: "Last Run (Oldest)" },
    { value: "runs_desc", label: "Total Runs (Most)" },
    { value: "runs_asc", label: "Total Runs (Least)" },
  ];

  return (
    <Card className="mb-8 bg-card/80 border-2 border-card-border backdrop-blur-sm rounded-lg shadow-lg">
      <CardContent className="p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <div className="relative flex-grow w-full sm:w-auto">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search automations by name or tag..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 w-full rounded-md border-input bg-background text-foreground focus:border-primary focus:ring-primary"
            />
          </div>
          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="w-full sm:w-[160px] bg-background border-input text-foreground hover:border-primary focus:border-primary focus:ring-primary">
                <FilterIcon className="h-4 w-4 mr-2 text-muted-foreground inline-block" />
                <SelectValue placeholder="Filter by Type" />
              </SelectTrigger>
              <SelectContent className="bg-popover text-popover-foreground border-input">
                <SelectItem value="all">All Types</SelectItem>
                {automationTypes.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-full sm:w-[160px] bg-background border-input text-foreground hover:border-primary focus:border-primary focus:ring-primary">
                <FilterIcon className="h-4 w-4 mr-2 text-muted-foreground inline-block" />
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent className="bg-popover text-popover-foreground border-input">
                <SelectItem value="all">All Statuses</SelectItem>
                {automationStatuses.map(status => (
                  <SelectItem key={status} value={status}>{status}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={sortOrder} onValueChange={setSortOrder}>
              <SelectTrigger className="w-full sm:w-[180px] bg-background border-input text-foreground hover:border-primary focus:border-primary focus:ring-primary">
                <ListOrdered className="h-4 w-4 mr-2 text-muted-foreground inline-block" />
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent className="bg-popover text-popover-foreground border-input">
                {sortOptions.map(option => (
                  <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AutomationFilterBar;