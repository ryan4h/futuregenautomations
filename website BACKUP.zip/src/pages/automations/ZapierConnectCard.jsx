import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Zap } from "lucide-react";

const ZapierConnectCard = ({ onConnectZapier }) => {
  return (
    <Card className="bg-card/70 border-2 border-card-border backdrop-blur-md shadow-lg mt-12">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-orange-500/20 rounded-md">
            <Zap className="h-6 w-6 text-orange-500" />
          </div>
          <CardTitle className="text-xl text-card-foreground">Connect with Zapier</CardTitle>
        </div>
        <CardDescription className="text-muted-foreground pt-1">
          Link your Zapier account to create powerful automations between your favorite apps and unlock more possibilities.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col sm:flex-row items-center justify-between p-4 sm:p-6 border-2 border-card-border/50 rounded-lg bg-background/50">
          <div className="flex items-center mb-4 sm:mb-0">
            <div className="h-12 w-12 rounded-full bg-gradient-to-br from-orange-500 to-yellow-500 flex items-center justify-center text-white font-bold text-2xl mr-4 shadow-md">
              Z
            </div>
            <div>
              <h3 className="font-medium text-card-foreground">Zapier Integration</h3>
              <p className="text-sm text-muted-foreground">
                Create and manage automations seamlessly.
              </p>
            </div>
          </div>
          <Button 
            variant="default" 
            onClick={onConnectZapier} 
            className="w-full sm:w-auto bg-orange-500 hover:bg-orange-600 text-white"
          >
            <Zap className="h-4 w-4 mr-2" /> Connect Zapier
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ZapierConnectCard;