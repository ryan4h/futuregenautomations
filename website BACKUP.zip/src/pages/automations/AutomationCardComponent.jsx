import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Zap, Clock, BarChart3, Edit, Play, Pause, MoreHorizontal, AlertCircle } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const AutomationCardComponent = ({ automation, onAutomationAction }) => {
  const getStatusBadgeClass = (status) => {
    switch (status) {
      case "Active": return "border-green-400 bg-green-500/20 text-green-300";
      case "Paused": return "border-yellow-400 bg-yellow-500/20 text-yellow-300";
      case "Draft": return "border-gray-400 bg-gray-500/20 text-gray-300";
      case "Error": return "border-red-400 bg-red-500/20 text-red-300";
      default: return "border-gray-400 bg-gray-500/20 text-gray-300";
    }
  };

  const Icon = automation.type === "Zapier" ? Zap : AlertCircle;

  return (
    <Card className="h-full flex flex-col bg-card/70 border-2 border-card-border backdrop-blur-md shadow-xl overflow-hidden transition-all duration-300 hover:border-primary/70">
      <CardHeader className="p-4 border-b border-card-border/50">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-md">
              <Icon className="h-6 w-6 text-primary" />
            </div>
            <CardTitle className="text-lg font-semibold text-card-foreground leading-tight">{automation.name}</CardTitle>
          </div>
          <Badge variant="outline" className={`text-xs ${getStatusBadgeClass(automation.status)}`}>
            {automation.status}
          </Badge>
        </div>
        <CardDescription className="mt-2 text-xs text-muted-foreground line-clamp-2">
          {automation.description}
        </CardDescription>
      </CardHeader>
      <CardContent className="p-4 flex-grow space-y-3">
        <div className="flex items-center text-xs">
          <Zap className="h-3 w-3 mr-2 text-muted-foreground" />
          <span className="text-muted-foreground">Type:</span>
          <span className="ml-1.5 font-medium text-card-foreground">{automation.type}</span>
        </div>
        <div className="flex items-center text-xs">
          <Clock className="h-3 w-3 mr-2 text-muted-foreground" />
          <span className="text-muted-foreground">Last run:</span>
          <span className="ml-1.5 font-medium text-card-foreground">{automation.lastRun}</span>
        </div>
        <div className="flex items-center text-xs">
          <BarChart3 className="h-3 w-3 mr-2 text-muted-foreground" />
          <span className="text-muted-foreground">Total runs:</span>
          <span className="ml-1.5 font-medium text-card-foreground">{automation.runs}</span>
        </div>
        
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="steps" className="border-card-border/50">
            <AccordionTrigger className="text-xs text-muted-foreground hover:text-primary py-2">
              View Workflow Steps
            </AccordionTrigger>
            <AccordionContent className="pt-2">
              <ol className="space-y-1.5 pl-4 list-decimal text-xs text-muted-foreground">
                {automation.steps.map((step, i) => (
                  <li key={i}>{step}</li>
                ))}
              </ol>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
      <CardFooter className="p-3 border-t border-card-border/50 flex justify-between items-center">
        <span className="text-xs text-muted-foreground">Created: {automation.created}</span>
        <div className="flex gap-2">
          {automation.status === "Active" ? (
            <Button
              variant="outline"
              size="sm"
              className="text-yellow-400 border-yellow-400 hover:bg-yellow-400/10"
              onClick={() => onAutomationAction("Pause", automation)}
            >
              <Pause className="h-3 w-3 mr-1.5" />
              Pause
            </Button>
          ) : (
            <Button
              variant="outline"
              size="sm"
              className="text-green-400 border-green-400 hover:bg-green-400/10"
              onClick={() => onAutomationAction("Activate", automation)}
            >
              <Play className="h-3 w-3 mr-1.5" />
              Activate
            </Button>
          )}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-popover text-popover-foreground border-input">
              <DropdownMenuItem onClick={() => onAutomationAction("Edit", automation)}>
                <Edit className="mr-2 h-4 w-4" /> Edit
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onAutomationAction("View Logs", automation)}>
                <BarChart3 className="mr-2 h-4 w-4" /> View Logs
              </DropdownMenuItem>
              <DropdownMenuSeparator className="bg-border" />
              <DropdownMenuItem 
                className="text-destructive focus:text-destructive focus:bg-destructive/10"
                onClick={() => onAutomationAction("Delete", automation)}
              >
                <AlertCircle className="mr-2 h-4 w-4" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardFooter>
    </Card>
  );
};

export default AutomationCardComponent;