import React from 'react';
import { motion } from "framer-motion";
import AutomationCardComponent from "./AutomationCardComponent";

const AutomationsGrid = ({ automations, onAutomationAction }) => (
  <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-8">
    {automations.map((automation, index) => (
      <motion.div
        key={automation.id}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.07, duration: 0.4 }}
      >
        <AutomationCardComponent automation={automation} onAutomationAction={onAutomationAction} />
      </motion.div>
    ))}
  </div>
);

export default AutomationsGrid;