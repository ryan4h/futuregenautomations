import React from 'react';
import { Button } from "@/components/ui/button";
import { Plus, Settings } from "lucide-react";

const AutomationsPageHeader = ({ onCreateAutomation, onManageSettings }) => (
  <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 pt-8 text-center md:text-left">
    <div>
      <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-primary via-accent to-secondary mb-3">
        Workflow Automations
      </h1>
      <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto md:mx-0">
        Manage your automated tasks, Zapier connections, and custom workflows.
      </p>
    </div>
    <div className="flex gap-2 mt-6 md:mt-0 w-full md:w-auto justify-center md:justify-start">
       <Button variant="outline" onClick={onManageSettings} className="border-primary text-primary hover:bg-primary/10">
        <Settings className="h-4 w-4 mr-2" />
        Manage Settings
      </Button>
      <Button variant="default" onClick={onCreateAutomation} className="bg-primary hover:bg-primary/90 text-primary-foreground">
        <Plus className="h-4 w-4 mr-2" />
        Create Automation
      </Button>
    </div>
  </div>
);

export default AutomationsPageHeader;