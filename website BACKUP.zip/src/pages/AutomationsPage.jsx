import React, { useState, useEffect } from "react";
import { useToast } from "@/components/ui/use-toast";
import { Loader2 } from "lucide-react";

import AutomationsPageHeader from "./automations/AutomationsPageHeader";
import AutomationFilterBar from "./automations/AutomationFilterBar";
import AutomationsGrid from "./automations/AutomationsGrid";
import NoAutomationsFound from "./automations/NoAutomationsFound";
import ZapierConnectCard from "./automations/ZapierConnectCard";

const mockAutomations = [
    { id: 1, name: "Lead Nurturing Sequence", description: "Automatically send follow-up emails to new leads based on their interactions.", type: "Zapier", status: "Active", lastRun: "2 hours ago", runs: 245, created: "2023-09-15", steps: ["New lead form submission", "Add lead to CRM", "Send welcome email", "Wait 2 days", "Send follow-up email if no response"] },
    { id: 2, name: "Customer Feedback Collection", description: "Collect and analyze customer feedback after purchase.", type: "Zapier", status: "Active", lastRun: "1 day ago", runs: 128, created: "2023-10-05", steps: ["Order completed", "Wait 5 days", "Send feedback request email", "Collect responses in spreadsheet", "Alert team for negative feedback"] },
    { id: 3, name: "Abandoned Cart Recovery", description: "Send reminders to customers who abandoned their shopping carts.", type: "API Based", status: "Paused", lastRun: "5 days ago", runs: 87, created: "2023-08-20", steps: ["Cart abandoned event", "Wait 4 hours", "Send reminder email", "Wait 24 hours", "Send discount offer if still not purchased"] },
    { id: 4, name: "Social Media Content Publishing", description: "Automatically publish blog content to social media channels.", type: "Zapier", status: "Error", lastRun: "3 hours ago", runs: 56, created: "2023-11-10", steps: ["New blog post published", "Create social media posts", "Schedule posts across platforms", "Monitor engagement", "Report results"] },
    { id: 5, name: "Campaign Performance Alerts", description: "Send alerts when campaign performance drops below thresholds.", type: "Custom", status: "Active", lastRun: "12 hours ago", runs: 34, created: "2023-12-01", steps: ["Monitor campaign metrics hourly", "Compare to baseline performance", "Detect significant drops", "Send alert to team", "Log incident"] },
    { id: 6, name: "Daily Backup Routine", description: "Scheduled daily backup of critical database tables.", type: "Scheduled", status: "Active", lastRun: "1 hour ago", runs: 30, created: "2024-01-01", steps: ["Connect to database", "Select tables", "Compress data", "Store in S3 bucket", "Notify admin"] },
    { id: 7, name: "New User Onboarding", description: "Guides new users through initial setup steps.", type: "Custom", status: "Draft", lastRun: "N/A", runs: 0, created: "2024-02-10", steps: ["User signs up", "Send welcome email", "Prompt for profile completion", "Introduce key features", "Offer tutorial link"] },
];


const AutomationsPage = () => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const [allAutomations, setAllAutomations] = useState([]);
  
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [sortOrder, setSortOrder] = useState("last_run_newest");

  useEffect(() => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setAllAutomations(mockAutomations);
      setIsLoading(false);
    }, 1000);
  }, []);


  const filteredAutomations = allAutomations.filter((automation) => {
    const matchesSearch = automation.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          automation.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === "all" || automation.type === selectedType;
    const matchesStatus = selectedStatus === "all" || automation.status === selectedStatus;
    return matchesSearch && matchesType && matchesStatus;
  }).sort((a,b) => {
    switch(sortOrder) {
        case "name_asc": return a.name.localeCompare(b.name);
        case "name_desc": return b.name.localeCompare(a.name);
        case "last_run_newest": return new Date(b.lastRun === "N/A" ? 0 : b.lastRun) - new Date(a.lastRun === "N/A" ? 0 : a.lastRun); // Simplistic date sort
        case "last_run_oldest": return new Date(a.lastRun === "N/A" ? 0 : a.lastRun) - new Date(b.lastRun === "N/A" ? 0 : b.lastRun);
        case "runs_desc": return b.runs - a.runs;
        case "runs_asc": return a.runs - b.runs;
        default: return 0;
    }
  });

  const handleCreateAutomation = () => {
    toast({ title: "Create Automation", description: "Opening automation creation wizard..." });
  };

  const handleManageSettings = () => {
    toast({ title: "Manage Settings", description: "Navigating to automation settings..." });
  };
  
  const handleConnectZapier = () => {
    toast({ title: "Connect Zapier", description: "Redirecting to Zapier for authentication..." });
  };

  const handleAutomationAction = (action, automation) => {
    toast({ 
        title: `${action} '${automation.name}'`, 
        description: `Action: ${action} for automation ID ${automation.id}. To be implemented.`,
        variant: action === "Delete" ? "destructive" : "default"
    });
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-4 md:p-8 flex justify-center items-center min-h-[calc(100vh-150px)]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="ml-4 text-lg text-foreground">Loading Automations...</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 md:p-8 text-foreground">
      <AutomationsPageHeader 
        onCreateAutomation={handleCreateAutomation} 
        onManageSettings={handleManageSettings}
      />

      <AutomationFilterBar 
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        selectedType={selectedType}
        setSelectedType={setSelectedType}
        selectedStatus={selectedStatus}
        setSelectedStatus={setSelectedStatus}
        sortOrder={sortOrder}
        setSortOrder={setSortOrder}
      />

      {filteredAutomations.length > 0 ? (
        <AutomationsGrid automations={filteredAutomations} onAutomationAction={handleAutomationAction} />
      ) : (
        <NoAutomationsFound 
            handleCreateAutomation={handleCreateAutomation} 
            isFiltering={searchQuery !== "" || selectedType !== "all" || selectedStatus !== "all"}
        />
      )}

      <ZapierConnectCard onConnectZapier={handleConnectZapier} />
    </div>
  );
};

export default AutomationsPage;