
import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/lib/supabaseClient";
import { Loader2, ShieldCheck, AlertTriangle } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { loadStripe } from '@stripe/stripe-js';
import { Button } from "@/components/ui/button"; 

import BillingInfoCard from '@/pages/billing/BillingInfoCard';
import PaymentActionsCard from '@/pages/billing/PaymentActionsCard';
import BillingHistoryCard from '@/pages/billing/BillingHistoryCard';
import TierUpgradeDialog from '@/pages/billing/TierUpgradeDialog';


const STRIPE_PUBLISHABLE_KEY = 'pk_live_51RQ3IkDm0AzRryHihPdGiAwNeQyHy6xPOLPqYDf8aH0RnyODqxI3Rl8EqkaigYwFMBCudcGmulJp67UbitXTGM8q00a1m4j3TB'; 

const BillingPage = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [subscriptionDetails, setSubscriptionDetails] = useState(null);
  const [allSubscriptionTiers, setAllSubscriptionTiers] = useState([]);
  const [activeAgentsCount, setActiveAgentsCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [isPortalLoading, setIsPortalLoading] = useState(false);
  const [isUpgradeDialogOpen, setIsUpgradeDialogOpen] = useState(false);

  const fetchAllBillingData = useCallback(async (userId) => {
    setIsLoading(true);
    try {
      const { data: profile, error: profileError } = await supabase
        .from('user_profiles')
        .select('stripe_customer_id, email, full_name, company_name')
        .eq('user_id', userId)
        .single();
      
      if (profileError) throw profileError;
      setUserProfile(profile);

      const { data: subData, error: subError } = await supabase
        .from('user_agent_subscriptions')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();
      if (subError && subError.code !== 'PGRST116') throw subError;
      setSubscriptionDetails(subData);

      const { data: tiersData, error: tiersError } = await supabase
        .from('subscription_tiers')
        .select('*')
        .order('monthly_rate', { ascending: true });
      if (tiersError) throw tiersError;
      setAllSubscriptionTiers(tiersData || []);
      
      const { count, error: agentsError } = await supabase
        .from('user_assigned_agents')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId)
        .eq('status', 'active');
      if (agentsError) throw agentsError;
      setActiveAgentsCount(count || 0);

    } catch (error) {
      toast({ title: "Error loading billing data", description: error.message, variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    const getCurrentUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        setUser(session.user);
        fetchAllBillingData(session.user.id);
      } else {
        setIsLoading(false);
        navigate('/login');
      }
    };
    getCurrentUser();
  }, [fetchAllBillingData, navigate]);

  useEffect(() => {
    const query = new URLSearchParams(location.search);
    if (query.get('tier_upgrade_success')) {
      toast({
        title: "Upgrade Successful!",
        description: "Your subscription tier has been updated.",
        variant: "success",
        duration: 7000,
      });
      if (user) fetchAllBillingData(user.id);
      navigate('/billing', { replace: true });
    }
    if (query.get('tier_upgrade_cancel')) {
      toast({
        title: "Upgrade Canceled",
        description: "Your subscription tier remains unchanged.",
        variant: "info"
      });
      navigate('/billing', { replace: true });
    }
  }, [location.search, toast, navigate, user, fetchAllBillingData]);


  const handleOpenUpgradeDialog = () => {
    setIsUpgradeDialogOpen(true);
  };
  
  const handleManageSubscriptionPortal = async () => {
    if (!user) {
      toast({ title: "Not Authenticated", description: "Please log in.", variant: "destructive" });
      return;
    }
    if (!userProfile?.stripe_customer_id) {
       toast({ title: "Stripe Customer ID Missing", description: "Your Stripe customer ID is not set. Please complete a purchase first or contact support.", variant: "warning", duration: 7000 });
       return;
    }

    setIsPortalLoading(true);
    try {
      const { data, error: functionError } = await supabase.functions.invoke('create-stripe-portal-session', {
        body: JSON.stringify({ return_url: window.location.href }), 
      });

      if (functionError) {
        const errorBody = functionError.context ? await functionError.context.json() : { error: functionError.message };
        throw new Error(errorBody.error || "Failed to create portal session.");
      }
      
      if (data && data.portalUrl) {
        window.location.href = data.portalUrl;
      } else {
        throw new Error("Failed to retrieve Stripe portal URL.");
      }
    } catch (error) {
      toast({ title: "Portal Access Error", description: error.message, variant: "destructive" });
      console.error("Portal Access Error Full:", error);
    } finally {
      setIsPortalLoading(false);
    }
  };


  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background text-foreground">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="ml-4 text-lg">Loading billing information...</p>
      </div>
    );
  }
  
  if (!user) {
    return (
       <div className="flex flex-col items-center justify-center h-screen bg-background text-foreground p-4">
          <AlertTriangle className="h-12 w-12 text-destructive mb-4" />
          <p className="text-xl font-semibold mb-2">Authentication Required</p>
          <p className="text-muted-foreground text-center mb-6">Please log in to view your billing information.</p>
          <Button onClick={() => navigate('/login')} variant="default" className="btn-primary">
            Go to Login
          </Button>
        </div>
    );
  }

  return (
    <motion.div
      className="container mx-auto p-4 md:p-8 bg-background text-foreground"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-primary">Billing & Subscriptions</h1>
        <p className="text-muted-foreground">Manage your subscription, payment methods, and view billing history.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <BillingInfoCard 
            userProfile={userProfile} 
            subscription={subscriptionDetails} 
            activeAgentsCount={activeAgentsCount}
            allSubscriptionTiers={allSubscriptionTiers}
          />
          <BillingHistoryCard userId={user?.id} />
        </div>
        <div className="lg:col-span-1">
          <PaymentActionsCard 
            onManageSubscription={handleManageSubscriptionPortal}
            onUpgradeAccount={handleOpenUpgradeDialog}
            onDowngradeAccount={handleManageSubscriptionPortal} 
            isLoadingPortal={isPortalLoading}
            hasActiveSubscription={!!subscriptionDetails && subscriptionDetails.subscription_status === 'active'}
          />
        </div>
      </div>

      {user && userProfile && (
         <TierUpgradeDialog
            open={isUpgradeDialogOpen}
            onOpenChange={setIsUpgradeDialogOpen}
            currentSubscription={subscriptionDetails}
            allSubscriptionTiers={allSubscriptionTiers}
            userId={user.id}
            userEmail={user.email}
          />
      )}
    </motion.div>
  );
};

export default BillingPage;
