import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2, ShoppingCart } from "lucide-react";
import { getProductIcon } from "@/pages/products/agentData"; 

const CartItemCard = ({ item, onRemoveItem }) => {
  const IconComponent = getProductIcon(item.icon_name) || <ShoppingCart className="h-10 w-10 text-muted-foreground" />;
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="bg-transparent border-2 border-white text-white">
        <CardContent className="p-6 flex flex-col sm:flex-row items-start sm:items-center gap-6">
          <div className="w-24 h-24 bg-black/30 border border-white/20 rounded-md flex items-center justify-center shrink-0">
             {React.cloneElement(IconComponent, { className: "h-10 w-10 text-white/80" })}
          </div>
          <div className="flex-grow">
            <h3 className="text-lg font-semibold text-white">{item.agent_name || "Unnamed Agent"}</h3>
            <p className="text-sm text-gray-400 mb-1 line-clamp-2">{item.description || "AI Agent for enhancing your workflow."}</p>
            <p className="text-sm text-gray-300 mb-2">Category: {item.category || "N/A"}</p>
            <p className="text-lg font-bold text-white">${(item.price_one_time || 0).toFixed(2)}</p>
          </div>
          <Button variant="ghost" size="icon" className="text-gray-300 hover:text-destructive h-8 w-8 sm:ml-auto" onClick={() => onRemoveItem(item.id)}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default CartItemCard;