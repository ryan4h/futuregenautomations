import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, CheckCircle, XCircle, CreditCard, ShieldCheck } from "lucide-react";

const CartCheckoutActions = ({
  isLoadingUserDetails,
  needsUpgradeForCart,
  isProcessingCheckout,
  cartItemCount,
  onProceedToCheckout,
  onNavigateToBilling,
}) => {

  const renderUpgradeButtonOrStatus = () => {
    if (isLoadingUserDetails) {
      return <div className="flex items-center text-sm text-muted-foreground"><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Checking tier status...</div>;
    }
    if (needsUpgradeForCart) {
      return (
        <Button variant="destructive" className="w-full" onClick={onNavigateToBilling}>
          <XCircle className="mr-2 h-5 w-5" /> Upgrade Account to Purchase
        </Button>
      );
    }
    if (cartItemCount > 0) { // Only show if items in cart
      return (
        <div className="flex items-center justify-center text-sm text-green-500 p-2 bg-green-500/10 rounded-md">
          <CheckCircle className="mr-2 h-5 w-5" /> Tier allows purchase.
        </div>
      );
    }
    return null; // Don't show anything if cart is empty
  };

  return (
    <Card className="bg-transparent border-2 border-white text-white">
      <CardContent className="pt-6 space-y-4">
        {renderUpgradeButtonOrStatus()}
        <Button 
          variant="outline"
          className="w-full" 
          onClick={onProceedToCheckout}
          disabled={isProcessingCheckout || cartItemCount === 0 || needsUpgradeForCart || isLoadingUserDetails}
        >
          {isProcessingCheckout ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <><CreditCard className="mr-2 h-5 w-5" /> Proceed to Checkout</>}
        </Button>
        {cartItemCount > 0 && (
          <div className="mt-4 flex items-center justify-center text-xs text-muted-foreground">
            <ShieldCheck className="h-4 w-4 mr-1 text-green-500" />
            <span>Secure checkout via Stripe.</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CartCheckoutActions;