import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

const PaymentForm = ({ paymentDetails, onInputChange, onSubmit, total, isLoading }) => {
  return (
    <Card id="payment-form" className="bg-card border-border mt-8">
      <CardHeader>
        <CardTitle className="text-card-foreground">Payment Details</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <Label htmlFor="nameOnCard" className="text-card-foreground">Name on Card</Label>
            <Input 
              id="nameOnCard" 
              name="nameOnCard"
              type="text" 
              placeholder="John M Doe" 
              value={paymentDetails.nameOnCard}
              onChange={onInputChange}
              className="mt-1 bg-input border-border text-foreground placeholder:text-muted-foreground" 
              required 
            />
          </div>
          <div>
            <Label htmlFor="cardNumber" className="text-card-foreground">Card Number</Label>
            <Input 
              id="cardNumber" 
              name="cardNumber"
              type="text" 
              placeholder="•••• •••• •••• ••••" 
              value={paymentDetails.cardNumber}
              onChange={onInputChange}
              className="mt-1 bg-input border-border text-foreground placeholder:text-muted-foreground" 
              required 
            />
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="expiryDate" className="text-card-foreground">Expiry</Label>
              <Input 
                id="expiryDate" 
                name="expiryDate"
                type="text" 
                placeholder="MM/YY" 
                value={paymentDetails.expiryDate}
                onChange={onInputChange}
                className="mt-1 bg-input border-border text-foreground placeholder:text-muted-foreground" 
                required 
              />
            </div>
            <div>
              <Label htmlFor="cvc" className="text-card-foreground">CVC</Label>
              <Input 
                id="cvc" 
                name="cvc"
                type="text" 
                placeholder="•••" 
                value={paymentDetails.cvc}
                onChange={onInputChange}
                className="mt-1 bg-input border-border text-foreground placeholder:text-muted-foreground" 
                required 
              />
            </div>
              <div>
              <Label htmlFor="zipCode" className="text-card-foreground">ZIP Code</Label>
              <Input 
                id="zipCode" 
                name="zipCode"
                type="text" 
                placeholder="12345" 
                value={paymentDetails.zipCode}
                onChange={onInputChange}
                className="mt-1 bg-input border-border text-foreground placeholder:text-muted-foreground" 
                required 
              />
            </div>
          </div>
          <Button type="submit" className="w-full btn-minimal mt-6" disabled={isLoading}>
            {isLoading ? "Processing..." : `Pay ${total.toFixed(2)}`}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default PaymentForm;