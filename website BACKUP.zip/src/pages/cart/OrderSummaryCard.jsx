import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

const OrderSummaryCard = ({ subtotal, total }) => { // Removed taxAmount and onProceedToPayment
  return (
    <Card className="bg-transparent border-2 border-white text-white"> {/* Removed sticky and top-24 */}
      <CardHeader>
        <CardTitle className="text-white">Order Summary</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-between text-gray-300">
          <span>Subtotal</span>
          <span className="text-white">${subtotal.toFixed(2)}</span>
        </div>
        {/* Tax section removed */}
        <Separator className="bg-white/30" />
        <div className="flex justify-between text-xl font-bold text-white">
          <span>Total</span>
          <span>${total.toFixed(2)}</span>
        </div>
      </CardContent>
      {/* CardFooter with Proceed to Payment button removed, will be handled by a separate Checkout card */}
    </Card>
  );
};

export default OrderSummaryCard;