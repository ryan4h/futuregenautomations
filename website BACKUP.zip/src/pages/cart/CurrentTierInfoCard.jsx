import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChart3 } from "lucide-react";

const CurrentTierInfoCard = ({ isLoading, currentSubscription, activeAgentCount }) => {
  if (isLoading) {
    return (
      <Card className="bg-transparent border-2 border-white text-white">
        <CardHeader>
          <CardTitle className="text-xl flex items-center">
            <BarChart3 className="mr-2 h-5 w-5" /> Current Tier
          </CardTitle>
          <CardDescription className="text-muted-foreground">Loading your subscription details...</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
          <Skeleton className="h-4 w-2/3" />
        </CardContent>
      </Card>
    );
  }

  const tierName = currentSubscription?.current_tier_name || "No Active Tier";
  const maxAgents = typeof currentSubscription?.max_agents === 'number' ? currentSubscription.max_agents : "Unknown";
  
  let agentUsageText = `${activeAgentCount} / ${maxAgents} Agents Active`;
  if (maxAgents === "Unknown" && activeAgentCount > 0) {
    agentUsageText = `${activeAgentCount} Agents Active (Limit Unknown)`;
  } else if (maxAgents === "Unknown" && activeAgentCount === 0) {
     agentUsageText = "No active agents (Limit Unknown)";
  }


  return (
    <Card className="bg-transparent border-2 border-white text-white">
      <CardHeader>
        <CardTitle className="text-xl flex items-center">
            <BarChart3 className="mr-2 h-5 w-5" /> Current Tier
        </CardTitle>
        <CardDescription className="text-muted-foreground">Your current subscription status and agent usage.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <p className="text-lg font-semibold">
            Tier: <span className="text-primary">{tierName}</span>
          </p>
          <p className="text-sm">
            {agentUsageText}
          </p>
          {maxAgents === "Unknown" && (
             <p className="text-xs text-amber-400">Agent limit could not be determined. Please check your subscription on the Billing page or contact support.</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default CurrentTierInfoCard;