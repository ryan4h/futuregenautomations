import { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { loadStripe } from '@stripe/stripe-js';
import { useToast } from "@/components/ui/use-toast";

const STRIPE_PUBLISHABLE_KEY = 'pk_live_51RQ3IkDm0AzRryHihPdGiAwNeQyHy6xPOLPqYDf8aH0RnyODqxI3Rl8EqkaigYwFMBCudcGmulJp67UbitXTGM8q00a1m4j3TB';
const stripePromise = loadStripe(STRIPE_PUBLISHABLE_KEY);

export const useStripeCheckout = () => {
  const { toast } = useToast();
  const [isProcessingCheckout, setIsProcessingCheckout] = useState(false);

  const processCheckout = async (user, cartItems, needsUpgradeForCart, isLoadingUserDetails, setNeedsUpgradeForCartCallback) => {
    if (!user) {
      toast({ title: "Not Logged In", description: "Please log in to proceed.", variant: "destructive" });
      return { success: false, reason: "login_required" };
    }
    if (cartItems.length === 0) {
      toast({ title: "Empty Cart", description: "Your cart is empty.", variant: "destructive" });
      return { success: false, reason: "empty_cart" };
    }
    if (isLoadingUserDetails) {
      toast({ title: "Please wait", description: "User details are still loading.", variant: "default" });
      return { success: false, reason: "loading_details" };
    }
    if (needsUpgradeForCart) {
      toast({ title: "Upgrade Required", description: "Your current tier doesn't support this many agents. Please upgrade your account.", variant: "warning", duration: 7000 });
      return { success: false, reason: "upgrade_required_frontend" };
    }

    setIsProcessingCheckout(true);
    try {
      const lineItemsPayload = cartItems.map(item => {
        if (!item.stripe_price_id) {
          console.warn(`Stripe Price ID missing for cart item: ${item.agent_name}. This item will be skipped.`);
          toast({ title: "Item Skipped", description: `${item.agent_name} is missing a Price ID and was skipped.`, variant: "warning"});
          return null; 
        }
        return { priceId: item.stripe_price_id, quantity: 1, type: 'one_time' };
      }).filter(item => item !== null);

      if (lineItemsPayload.length === 0) {
        toast({ title: "Checkout Error", description: "No items with valid Stripe Price IDs in cart to proceed.", variant: "destructive" });
        setIsProcessingCheckout(false);
        return { success: false, reason: "no_valid_items" };
      }

      const { data: checkoutSessionData, error: functionError, status } = await supabase.functions.invoke('create-stripe-checkout-session', {
        body: JSON.stringify({
          userId: user.id,
          userEmail: user.email,
          lineItemsPayload: lineItemsPayload,
          checkoutMode: 'agents_only',
          metadata: { 
            session_metadata: { cart_checkout_agents_only: "true", items_count: lineItemsPayload.length.toString(), user_id: user.id }
          }
        }),
      });
      
      const errorBody = functionError ? (typeof functionError.context?.json === 'function' ? await functionError.context.json() : { message: functionError.message}) : (checkoutSessionData || {message: `Function returned status ${status}`});

      if (functionError || status === 402 || (checkoutSessionData && checkoutSessionData.error_code === "UPGRADE_REQUIRED") ) { 
        if (errorBody?.error_code === "UPGRADE_REQUIRED") {
          if (setNeedsUpgradeForCartCallback) setNeedsUpgradeForCartCallback(true); 
          toast({ title: "Upgrade Required", description: errorBody.message || "Please upgrade your tier from the Billing page.", variant: "warning", duration: 7000});
          return { success: false, reason: "upgrade_required_backend" };
        } else {
          console.error("Error invoking create-stripe-checkout-session (agents_only):", errorBody);
          throw new Error(errorBody?.message || `Unknown checkout error (Status: ${status})`);
        }
      } else if (checkoutSessionData && checkoutSessionData.sessionId) {
        const stripe = await stripePromise;
        if (!stripe) {
          throw new Error("Stripe.js failed to load.");
        }
        const { error: stripeError } = await stripe.redirectToCheckout({ sessionId: checkoutSessionData.sessionId });
        if (stripeError) {
          toast({ title: "Stripe Error", description: stripeError.message, variant: "destructive" });
          return { success: false, reason: "stripe_redirect_error", error: stripeError };
        }
        return { success: true }; 
      } else if (checkoutSessionData && checkoutSessionData.error) {
         toast({ title: "Checkout Error", description: checkoutSessionData.error, variant: "destructive" });
         return { success: false, reason: "checkout_session_error", error: checkoutSessionData.error };
      } else {
         console.error("No sessionId received from Edge Function (agents_only):", checkoutSessionData);
         toast({ title: "Checkout Error", description: "Could not create checkout session. Please try again.", variant: "destructive" });
         return { success: false, reason: "unknown_session_creation_error" };
      }
    } catch (error) {
      toast({ title: "Checkout Failed", description: `Error: ${error.message}`, variant: "destructive" });
      return { success: false, reason: "general_error", error: error };
    } finally {
      setIsProcessingCheckout(false);
    }
    return { success: false, reason: "unhandled_path" }; 
  };

  return { isProcessingCheckout, processCheckout };
};