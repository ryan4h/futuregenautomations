import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from "@/components/ui/use-toast";
import { fetchUserSubscriptionDetails, fetchUserAssignedAgents } from "@/pages/agents/services/agentDataService";

export const useCartUserData = () => {
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [currentActiveAgentCount, setCurrentActiveAgentCount] = useState(0);
  const [currentSubscription, setCurrentSubscription] = useState(null);
  const [isLoadingUserDetails, setIsLoadingUserDetails] = useState(true);

  const fetchInitialData = useCallback(async (userId) => {
    if (!userId) {
      setIsLoadingUserDetails(false);
      return;
    }
    setIsLoadingUserDetails(true);
    try {
      const [agents, subDetails] = await Promise.all([
        fetchUserAssignedAgents(userId, toast),
        fetchUserSubscriptionDetails(userId, toast),
      ]);
      setCurrentActiveAgentCount(agents.filter(a => a.status === 'active').length);
      setCurrentSubscription(subDetails);
    } catch (error) {
      console.error("Error fetching user data for cart:", error);
      toast({ title: "Data Fetch Error", description: "Could not load all user details for the cart.", variant: "warning" });
    } finally {
      setIsLoadingUserDetails(false);
    }
  }, [toast]);

  useEffect(() => {
    const getSession = async () => {
      if (!supabase) {
        setIsLoadingUserDetails(false);
        return;
      }
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user || null);
      if (session?.user) {
        fetchInitialData(session.user.id);
      } else {
        setIsLoadingUserDetails(false);
      }
    };
    getSession();

    if (!supabase) return;
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null);
      if (session?.user) {
        fetchInitialData(session.user.id);
      } else {
        setCurrentActiveAgentCount(0);
        setCurrentSubscription(null);
        setIsLoadingUserDetails(false);
      }
    });
    
    return () => authListener?.subscription.unsubscribe();
  }, [fetchInitialData]);

  return {
    user,
    currentActiveAgentCount,
    currentSubscription,
    isLoadingUserDetails,
    fetchInitialData // Expose if manual refresh is needed
  };
};