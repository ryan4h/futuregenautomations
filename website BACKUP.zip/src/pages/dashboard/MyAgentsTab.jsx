import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Settings } from "lucide-react";
import { useNavigate } from 'react-router-dom';

const MyAgentItem = ({ agent }) => {
  const navigate = useNavigate(); 

  const handleManageAgent = () => {
    navigate('/agents'); 
  };

  return (
    <div className="grid grid-cols-3 sm:grid-cols-4 gap-4 p-3 items-center text-sm border-b border-border last:border-b-0">
      <div className="font-medium truncate text-card-foreground col-span-1 sm:col-span-1">{agent.agent_name}</div>
      <div className="truncate text-muted-foreground hidden sm:block">{agent.category || 'N/A'}</div>
      <div>
        <Badge variant={agent.status === "active" ? "success" : "secondary"} className={`border-2 ${agent.status === "active" ? "border-green-500 text-green-400" : "border-gray-500 text-gray-400"} bg-transparent`}>
          {agent.status}
        </Badge>
      </div>
      <div className="text-right">
        <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80" onClick={handleManageAgent}>
          <Settings className="mr-1 h-4 w-4 sm:mr-2" /> 
          <span className="hidden sm:inline">Manage</span>
        </Button>
      </div>
    </div>
  );
};


const MyAgentsTab = ({ agents, isLoading }) => {
  const navigate = useNavigate();
  return (
    <Card className="bg-card border-border">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-card-foreground">Your AI Agents</CardTitle>
        <Button size="sm" variant="outline" className="border-2 border-white bg-transparent hover:bg-white/10" onClick={() => navigate('/products')}>Add Agents</Button>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-4 text-muted-foreground">Loading agents...</div>
        ) : agents.length > 0 ? (
          <div className="rounded-md border border-border">
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-4 p-3 font-medium border-b border-border bg-accent/50 text-accent-foreground">
              <div className="col-span-1 sm:col-span-1">Agent Name</div>
              <div className="hidden sm:block">Category</div>
              <div>Status</div>
              <div className="text-right">Actions</div>
            </div>
            <div className="divide-y divide-border">
              {agents.map((agent) => <MyAgentItem key={agent.assigned_agent_id} agent={agent} />)}
            </div>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground text-center py-6">You have no active AI agents. <Button variant="link" className="p-0 h-auto text-primary" onClick={() => navigate('/products')}>Browse marketplace</Button></p>
        )}
      </CardContent>
    </Card>
  );
};

export default MyAgentsTab;