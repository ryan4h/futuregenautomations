import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area"; 

const RecentTaskItem = ({ task }) => {
  const getStatusVariant = (status) => {
    switch (status?.toLowerCase()) {
      case 'completed':
        return 'success';
      case 'active':
      case 'outgoing':
        return 'default';
      case 'error':
      case 'stopped':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  return (
  <div className="flex items-center justify-between py-3 border-b border-border last:border-b-0">
    <div>
      <p className="font-medium text-sm text-card-foreground truncate max-w-[200px] sm:max-w-xs">{task.agent_name || 'Unnamed Task'}</p>
      <p className="text-xs text-muted-foreground">
        {task.last_run_at ? `Last activity: ${new Date(task.last_run_at).toLocaleDateString()}` : 'No activity yet'}
      </p>
    </div>
    <Badge variant={getStatusVariant(task.status)} className="whitespace-nowrap">
      {task.status || 'Unknown'}
    </Badge>
  </div>
)};

const RecentTasksList = ({ tasks, isLoading }) => {
  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-card-foreground">Recent Agent Activity</CardTitle>
        <CardDescription className="text-muted-foreground">Latest updates from your agents tasks.</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          Array(3).fill(0).map((_, i) => <div key={i} className="h-12 mb-2 bg-muted animate-pulse rounded"></div>)
        ) : tasks.length > 0 ? (
          <ScrollArea className="h-[200px] sm:h-[240px]">
            <div className="space-y-1 pr-3">
              {tasks.map((task) => <RecentTaskItem key={task.id} task={task} />)}
            </div>
          </ScrollArea>
        ) : (
          <p className="text-sm text-muted-foreground text-center py-4">No recent task activity from your agents.</p>
        )}
      </CardContent>
    </Card>
  );
};

export default RecentTasksList;