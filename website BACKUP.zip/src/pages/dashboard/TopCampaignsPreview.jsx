import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area"; 

const CampaignItem = ({ campaign }) => {
  const getStatusVariant = (status) => {
    switch (status?.toLowerCase()) {
      case 'active':
        return 'success';
      case 'paused':
        return 'warning';
      case 'completed':
        return 'default'; 
      case 'draft':
      default:
        return 'secondary';
    }
  };
  return (
  <div className="flex items-center justify-between py-3 border-b border-border last:border-b-0">
    <div>
      <p className="font-medium text-sm text-card-foreground truncate max-w-[150px] sm:max-w-xs">{campaign.campaign_name}</p>
      <p className="text-xs text-muted-foreground">{campaign.platform}</p>
    </div>
    <Badge variant={getStatusVariant(campaign.status)} className="whitespace-nowrap">
      {campaign.status || 'N/A'}
    </Badge>
  </div>
)};

const TopCampaignsPreview = ({ campaigns, isLoading, navigate }) => {
  const topCampaigns = campaigns.slice(0, 3);

  return (
    <Card className="bg-card border-border">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-card-foreground">Ad Campaigns</CardTitle>
          <CardDescription className="text-muted-foreground">Quick look at your leading campaigns.</CardDescription>
        </div>
        <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80" onClick={() => navigate('/ad-campaigns')}>
          View All <ArrowRight className="ml-1 h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          Array(3).fill(0).map((_, i) => <div key={i} className="h-12 mb-2 bg-muted animate-pulse rounded"></div>)
        ) : topCampaigns.length > 0 ? (
           <ScrollArea className="h-[200px] sm:h-[240px]">
            <div className="space-y-1 pr-3">
              {topCampaigns.map((campaign) => <CampaignItem key={campaign.id} campaign={campaign} />)}
            </div>
          </ScrollArea>
        ) : (
          <p className="text-sm text-muted-foreground text-center py-4">No active campaigns to display.</p>
        )}
      </CardContent>
    </Card>
  );
};

export default TopCampaignsPreview;