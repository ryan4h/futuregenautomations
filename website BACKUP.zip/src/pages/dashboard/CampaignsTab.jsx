import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

const CampaignItem = ({ campaign }) => {
  const getStatusVariant = (status) => {
    switch (status?.toLowerCase()) {
      case 'active':
        return 'success';
      case 'paused':
        return 'warning';
      case 'completed':
        return 'default';
      case 'draft':
      default:
        return 'secondary';
    }
  };

  return (
    <div className="grid grid-cols-3 sm:grid-cols-5 gap-4 p-3 items-center text-sm border-b border-border last:border-b-0">
      <div className="font-medium truncate col-span-2 sm:col-span-1 text-card-foreground">{campaign.campaign_name}</div>
      <div className="hidden sm:block truncate text-muted-foreground">{campaign.platform}</div>
      <div>
        <Badge variant={getStatusVariant(campaign.status)} className="whitespace-nowrap">
          {campaign.status || 'N/A'}
        </Badge>
      </div>
      <div className="hidden sm:block text-right text-muted-foreground">${(campaign.spent || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
      <div className="text-right text-card-foreground">{campaign.conversions || 0}</div>
    </div>
  );
};

const CampaignsTab = ({ campaigns, isLoading, navigate }) => {
  return (
    <Card className="bg-card border-border">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-card-foreground">All Ad Campaigns</CardTitle>
        <Button size="sm" className="btn-minimal" onClick={() => navigate('/ad-campaigns')}>Manage Campaigns</Button>
      </CardHeader>
      <CardContent>
        {isLoading ? (
           <div className="text-center py-4 text-muted-foreground">Loading campaigns...</div>
        ) : campaigns.length > 0 ? (
          <div className="rounded-md border border-border">
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-4 p-3 font-semibold border-b border-border bg-accent/50 text-xs sm:text-sm text-accent-foreground sticky top-0 z-10">
              <div className="col-span-2 sm:col-span-1">Campaign</div>
              <div className="hidden sm:block">Platform</div>
              <div>Status</div>
              <div className="hidden sm:block text-right">Spent</div>
              <div className="text-right">Conversions</div>
            </div>
            <ScrollArea className="h-[300px] md:h-[400px]">
              <div className="divide-y divide-border">
                {campaigns.map((campaign) => <CampaignItem key={campaign.id} campaign={campaign} />)}
              </div>
            </ScrollArea>
          </div>
        ) : (
           <p className="text-sm text-muted-foreground text-center py-6">No ad campaigns found. <Button variant="link" className="p-0 h-auto text-primary" onClick={() => navigate('/ad-campaigns')}>Create one</Button></p>
        )}
      </CardContent>
    </Card>
  );
};

export default CampaignsTab;