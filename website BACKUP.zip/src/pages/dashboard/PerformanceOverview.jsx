import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { motion } from "framer-motion";

const MetricCard = ({ title, value, icon, isLoading, navigateTo, navigate }) => {
  const handleClick = () => {
    if (navigateTo) {
      navigate(navigateTo);
    }
  };

  return (
    <motion.div 
      className={`bg-black/40 backdrop-blur-sm border-white/20 shadow-lg rounded-lg transition-all duration-300 ${navigateTo ? 'cursor-pointer hover:shadow-[0_0_15px_5px_rgba(255,255,255,0.2)] hover:border-white/50' : ''}`}
      whileHover={navigateTo ? { scale: 1.03 } : {}}
      onClick={handleClick}
    >
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium text-gray-200">{title}</p>
          <div className="text-gray-100">{icon}</div>
        </div>
        {isLoading ? <div className="h-8 mt-2 bg-white/20 animate-pulse rounded"></div> : <p className="text-3xl font-bold text-white mt-1">{value}</p>}
      </CardContent>
    </motion.div>
  );
};


const PerformanceOverview = ({ metrics, isLoading, navigate }) => {
  return (
    <Card className="dashboard-performance-bg">
      <CardHeader className="dashboard-performance-content">
        <CardTitle className="text-xl text-white">Performance Overview</CardTitle>
        <CardDescription className="text-gray-300">Key metrics from your automated tasks.</CardDescription>
      </CardHeader>
      <CardContent className="dashboard-performance-content grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {metrics.map((stat) => (
          <MetricCard 
            key={stat.title} 
            title={stat.title}
            value={stat.value}
            icon={stat.icon}
            isLoading={isLoading}
            navigateTo={stat.navigateTo}
            navigate={navigate}
          />
        ))}
      </CardContent>
    </Card>
  );
};

export default PerformanceOverview;