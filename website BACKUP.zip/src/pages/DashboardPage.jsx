import React, { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { 
  Mail, Star, Users2, CheckSquare, 
  RefreshCw
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/lib/supabaseClient";
import { useNavigate } from "react-router-dom";
import PerformanceOverview from "./dashboard/PerformanceOverview";
import RecentTasksList from "./dashboard/RecentTasksList";
import TopCampaignsPreview from "./dashboard/TopCampaignsPreview";
import MyAgentsTab from "./dashboard/MyAgentsTab";
import CampaignsTab from "./dashboard/CampaignsTab";

const DashboardPage = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");

  const [dashboardStats, setDashboardStats] = useState({
    emailsSent: 0,
    reviewsObtained: 0,
    leadsGenerated: 0,
    tasksCompleted: 0,
  });
  const [recentTasks, setRecentTasks] = useState([]);
  const [userCampaigns, setUserCampaigns] = useState([]);
  const [userAssignedAgents, setUserAssignedAgents] = useState([]);

  const fetchData = useCallback(async (currentUserId, currentUserEmail) => {
    if (!currentUserId || !currentUserEmail) {
      setIsLoading(false); 
      return;
    }
    setIsLoading(true);

    try {
      const tasksQuery = supabase
        .from('zapier_task_data')
        .select('agent_name, status, tasks_completed, emails_sent, reviews_requested, leads_captured, created_at, agent_id')
        .eq('user_email', currentUserEmail)
        .order('created_at', { ascending: false });

      const campaignsQuery = supabase
        .from('users_ad_campaigns')
        .select('id, campaign_name, platform, status, budget, spent, impressions, clicks, conversions, start_date, end_date, daily_budget, api_endpoint')
        .eq('user_id', currentUserId)
        .order('created_at', { ascending: false });
      
      const agentsQuery = supabase
        .from('user_assigned_agents')
        .select('assigned_agent_id, agent_name, status, category, purchased_at, config_details')
        .eq('user_id', currentUserId)
        .order('created_at', { ascending: false });

      const [tasksResponse, campaignsResponse, agentsResponse] = await Promise.all([
        tasksQuery,
        campaignsQuery,
        agentsQuery
      ]);

      if (tasksResponse.error) {
        toast({ title: "Error fetching tasks", description: tasksResponse.error.message, variant: "destructive" });
      }
      const tasksData = tasksResponse.data || [];
      
      const leads = tasksData.reduce((sum, t) => sum + (t.leads_captured || 0), 0);
      const emails = tasksData.reduce((sum, t) => sum + (t.emails_sent || 0), 0);
      const reviews = tasksData.reduce((sum, t) => sum + (t.reviews_requested || 0), 0); 
      const completed = tasksData.reduce((sum, t) => sum + (t.tasks_completed || 0), 0);
      
      setDashboardStats({ 
        leadsGenerated: leads, 
        emailsSent: emails, 
        reviewsObtained: reviews, 
        tasksCompleted: completed 
      });
      setRecentTasks(tasksData.slice(0, 5).map(t => ({
        id: t.agent_id,
        agent_name: t.agent_name,
        last_run_at: t.created_at, 
        status: t.status || 'unknown'
      })));
      
      if (campaignsResponse.error) {
        toast({ title: "Error fetching campaigns", description: campaignsResponse.error.message, variant: "destructive" });
      }
      setUserCampaigns(campaignsResponse.data || []);

      if (agentsResponse.error) {
        toast({ title: "Error fetching agents", description: agentsResponse.error.message, variant: "destructive" });
      }
      setUserAssignedAgents(agentsResponse.data || []);

    } catch (error) {
      toast({ title: "Dashboard Error", description: "Could not load all dashboard data.", variant: "destructive"});
      console.error("Dashboard fetch error:", error);
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    const getSessionAndData = async () => {
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError) {
         toast({ title: "Authentication Error", description: sessionError.message, variant: "destructive" });
         setIsLoading(false);
         navigate("/login");
         return;
      }

      if (session?.user) {
        setUser(session.user);
        if (session.user.email) {
          fetchData(session.user.id, session.user.email);
        } else {
          toast({ title: "User Data Incomplete", description: "User email is not available. Cannot fetch all data.", variant: "warning" });
          setIsLoading(false);
        }
      } else {
        setIsLoading(false);
        navigate("/login");
      }
    };
    getSessionAndData();
  }, [fetchData, navigate, toast]);

  const handleRefresh = () => {
    if (user && user.email) {
      toast({ title: "Refreshing dashboard data..." });
      fetchData(user.id, user.email);
    } else if (user && !user.email) {
      toast({ title: "Cannot Refresh", description: "User email is missing. Unable to fetch task data.", variant: "warning" });
    }
  };
  
  const performanceMetrics = [
    { title: "Leads Generated", value: dashboardStats.leadsGenerated.toLocaleString(), icon: <Users2 className="h-6 w-6" />, navigateTo: "/tasks" },
    { title: "Emails Sent", value: dashboardStats.emailsSent.toLocaleString(), icon: <Mail className="h-6 w-6" />, navigateTo: "/tasks" },
    { title: "Reviews Obtained", value: dashboardStats.reviewsObtained.toLocaleString(), icon: <Star className="h-6 w-6" />, navigateTo: "/tasks" },
    { title: "Tasks Completed", value: dashboardStats.tasksCompleted.toLocaleString(), icon: <CheckSquare className="h-6 w-6" />, navigateTo: "/tasks" },
  ];


  return (
    <div className="container py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">
            Overview of your marketing performance and automations.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="btn-minimal" onClick={handleRefresh} disabled={isLoading || !user?.email}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="mb-8" onValueChange={setActiveTab}>
        <TabsList className="bg-card border-border">
          <TabsTrigger value="overview" className="data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">Overview</TabsTrigger>
          <TabsTrigger value="my-agents" className="data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">My Agents</TabsTrigger>
          <TabsTrigger value="campaigns" className="data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">Campaigns</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6 mt-6">
          <PerformanceOverview metrics={performanceMetrics} isLoading={isLoading} navigate={navigate} />
          <div className="grid gap-6 md:grid-cols-2">
            <RecentTasksList tasks={recentTasks} isLoading={isLoading} />
            <TopCampaignsPreview campaigns={userCampaigns} isLoading={isLoading} navigate={navigate} />
          </div>
        </TabsContent>

        <TabsContent value="my-agents" className="space-y-4 mt-6">
          <MyAgentsTab agents={userAssignedAgents} isLoading={isLoading} navigate={navigate} />
        </TabsContent>

        <TabsContent value="campaigns" className="space-y-4 mt-6">
          <CampaignsTab campaigns={userCampaigns} isLoading={isLoading} navigate={navigate} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DashboardPage;