import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  BarChartHorizontalBig, CheckCircle2, Mail, MessageSquare, TrendingUp, XCircle, Edit3, Trash2
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const TaskCard = ({ task, onEdit, onDelete, onUpdateStatus }) => {
  const totalSubTasks = (task.tasks_outgoing || 0) + (task.tasks_completed || 0) + (task.tasks_stopped || 0);
  const completionPercentage = totalSubTasks > 0 ? ((task.tasks_completed || 0) / totalSubTasks) * 100 : 0;

  let statusVariant = "secondary";
  if (task.status === "completed") statusVariant = "success";
  else if (task.status === "outgoing") statusVariant = "default";
  else if (task.status === "stopped") statusVariant = "destructive";
  else if (task.status === "error") statusVariant = "destructive";

  return (
    <Card className="bg-card border-border hover:shadow-lg transition-shadow flex flex-col">
      <CardHeader>
        <div className="flex justify-between items-start">
          <CardTitle className="text-card-foreground text-lg">{task.agent_name}</CardTitle>
          <Badge variant={statusVariant}>
            {task.status.charAt(0).toUpperCase() + task.status.slice(1)}
          </Badge>
        </div>
        <CardDescription className="text-muted-foreground text-sm h-10 overflow-y-auto">
          {task.task_description || "No description provided."}
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-grow space-y-3">
        <div className="space-y-1">
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Progress</span>
            <span>{completionPercentage.toFixed(0)}%</span>
          </div>
          <Progress value={completionPercentage} className="h-2" />
        </div>
        <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
          <div className="flex items-center">
            <BarChartHorizontalBig className="h-4 w-4 mr-2 text-blue-500 shrink-0" />
            <span>Outgoing: {(task.tasks_outgoing || 0).toLocaleString()}</span>
          </div>
          <div className="flex items-center">
            <CheckCircle2 className="h-4 w-4 mr-2 text-green-500 shrink-0" />
            <span>Completed: {(task.tasks_completed || 0).toLocaleString()}</span>
          </div>
          <div className="flex items-center">
            <XCircle className="h-4 w-4 mr-2 text-red-500 shrink-0" />
            <span>Stopped: {(task.tasks_stopped || 0).toLocaleString()}</span>
          </div>
          {task.emails_sent !== null && task.emails_sent > 0 && (
            <div className="flex items-center">
              <Mail className="h-4 w-4 mr-2 text-purple-500 shrink-0" />
              <span>Emails Sent: {task.emails_sent.toLocaleString()}</span>
            </div>
          )}
          {task.reviews_requested !== null && task.reviews_requested > 0 && (
            <div className="flex items-center">
              <TrendingUp className="h-4 w-4 mr-2 text-yellow-500 shrink-0" />
              <span>Reviews Req.: {task.reviews_requested.toLocaleString()}</span>
            </div>
          )}
           {task.tickets_resolved !== null && task.tickets_resolved > 0 && (
            <div className="flex items-center">
              <MessageSquare className="h-4 w-4 mr-2 text-indigo-500 shrink-0" />
              <span>Tickets Resolved: {task.tickets_resolved.toLocaleString()}</span>
            </div>
          )}
           {task.leads_captured !== null && task.leads_captured > 0 && (
            <div className="flex items-center">
              <TrendingUp className="h-4 w-4 mr-2 text-teal-500 shrink-0" />
              <span>Leads Captured: {task.leads_captured.toLocaleString()}</span>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between items-center pt-4 border-t border-border">
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary" onClick={() => onEdit(task)}>
            <Edit3 className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => onDelete(task.id)}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
        <Select value={task.status} onValueChange={(newStatus) => onUpdateStatus(task.id, newStatus)}>
          <SelectTrigger className="w-[120px] h-8 text-xs btn-minimal">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="outgoing">Outgoing</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="stopped">Stopped</SelectItem>
            <SelectItem value="error">Error</SelectItem>
          </SelectContent>
        </Select>
      </CardFooter>
    </Card>
  );
};

export default TaskCard;