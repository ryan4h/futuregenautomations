import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea"; 
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const TaskFormDialog = ({ open, onOpenChange, task, onSubmit, availableAgents }) => {
  const initialFormData = {
    agent_name: '',
    task_description: '',
    status: 'outgoing',
    tasks_completed: 0,
    tasks_outgoing: 0,
    tasks_stopped: 0,
    emails_sent: 0,
    reviews_requested: 0,
    tickets_resolved: 0,
    leads_captured: 0,
  };
  
  const [formData, setFormData] = useState(initialFormData);

  useEffect(() => {
    if (task) {
      setFormData({
        agent_name: task.agent_name || '',
        task_description: task.task_description || '',
        status: task.status || 'outgoing',
        tasks_completed: task.tasks_completed || 0,
        tasks_outgoing: task.tasks_outgoing || 0,
        tasks_stopped: task.tasks_stopped || 0,
        emails_sent: task.emails_sent || 0,
        reviews_requested: task.reviews_requested || 0,
        tickets_resolved: task.tickets_resolved || 0,
        leads_captured: task.leads_captured || 0,
      });
    } else {
      setFormData({
        ...initialFormData,
        agent_name: availableAgents && availableAgents.length > 0 ? availableAgents[0] : 'Generic Task',
      });
    }
  }, [task, availableAgents, open]); // Rerun if `open` changes to reset form when re-opened for new task

  const handleChange = (e) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'number' ? parseInt(value, 10) || 0 : value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[525px] bg-card border-border text-foreground">
        <DialogHeader>
          <DialogTitle>{task ? 'Edit Task' : 'Create New Task'}</DialogTitle>
          <DialogDescription>
            {task ? 'Update the details of your AI agent task.' : 'Fill in the details for a new AI agent task.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="agent_name" className="text-right">Agent Name</Label>
            <Select 
              name="agent_name"
              value={formData.agent_name} 
              onValueChange={(value) => handleSelectChange("agent_name", value)}
            >
              <SelectTrigger className="col-span-3 bg-input border-border">
                <SelectValue placeholder="Select Agent" />
              </SelectTrigger>
              <SelectContent>
                {(availableAgents && availableAgents.length > 0 ? availableAgents : ["Generic Task"]).map(agent => (
                  <SelectItem key={agent} value={agent}>{agent}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="task_description" className="text-right">Description</Label>
            <Textarea 
              id="task_description" 
              name="task_description" 
              value={formData.task_description} 
              onChange={handleChange} 
              className="col-span-3 bg-input border-border" 
              placeholder="Describe the task..."
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="status" className="text-right">Status</Label>
            <Select name="status" value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
              <SelectTrigger className="col-span-3 bg-input border-border">
                <SelectValue placeholder="Select Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="outgoing">Outgoing</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="stopped">Stopped</SelectItem>
                <SelectItem value="error">Error</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="tasks_outgoing">Outgoing Count</Label>
              <Input id="tasks_outgoing" name="tasks_outgoing" type="number" value={formData.tasks_outgoing} onChange={handleChange} className="bg-input border-border" />
            </div>
            <div>
              <Label htmlFor="tasks_completed">Completed Count</Label>
              <Input id="tasks_completed" name="tasks_completed" type="number" value={formData.tasks_completed} onChange={handleChange} className="bg-input border-border" />
            </div>
            <div>
              <Label htmlFor="tasks_stopped">Stopped Count</Label>
              <Input id="tasks_stopped" name="tasks_stopped" type="number" value={formData.tasks_stopped} onChange={handleChange} className="bg-input border-border" />
            </div>
            <div>
              <Label htmlFor="emails_sent">Emails Sent</Label>
              <Input id="emails_sent" name="emails_sent" type="number" value={formData.emails_sent} onChange={handleChange} className="bg-input border-border" />
            </div>
             <div>
              <Label htmlFor="reviews_requested">Reviews Requested</Label>
              <Input id="reviews_requested" name="reviews_requested" type="number" value={formData.reviews_requested} onChange={handleChange} className="bg-input border-border" />
            </div>
             <div>
              <Label htmlFor="tickets_resolved">Tickets Resolved</Label>
              <Input id="tickets_resolved" name="tickets_resolved" type="number" value={formData.tickets_resolved} onChange={handleChange} className="bg-input border-border" />
            </div>
            <div>
              <Label htmlFor="leads_captured">Leads Captured</Label>
              <Input id="leads_captured" name="leads_captured" type="number" value={formData.leads_captured} onChange={handleChange} className="bg-input border-border" />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" className="btn-minimal" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" className="btn-minimal">{task ? 'Save Changes' : 'Create Task'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default TaskFormDialog;