import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

const TaskSummaryCards = ({ tasks }) => {
  const totalTasksTracked = tasks.length;
  const totalCompleted = tasks.reduce((sum, task) => sum + (task.tasks_completed || 0), 0);
  const totalOutgoing = tasks.reduce((sum, task) => sum + (task.tasks_outgoing || 0), 0);
  const totalEmails = tasks.reduce((sum, task) => sum + (task.emails_sent || 0), 0);
  const totalReviews = tasks.reduce((sum, task) => sum + (task.reviews_requested || 0), 0);

  const summaryData = [
    { title: "Total Tasks Tracked", value: totalTasksTracked.toLocaleString(), description: "Across all agents" },
    { title: "Total Completed", value: totalCompleted.toLocaleString(), description: "Sum of all completed sub-tasks" },
    { title: "Total Outgoing", value: totalOutgoing.toLocaleString(), description: "Sum of all outgoing sub-tasks" },
    { title: "Total Emails Sent", value: totalEmails.toLocaleString(), description: "Across relevant agents" },
    { title: "Total Reviews Requested", value: totalReviews.toLocaleString(), description: "Across relevant agents" },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.3, duration: 0.5 }}
      className="mt-12"
    >
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Overall Performance Insights</CardTitle>
          <CardDescription>Summary of all your AI agent activities.</CardDescription>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {summaryData.map(item => (
            <Card key={item.title} className="bg-accent/50 border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium">{item.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">
                  {item.value}
                </div>
                <p className="text-xs text-muted-foreground">
                  {item.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default TaskSummaryCards;