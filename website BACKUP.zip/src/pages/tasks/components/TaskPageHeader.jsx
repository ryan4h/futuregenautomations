import React from "react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";

const TaskPageHeader = ({ 
  searchTerm, 
  onSearchTermChange, 
  statusFilter, 
  onStatusFilterChange, 
  agentFilter, 
  onAgentFilterChange, 
  availableAgents = [] 
}) => {
  return (
    <div className="mb-8">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-foreground">Your Tasks</h1>
      </div>
      <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search tasks..."
            value={searchTerm}
            onChange={(e) => onSearchTermChange(e.target.value)}
            className="pl-10 bg-transparent border-2 border-white/50 text-white placeholder:text-gray-400 focus:border-primary"
          />
        </div>
        <Select value={statusFilter} onValueChange={onStatusFilterChange}>
          <SelectTrigger className="bg-transparent border-2 border-white/50 text-white placeholder:text-gray-400 focus:border-primary">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="outgoing">Outgoing</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="stopped">Stopped</SelectItem>
            <SelectItem value="error">Error</SelectItem>
          </SelectContent>
        </Select>
        <Select value={agentFilter} onValueChange={onAgentFilterChange}>
          <SelectTrigger className="bg-transparent border-2 border-white/50 text-white placeholder:text-gray-400 focus:border-primary">
            <SelectValue placeholder="Filter by agent" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Agents</SelectItem>
            {availableAgents.map(agentName => (
              <SelectItem key={agentName} value={agentName}>{agentName}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default TaskPageHeader;