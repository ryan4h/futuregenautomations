import React from 'react';
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { BarChart3, Mail, CheckCircle, AlertTriangle, Zap, Users, MessageSquare, PhoneCall, Bot } from 'lucide-react';

const StatItem = ({ icon, label, value, color = "text-foreground" }) => (
  <div className="flex items-center justify-between py-2 border-b border-border/50">
    <div className="flex items-center">
      {React.cloneElement(icon, { className: `h-5 w-5 mr-3 ${color}` })}
      <span className="text-sm text-muted-foreground">{label}:</span>
    </div>
    <span className={`text-sm font-semibold ${color}`}>{value ?? 'N/A'}</span>
  </div>
);

const AgentTaskStatsDialog = ({ open, onOpenChange, agentName, tasks = [] }) => {
  if (!open) return null;

  const aggregateStats = (taskList) => {
    return taskList.reduce((acc, task) => {
      acc.totalTasks += 1; // Counts each entry from zapier_task_data as a "task log"
      acc.tasksCompleted += task.tasks_completed || 0; // Sum of tasks_completed field
      acc.tasksOutgoing += task.tasks_outgoing || 0;
      acc.emailsSent += task.emails_sent || 0;
      acc.leadsCaptured += task.leads_captured || 0;
      acc.reviewsRequested += task.reviews_requested || 0;
      acc.ticketsResolved += task.tickets_resolved || 0;
      
      const status = task.status?.toLowerCase();
      if (status === 'completed' || status === 'succeeded') acc.succeededTasks += 1;
      if (status === 'failed' || status === 'error') acc.failedTasks += 1;
      return acc;
    }, {
      totalTasks: 0,
      tasksCompleted: 0,
      tasksOutgoing: 0,
      emailsSent: 0,
      leadsCaptured: 0,
      reviewsRequested: 0,
      ticketsResolved: 0,
      succeededTasks: 0,
      failedTasks: 0,
    });
  };

  const stats = aggregateStats(tasks);

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="bg-card border-border text-card-foreground sm:max-w-md">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-2xl font-bold text-primary flex items-center">
            <BarChart3 className="h-6 w-6 mr-2" /> Stats for {agentName || "Agent"}
          </AlertDialogTitle>
          <AlertDialogDescription className="text-muted-foreground">
            Overview of tasks and performance for this agent.
          </AlertDialogDescription>
        </AlertDialogHeader>
        
        <ScrollArea className="max-h-[60vh] pr-4">
          <div className="space-y-1 my-4">
            <StatItem icon={<Zap />} label="Total Logged Task Entries" value={stats.totalTasks} color="text-foreground" />
            <StatItem icon={<CheckCircle />} label="Succeeded Task Entries" value={stats.succeededTasks} color="text-foreground" />
            <StatItem icon={<AlertTriangle />} label="Failed Task Entries" value={stats.failedTasks} color="text-foreground" />
            {/* Removed "Total Tasks Completed (by agent)" as it's often the same as "Succeeded Task Entries" or tasks_completed sum */}
            <StatItem icon={<Mail />} label="Total Emails Sent" value={stats.emailsSent} color="text-foreground" />
            <StatItem icon={<Users />} label="Total Leads Captured" value={stats.leadsCaptured} color="text-foreground" />
            <StatItem icon={<MessageSquare />} label="Total Reviews Requested" value={stats.reviewsRequested} color="text-foreground" />
            <StatItem icon={<PhoneCall />} label="Total Tickets Resolved" value={stats.ticketsResolved} color="text-foreground" />
          </div>

          {tasks.length > 0 && (
            <>
              <h4 className="text-sm font-semibold mt-6 mb-2 text-muted-foreground">Recent Task Details:</h4>
              {tasks.slice(0, 5).map((task, index) => (
                <div key={task.id || index} className="text-xs p-2 border border-border/30 rounded-md mb-2 bg-background/50">
                  <p className="font-medium text-foreground">{task.agent_name || "Task Detail"}</p>
                  <p>Status: <span className={`capitalize font-semibold ${task.status?.toLowerCase() === 'completed' || task.status?.toLowerCase() === 'succeeded' ? 'text-green-500' : task.status?.toLowerCase() === 'failed' ? 'text-red-500' : 'text-orange-500'}`}>{task.status || "Unknown"}</span></p>
                  {task.created_at && <p className="text-muted-foreground">Logged: {new Date(task.created_at).toLocaleDateString()}</p>}
                </div>
              ))}
              {tasks.length > 5 && <p className="text-xs text-center text-muted-foreground mt-2">...and {tasks.length - 5} more tasks.</p>}
            </>
          )}
           {tasks.length === 0 && (
             <p className="text-sm text-center text-muted-foreground mt-4">No specific task data entries found for this agent in the current view.</p>
           )}

        </ScrollArea>

        <AlertDialogFooter className="mt-6">
          <AlertDialogCancel asChild>
            <Button variant="outline" className="text-white border-white hover:bg-white/10">Close</Button>
          </AlertDialogCancel>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default AgentTaskStatsDialog;