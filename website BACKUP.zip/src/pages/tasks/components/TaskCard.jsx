import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Eye, CheckCircle, AlertCircle, Clock, FileText, Users, CalendarCheck2, MessageSquare } from 'lucide-react'; 
import { motion } from 'framer-motion';

const getStatusStyles = (status) => {
  status = status?.toLowerCase() || 'unknown';
  switch (status) {
    case 'completed':
    case 'succeeded':
      return { icon: <CheckCircle className="h-5 w-5 text-green-500" />, color: 'text-green-500', badgeVariant: 'success', label: 'Completed' };
    case 'outgoing':
    case 'pending':
    case 'in_progress':
      return { icon: <Clock className="h-5 w-5 text-orange-500" />, color: 'text-orange-500', badgeVariant: 'warning', label: status };
    case 'failed':
    case 'error':
      return { icon: <AlertCircle className="h-5 w-5 text-red-500" />, color: 'text-red-500', badgeVariant: 'destructive', label: status };
    default:
      return { icon: <Clock className="h-5 w-5 text-gray-500" />, color: 'text-gray-500', badgeVariant: 'secondary', label: status };
  }
};

const agentSpecificMetricsConfig = {
  "Voice to Invoice Agent": [
    { label: "Invoices Created", field: "invoices_created", icon: <FileText className="h-4 w-4 mr-2 text-blue-400"/> },
    { label: "Invoices Successfully Sent", field: "tasks_completed", filter: (task) => task.status?.toLowerCase() === 'succeeded' || task.status?.toLowerCase() === 'completed', icon: <CheckCircle className="h-4 w-4 mr-2 text-green-400"/> },
    { label: "Invoices Unsuccessfully Sent", field: "tasks_completed", filter: (task) => task.status?.toLowerCase() === 'failed' || task.status?.toLowerCase() === 'error', icon: <AlertCircle className="h-4 w-4 mr-2 text-red-400"/> }
  ],
  "Appointment Management Agent": [
    { label: "Appointments Scheduled", field: "appointments_scheduled", icon: <CalendarCheck2 className="h-4 w-4 mr-2 text-purple-400"/> },
    { label: "Reminders Successfully Sent", field: "tasks_completed", filter: (task) => task.status?.toLowerCase() === 'succeeded' || task.status?.toLowerCase() === 'completed', icon: <MessageSquare className="h-4 w-4 mr-2 text-green-400"/> }, 
    { label: "Reminders Unsuccessfully Sent", field: "tasks_completed", filter: (task) => task.status?.toLowerCase() === 'failed' || task.status?.toLowerCase() === 'error', icon: <AlertCircle className="h-4 w-4 mr-2 text-red-400"/> }
  ],
  "Default": [
    { label: "Tasks Succeeded", field: "tasks_completed", filter: (task) => task.status?.toLowerCase() === 'succeeded' || task.status?.toLowerCase() === 'completed', icon: <CheckCircle className="h-4 w-4 mr-2 text-green-400"/> },
    { label: "Emails Sent", field: "emails_sent", icon: <FileText className="h-4 w-4 mr-2 text-sky-400"/> },
    { label: "Leads Captured", field: "leads_captured", icon: <Users className="h-4 w-4 mr-2 text-purple-400"/> }
  ]
};


const TaskCard = ({ agentName, tasks, onViewAgentTasks }) => {
  
  const metricsToDisplay = agentSpecificMetricsConfig[agentName] || agentSpecificMetricsConfig["Default"];

  const aggregatedStats = tasks.reduce((acc, task) => {
    acc.totalLoggedTasks = (acc.totalLoggedTasks || 0) + 1;
    
    const status = task.status?.toLowerCase();
    if (status === 'completed' || status === 'succeeded') acc.succeededTasks = (acc.succeededTasks || 0) + 1;
    else if (status === 'failed' || status === 'error') acc.failedTasks = (acc.failedTasks || 0) + 1;
    else acc.pendingTasks = (acc.pendingTasks || 0) +1;

    metricsToDisplay.forEach(metricConf => {
        const key = metricConf.field + (metricConf.filter ? '_filtered' : ''); // Make key unique for filtered stats
        const taskValue = Number(task[metricConf.field]) || 0;

        if (metricConf.filter) {
            if (metricConf.filter(task)) {
                 // If filter applies, increment by 1 for counts or by field value if it's numeric and relevant
                 acc[key] = (acc[key] || 0) + (task[metricConf.field] !== undefined ? taskValue : 1);
            }
        } else {
             acc[key] = (acc[key] || 0) + taskValue;
        }
    });
    return acc;
  }, { totalLoggedTasks: 0, succeededTasks: 0, failedTasks: 0, pendingTasks: 0 });

  
  let overallStatus = 'pending';
  if (aggregatedStats.succeededTasks > 0 && aggregatedStats.failedTasks === 0 && aggregatedStats.pendingTasks === 0) {
    overallStatus = 'completed';
  } else if (aggregatedStats.failedTasks > 0) {
    overallStatus = 'error';
  }

  const { icon: statusIcon, badgeVariant, label: statusLabel } = getStatusStyles(overallStatus);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      className="h-full"
    >
      <Card className="bg-card border-border hover:shadow-lg transition-shadow duration-300 flex flex-col justify-between h-full">
        <CardHeader>
          <div className="flex justify-between items-start">
            <CardTitle className="text-lg font-semibold text-white">{agentName}</CardTitle>
            {statusIcon}
          </div>
          <CardDescription className="text-sm text-muted-foreground">
            Aggregated task summary for this agent.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex-grow">
          <div className="space-y-2 text-sm">
            <p><strong className="text-muted-foreground">Overall Status:</strong> <Badge variant={badgeVariant} className="capitalize">{statusLabel}</Badge></p>
            <p><strong className="text-muted-foreground">Total Logged Task Entries:</strong> <span className="text-white">{aggregatedStats.totalLoggedTasks}</span></p>
            <p><strong className="text-muted-foreground">Succeeded Task Entries:</strong> <span className="text-green-400">{aggregatedStats.succeededTasks}</span></p>
            {aggregatedStats.failedTasks > 0 && <p><strong className="text-muted-foreground">Failed Task Entries:</strong> <span className="text-red-400">{aggregatedStats.failedTasks}</span></p>}
            
            {metricsToDisplay.map(metricConf => {
              const key = metricConf.field + (metricConf.filter ? '_filtered' : '');
              const value = aggregatedStats[key] || 0;
              return (
                <p key={metricConf.label} className="flex items-center">
                  {metricConf.icon}
                  <strong className="text-muted-foreground">{metricConf.label}:</strong> 
                  <span className="ml-1 text-white">{value}</span>
                </p>
              );
            })}
          </div>
        </CardContent>
        <CardFooter className="flex justify-end space-x-2 pt-4 border-t border-border">
          <Button variant="outline" size="sm" onClick={() => onViewAgentTasks(agentName, tasks)} className="text-primary border-primary hover:bg-primary/10">
            <Eye className="mr-2 h-4 w-4" /> View Agent Stats
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default TaskCard;