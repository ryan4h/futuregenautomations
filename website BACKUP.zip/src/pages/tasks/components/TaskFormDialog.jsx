import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const TaskFormDialog = ({ open, onOpenChange, task, onSubmit, availableAgents = [] }) => {
  const getDefaultAgentName = () => {
    if (availableAgents && availableAgents.length > 0) {
      return availableAgents[0];
    }
    return ""; 
  };
  
  const initialFormData = {
    agent_name: getDefaultAgentName(),
    task_description: "",
    status: "outgoing",
    tasks_completed: 0,
    tasks_outgoing: 0,
    tasks_stopped: 0,
    emails_sent: 0,
    reviews_requested: 0,
    leads_captured: 0,
    tickets_resolved: 0, // Added tickets_resolved
  };

  const [formData, setFormData] = useState(initialFormData);

  useEffect(() => {
    if (task) {
      setFormData({
        agent_name: task.agent_name || getDefaultAgentName(),
        task_description: task.task_description || "",
        status: task.status || "outgoing",
        tasks_completed: task.tasks_completed || 0,
        tasks_outgoing: task.tasks_outgoing || 0,
        tasks_stopped: task.tasks_stopped || 0,
        emails_sent: task.emails_sent || 0,
        reviews_requested: task.reviews_requested || 0,
        leads_captured: task.leads_captured || 0,
        tickets_resolved: task.tickets_resolved || 0, // Added tickets_resolved
      });
    } else {
      // When creating a new task, ensure agent_name defaults correctly
      setFormData({
        ...initialFormData,
        agent_name: getDefaultAgentName(),
      });
    }
  }, [task, open, availableAgents]);

  const handleChange = (e) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseInt(value, 10) || 0 : value,
    }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[525px] bg-card border-border text-card-foreground">
        <DialogHeader>
          <DialogTitle>{task ? "Edit Task" : "Create New Task (Edit Only)"}</DialogTitle>
          <DialogDescription>
            {task ? "Update the details of this task." : "Note: This form is currently for editing existing tasks. New task creation requires agent_id handling."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4 max-h-[70vh] overflow-y-auto pr-2">
          <div>
            <Label htmlFor="agent_name">Agent Name</Label>
            <Select name="agent_name" value={formData.agent_name} onValueChange={(value) => handleSelectChange("agent_name", value)} disabled={!task}>
              <SelectTrigger className="w-full bg-input border-border focus:border-primary">
                <SelectValue placeholder="Select an agent" />
              </SelectTrigger>
              <SelectContent>
                {availableAgents.map(agent => (
                  <SelectItem key={agent} value={agent}>{agent}</SelectItem>
                ))}
                {(!availableAgents || availableAgents.length === 0) && !formData.agent_name && (
                    <SelectItem value="" disabled>No agents available</SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="task_description">Task Description</Label>
            <Textarea id="task_description" name="task_description" value={formData.task_description} onChange={handleChange} required className="bg-input border-border focus:border-primary" />
          </div>
          <div>
            <Label htmlFor="status">Status</Label>
            <Select name="status" value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
              <SelectTrigger className="w-full bg-input border-border focus:border-primary">
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="outgoing">Outgoing</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="stopped">Stopped</SelectItem>
                <SelectItem value="error">Error</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="tasks_completed">Tasks Completed</Label>
              <Input id="tasks_completed" name="tasks_completed" type="number" value={formData.tasks_completed} onChange={handleChange} className="bg-input border-border focus:border-primary" />
            </div>
            <div>
              <Label htmlFor="tasks_outgoing">Tasks Outgoing</Label>
              <Input id="tasks_outgoing" name="tasks_outgoing" type="number" value={formData.tasks_outgoing} onChange={handleChange} className="bg-input border-border focus:border-primary" />
            </div>
            <div>
              <Label htmlFor="tasks_stopped">Tasks Stopped</Label>
              <Input id="tasks_stopped" name="tasks_stopped" type="number" value={formData.tasks_stopped} onChange={handleChange} className="bg-input border-border focus:border-primary" />
            </div>
            <div>
              <Label htmlFor="emails_sent">Emails Sent</Label>
              <Input id="emails_sent" name="emails_sent" type="number" value={formData.emails_sent} onChange={handleChange} className="bg-input border-border focus:border-primary" />
            </div>
            <div>
              <Label htmlFor="reviews_requested">Reviews Requested</Label>
              <Input id="reviews_requested" name="reviews_requested" type="number" value={formData.reviews_requested} onChange={handleChange} className="bg-input border-border focus:border-primary" />
            </div>
            <div>
              <Label htmlFor="leads_captured">Leads Captured</Label>
              <Input id="leads_captured" name="leads_captured" type="number" value={formData.leads_captured} onChange={handleChange} className="bg-input border-border focus:border-primary" />
            </div>
            <div>
              <Label htmlFor="tickets_resolved">Tickets Resolved</Label>
              <Input id="tickets_resolved" name="tickets_resolved" type="number" value={formData.tickets_resolved} onChange={handleChange} className="bg-input border-border focus:border-primary" />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="btn-minimal">Cancel</Button>
            <Button type="submit" className="btn-minimal" disabled={!task && true}>{task ? "Save Changes" : "Create Task (Disabled)"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default TaskFormDialog;