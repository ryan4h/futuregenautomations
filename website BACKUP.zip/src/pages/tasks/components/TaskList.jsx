import React from 'react';
import TaskCard from './TaskCard'; // Assuming TaskCard is updated for agent summary

const TaskList = ({ tasksByAgent, onViewAgentStats }) => {
  return (
    <div className="mt-8">
      <h2 className="text-2xl font-semibold mb-6 text-foreground border-b border-border pb-2">Agent Task Summaries</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Object.entries(tasksByAgent).map(([agentName, agentTasks]) => (
          <TaskCard 
            key={agentName} 
            agentName={agentName}
            tasks={agentTasks} 
            onViewAgentTasks={onViewAgentStats} 
          />
        ))}
      </div>
    </div>
  );
};

export default TaskList;