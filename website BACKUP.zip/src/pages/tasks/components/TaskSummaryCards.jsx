import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, Send, Users, Eye, Clock, AlertCircle, BarChart3 } from 'lucide-react';
import { motion } from 'framer-motion';

const StatCard = ({ title, value, icon, iconColorClass = "text-primary", headerColorClass = "text-primary", valueColorClass = "text-white", description }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.3 }}
    className="h-full"
  >
    <Card className="bg-transparent border-2 border-card-border/30 shadow-lg h-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className={`text-sm font-medium ${headerColorClass}`}>{title}</CardTitle>
        {React.cloneElement(icon, { className: `h-5 w-5 ${iconColorClass}` })}
      </CardHeader>
      <CardContent>
        <div className={`text-3xl font-bold ${valueColorClass}`}>{value}</div>
        {description && <p className={`text-xs text-muted-foreground mt-1`}>{description}</p>}
      </CardContent>
    </Card>
  </motion.div>
);


const TaskSummaryCards = ({ tasks }) => {
  const totalTasks = tasks.length;
  
  const aggregateField = (fieldName) => tasks.reduce((sum, task) => sum + (Number(task[fieldName]) || 0), 0);

  const tasksCompleted = aggregateField('tasks_completed');
  const emailsSent = aggregateField('emails_sent');
  const leadsCaptured = aggregateField('leads_captured');
  const reviewsRequested = aggregateField('reviews_requested');
  
  const outgoingTasks = aggregateField('tasks_outgoing') + 
                        tasks.filter(t => ['pending', 'in_progress', 'outgoing'].includes(t.status?.toLowerCase())).length;
  
  const failedTasks = tasks.filter(t => ['failed', 'error'].includes(t.status?.toLowerCase())).length;


  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 mb-8">
      <StatCard 
        title="Total Tasks Logged" 
        value={totalTasks} 
        icon={<BarChart3 />} 
        headerColorClass="text-blue-400"
        iconColorClass="text-blue-400"
        valueColorClass="text-white"
        description="All tasks recorded in the system."
      />
      <StatCard 
        title="Tasks Completed" 
        value={tasksCompleted} 
        icon={<CheckCircle />} 
        headerColorClass="text-green-400"
        iconColorClass="text-green-400"
        valueColorClass="text-white"
        description="Successfully finished tasks by agents."
      />
      <StatCard 
        title="Emails Sent" 
        value={emailsSent} 
        icon={<Send />} 
        headerColorClass="text-sky-400"
        iconColorClass="text-sky-400"
        valueColorClass="text-white"
        description="Total emails dispatched by agents."
      />
      <StatCard 
        title="Leads Captured" 
        value={leadsCaptured} 
        icon={<Users />} 
        headerColorClass="text-purple-400"
        iconColorClass="text-purple-400"
        valueColorClass="text-white"
        description="New potential customers identified."
      />
       <StatCard 
        title="Reviews Requested" 
        value={reviewsRequested} 
        icon={<Eye />} 
        headerColorClass="text-pink-400"
        iconColorClass="text-pink-400"
        valueColorClass="text-white"
        description="Customer reviews actively sought."
      />
      <StatCard 
        title="Outgoing/Pending Tasks" 
        value={outgoingTasks} 
        icon={<Clock />} 
        headerColorClass="text-orange-400"
        iconColorClass="text-orange-400"
        valueColorClass="text-white"
        description="Tasks currently active or awaiting action."
      />
      <StatCard 
        title="Failed Tasks" 
        value={failedTasks} 
        icon={<AlertCircle />} 
        headerColorClass="text-red-400"
        iconColorClass="text-red-400"
        valueColorClass="text-white"
        description="Tasks that encountered errors."
      />
    </div>
  );
};

export default TaskSummaryCards;