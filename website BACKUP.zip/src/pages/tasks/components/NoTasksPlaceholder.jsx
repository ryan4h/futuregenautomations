import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bot, PlusCircle } from "lucide-react";

const NoTasksPlaceholder = ({ onAddNewTask }) => {
  return (
    <Card className="bg-card border-border">
      <CardContent className="p-12 text-center">
        <Bot className="mx-auto h-12 w-12 text-muted-foreground" />
        <h3 className="mt-4 text-xl font-semibold">No tasks found</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Get started by adding your first agent task.
        </p>
        <div className="mt-6">
          <Button variant="outline" className="btn-minimal" onClick={onAddNewTask}>
            <PlusCircle className="mr-2 h-4 w-4" /> Add New Task
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default NoTasksPlaceholder;