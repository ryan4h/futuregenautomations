import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Megaphone, PlusCircle, Filter, Edit2, Trash2, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/lib/supabaseClient";
import { AlertDialog } from "@/components/ui/alert-dialog";

import CampaignFormDialog from "./ad-campaigns/CampaignFormDialog";
import CampaignCard from "./ad-campaigns/CampaignCard";
import NoCampaignsPlaceholder from "./ad-campaigns/NoCampaignsPlaceholder";
import AdCampaignsHeader from "./ad-campaigns/AdCampaignsHeader";
import DeleteConfirmationDialog from "./ad-campaigns/DeleteConfirmationDialog";


const AdCampaignsPage = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState(null);
  const [campaignToDelete, setCampaignToDelete] = useState(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  const fetchUserProfile = useCallback(async (userId) => {
    if (!userId) return;
    const { data, error } = await supabase
      .from("user_profiles")
      .select("full_name")
      .eq("user_id", userId)
      .single();
    
    if (error && error.code !== 'PGRST116') { 
      console.error("Error fetching user profile:", error);
    } else if (data) {
      setUserProfile(data);
    }
  }, []);


  const fetchCampaigns = useCallback(async (currentUserId) => {
    if (!currentUserId) return;
    setLoading(true);
    const { data, error } = await supabase
      .from("users_ad_campaigns")
      .select("*")
      .eq("user_id", currentUserId)
      .order("created_at", { ascending: false });

    if (error) {
      toast({ title: "Error fetching campaigns", description: error.message, variant: "destructive" });
      setCampaigns([]);
    } else {
      setCampaigns(data || []);
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        setUser(session.user);
        fetchCampaigns(session.user.id);
        fetchUserProfile(session.user.id);
      } else {
        setLoading(false);
         navigate("/login");
      }
    };
    getSession();
     const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      const currentUser = session?.user;
      setUser(currentUser);
      if (currentUser) {
        fetchCampaigns(currentUser.id);
        fetchUserProfile(currentUser.id);
      } else {
        setCampaigns([]);
        setUserProfile(null);
        setLoading(false);
        navigate("/login");
      }
    });
     return () => {
      authListener?.subscription.unsubscribe();
    };
  }, [fetchCampaigns, fetchUserProfile, navigate]);

  const handleFormSubmit = async (formData) => {
    if (!user) {
      toast({ title: "Authentication Error", description: "You must be logged in.", variant: "destructive" });
      return;
    }
    setLoading(true);
    let response;
    if (editingCampaign) {
      response = await supabase
        .from("users_ad_campaigns")
        .update({ ...formData, user_id: user.id, updated_at: new Date().toISOString() })
        .eq("id", editingCampaign.id)
        .select();
    } else {
      response = await supabase
        .from("users_ad_campaigns")
        .insert({ ...formData, user_id: user.id })
        .select();
    }

    const { error } = response;
    if (error) {
      toast({ title: editingCampaign ? "Error Updating Campaign" : "Error Creating Campaign", description: error.message, variant: "destructive" });
    } else {
      toast({ title: editingCampaign ? "Campaign Updated" : "Campaign Created", description: "Your campaign has been saved." });
      fetchCampaigns(user.id);
      setIsFormOpen(false);
      setEditingCampaign(null);
    }
    setLoading(false);
  };

  const openEditForm = (campaign) => {
    setEditingCampaign(campaign);
    setIsFormOpen(true);
  };
  
  const handleNewCampaign = () => {
     if (user) {
      navigate("/contact", { 
        state: { 
          subject: "Interested in starting a new campaign",
          name: user.user_metadata?.full_name || userProfile?.full_name || '',
          email: user.email || '',
        }
      });
    } else {
      navigate("/contact", { state: { subject: "Interested in starting a new campaign" } });
    }
  };

  const handleDeleteClick = (campaign) => {
    setCampaignToDelete(campaign);
    setIsDeleteDialogOpen(true);
  };

  const confirmDeleteCampaign = async () => {
    if (!campaignToDelete || !user) return;
    setLoading(true);
    const { error } = await supabase
      .from("users_ad_campaigns")
      .delete()
      .eq("id", campaignToDelete.id)
      .eq("user_id", user.id);

    if (error) {
      toast({ title: "Error Deleting Campaign", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Campaign Deleted", description: `${campaignToDelete.campaign_name} has been removed.` });
      fetchCampaigns(user.id);
    }
    setCampaignToDelete(null);
    setIsDeleteDialogOpen(false);
    setLoading(false);
  };


  return (
    <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
      <div className="container py-8 bg-background text-foreground">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <AdCampaignsHeader 
            onRefresh={() => user && fetchCampaigns(user.id)}
            onNewCampaign={handleNewCampaign}
            loading={loading}
          />
          
          {loading && campaigns.length === 0 ? (
             <div className="text-center py-12 text-muted-foreground">Loading campaigns...</div>
          ) : campaigns.length > 0 ? (
            <div className="space-y-6">
              {campaigns.map((campaign) => (
                <CampaignCard 
                  key={campaign.id} 
                  campaign={campaign} 
                  onEdit={() => openEditForm(campaign)} 
                  onDelete={() => handleDeleteClick(campaign)} 
                />
              ))}
            </div>
          ) : (
            <NoCampaignsPlaceholder onNewCampaign={handleNewCampaign} />
          )}
        </motion.div>

        <CampaignFormDialog 
          open={isFormOpen} 
          onOpenChange={setIsFormOpen} 
          onSubmit={handleFormSubmit} 
          campaign={editingCampaign}
          loading={loading}
        />
        {campaignToDelete && (
          <DeleteConfirmationDialog 
            campaignName={campaignToDelete.campaign_name}
            onCancel={() => { setCampaignToDelete(null); setIsDeleteDialogOpen(false); }}
            onConfirm={confirmDeleteCampaign}
            loading={loading}
          />
        )}
      </div>
    </AlertDialog>
  );
};

export default AdCampaignsPage;