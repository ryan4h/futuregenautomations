import React, {useState, useEffect, useCallback} from "react";
import { motion } from "framer-motion";
import { Link2, PlusCircle, Search, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/lib/supabaseClient";
import { useToast } from "@/components/ui/use-toast";
import IntegrationRequestForm from "./integrations/IntegrationRequestForm";
import IntegrationCard from "./integrations/IntegrationCard";
import { topZapierIntegrations } from "./integrations/zapierIntegrationsData";


const platformIntegrations = [
    { id: "plat1", name: "Google Ads Platform", description: "Native integration for campaign management.", connected: true, logo: "GAdsPlat", category: "Platform" },
    { id: "plat2", name: "Meta Ads Platform", description: "Native integration for Facebook & Instagram ads.", connected: true, logo: "MetaPlat", category: "Platform" },
];

const externalIntegrationsList = topZapierIntegrations.map(zapInt => ({
  id: zapInt.id,
  name: zapInt.name,
  description: zapInt.description,
  connected: false, 
  logo: zapInt.logo || zapInt.name.substring(0,3).toUpperCase(),
  category: zapInt.category || "Productivity"
}));

const allIntegrations = [...platformIntegrations, ...externalIntegrationsList];


const IntegrationsPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [userAgents, setUserAgents] = useState([]);
  const [isRequestFormOpen, setIsRequestFormOpen] = useState(false);
  const [formLoading, setFormLoading] = useState(false);
  const [supabaseError, setSupabaseError] = useState(!supabase);
  const [initialIntegrationName, setInitialIntegrationName] = useState("");

  const fetchUserAgents = useCallback(async (userId) => {
    if (!userId || !supabase) return;
    const { data, error } = await supabase
      .from('user_assigned_agents')
      .select('assigned_agent_id, agent_name')
      .eq('user_id', userId)
      .eq('status', 'active'); 
    if (error) {
      console.error("Error fetching user agents:", error);
      setUserAgents([]);
    } else {
      setUserAgents(data || []);
    }
  }, []);


  useEffect(() => {
    if (!supabase) {
        setSupabaseError(true);
        return;
    }
    setSupabaseError(false);
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user || null);
      if (session?.user) {
        const { data: profile } = await supabase
            .from('user_profiles')
            .select('full_name')
            .eq('user_id', session.user.id)
            .single();
        setUserProfile(profile);
        fetchUserAgents(session.user.id);
      }
    };
    getSession();
  }, [fetchUserAgents]);


  const handleRequestSubmit = async (formData) => {
    if (!user || !supabase) {
      toast({ title: "Not Logged In", description: "Please log in to submit requests.", variant: "destructive" });
      return;
    }
    setFormLoading(true);
    
    const requestPayload = {
      user_id: user.id,
      user_email: user.email,
      full_name: userProfile?.full_name || user.user_metadata?.full_name || 'N/A',
      requested_integration_name: formData.requested_integration_name,
      selected_agent_id: formData.selected_agent_id || null, // Ensure null if empty
      use_case: formData.use_case,
      business_need: formData.business_need, // Kept for now
      status: 'pending'
    };

    const { error } = await supabase.from('integration_requests').insert([requestPayload]);
    setFormLoading(false);
    if (error) {
      toast({ title: "Request Failed", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Request Submitted", description: "Your integration request has been sent to our team." });
      setIsRequestFormOpen(false);
    }
  };

  const openRequestForm = (integrationName = "") => {
    setInitialIntegrationName(integrationName);
    setIsRequestFormOpen(true);
  };


  const filteredIntegrations = allIntegrations.filter(integration => 
    integration.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    integration.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    integration.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container py-8 bg-background text-foreground">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {supabaseError && (
           <div className="mb-6 bg-destructive/20 border border-destructive text-destructive-foreground p-4 rounded-md text-sm flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 flex-shrink-0" />
            <span>Database is not connected. Integration requests are disabled.</span>
          </div>
        )}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
          <h1 className="text-3xl font-bold">Integrations</h1>
          <div className="relative w-full sm:w-auto">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search integrations..." 
              className="pl-10 bg-input border-border text-foreground placeholder:text-muted-foreground w-full sm:w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button variant="outline" className="w-full sm:w-auto border-2 border-white bg-transparent hover:bg-white/10" onClick={() => openRequestForm()} disabled={supabaseError}>
            <PlusCircle className="mr-2 h-4 w-4" /> Request New
          </Button>
        </div>

        <h2 className="text-2xl font-semibold mb-4 text-foreground">Platform Integrations</h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-10">
          {filteredIntegrations.filter(int => int.category === "Platform").map((integration) => (
            <IntegrationCard 
              key={integration.id} 
              integration={integration} 
              onOpenRequestForm={openRequestForm}
              disabled={supabaseError}
            />
          ))}
        </div>

        <h2 className="text-2xl font-semibold mb-4 text-foreground">External Integrations <Badge variant="secondary" className="ml-2">Popular Options</Badge></h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredIntegrations.filter(int => int.category !== "Platform").map((integration) => (
             <IntegrationCard 
              key={integration.id} 
              integration={integration} 
              onOpenRequestForm={openRequestForm}
              disabled={supabaseError}
            />
          ))}
        </div>
        
        {filteredIntegrations.length === 0 && searchTerm && (
           <div className="text-center py-12 col-span-full">
            <Search className="mx-auto h-12 w-12 text-muted-foreground" />
            <h3 className="mt-2 text-xl font-semibold">No integrations match "{searchTerm}"</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Try a different search term or request a new integration.
            </p>
          </div>
        )}
      </motion.div>
      <IntegrationRequestForm 
        open={isRequestFormOpen}
        onOpenChange={setIsRequestFormOpen}
        onSubmit={handleRequestSubmit}
        loading={formLoading}
        user={user}
        initialIntegrationName={initialIntegrationName}
        userAgents={userAgents}
      />
    </div>
  );
};

export default IntegrationsPage;