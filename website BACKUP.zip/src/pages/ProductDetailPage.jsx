import React, { useState, useEffect, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { supabase } from "@/lib/supabaseClient";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, CheckCircle, Info, Star, Users, Zap, DollarSign, Brain, FileText, Mail as MailIcon, Calendar, ArrowLeft, Loader2, AlertTriangle } from "lucide-react";
import { useCart } from "@/context/CartContext"; 
import { checkExistingAgentAssignment } from "./agents/dataFetchers";

const iconMap = {
  Users: <Users className="h-5 w-5 mr-2 text-primary" />,
  Mail: <MailIcon className="h-5 w-5 mr-2 text-primary" />,
  FileText: <FileText className="h-5 w-5 mr-2 text-primary" />,
  Star: <Star className="h-5 w-5 mr-2 text-primary" />,
  Calendar: <Calendar className="h-5 w-5 mr-2 text-primary" />,
  Brain: <Brain className="h-5 w-5 mr-2 text-primary" />,
  DollarSign: <DollarSign className="h-5 w-5 mr-2 text-primary" />,
  Zap: <Zap className="h-5 w-5 mr-2 text-primary" />,
  Default: <Info className="h-5 w-5 mr-2 text-primary" />
};

const ProductDetailPage = () => {
  const { id: productId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { addToCart, cartItems } = useCart(); 
  const [product, setProduct] = useState(null);
  const [loadingProduct, setLoadingProduct] = useState(true);
  const [user, setUser] = useState(null);
  const [isOwned, setIsOwned] = useState(false);
  const [loadingOwnership, setLoadingOwnership] = useState(true);

  const fetchProductDetails = useCallback(async () => {
    setLoadingProduct(true);
    const { data, error } = await supabase
      .from("ai_agents_list")
      .select("*")
      .eq("id", parseInt(productId))
      .single();

    if (error) {
      toast({ title: "Error", description: "Could not fetch product details.", variant: "destructive" });
      navigate("/products");
    } else {
      setProduct(data);
    }
    setLoadingProduct(false);
  }, [productId, navigate, toast]);

  const checkUserAndOwnershipStatus = useCallback(async (currentUserId, currentProduct) => {
    if (!currentUserId || !currentProduct) {
      setLoadingOwnership(false);
      return;
    }
    setLoadingOwnership(true);
    const existingAssignment = await checkExistingAgentAssignment(currentUserId, currentProduct.id, toast);
    setIsOwned(!!existingAssignment);
    setLoadingOwnership(false);
  }, [toast]);

  useEffect(() => {
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user || null);
    };
    getSession();

    const { data: authListener } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        setUser(session?.user || null);
      }
    );
    return () => authListener?.subscription.unsubscribe();
  }, []);


  useEffect(() => {
    fetchProductDetails();
  }, [fetchProductDetails]);

  useEffect(() => {
    if (user && product) {
      checkUserAndOwnershipStatus(user.id, product);
    } else if (!user) {
      setLoadingOwnership(false); // No user, not loading ownership
      setIsOwned(false);
    }
  }, [user, product, checkUserAndOwnershipStatus]);

  const handleGetNow = () => {
    if (!user) {
      toast({ title: "Authentication Required", description: "Please log in to get agents.", variant: "info" });
      navigate("/login");
      return;
    }
    if (!product) return;

    if (isOwned) {
        toast({ title: "Already Owned", description: "You already have this agent.", variant: "default" });
        return;
    }
    
    if (!product.stripe_price_id) {
        toast({ title: "Not Purchasable", description: "This agent is currently not available for purchase.", variant: "warning" });
        return;
    }

    addToCart(product);
  };
  
  const isInCart = product && cartItems.some(item => item.id === product.id);
  const isPurchasable = product && !!product.stripe_price_id;


  if (loadingProduct) {
    return (
      <div className="container mx-auto py-12 flex flex-col items-center justify-center min-h-[calc(100vh-200px)] text-foreground">
        <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
        <p>Loading product details...</p>
      </div>
    );
  }

  if (!product) {
    return <div className="container mx-auto py-12 text-center text-foreground">Product not found.</div>;
  }

  const displayIcon = product.icon_name && iconMap[product.icon_name] ? iconMap[product.icon_name] : iconMap.Default;

  const renderActionButton = () => {
    if (loadingOwnership) {
      return (
        <Button size="lg" className="w-full btn-minimal text-lg py-3" disabled>
          <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Checking Ownership...
        </Button>
      );
    }
    if (isOwned) {
      return (
        <Button size="lg" className="w-full bg-transparent border-2 border-green-500 text-green-500 hover:bg-green-500/10 text-lg py-3" disabled>
          <CheckCircle className="mr-2 h-5 w-5" /> Already Owned
        </Button>
      );
    }
    if (!isPurchasable) {
      return (
        <Button size="lg" className="w-full btn-minimal text-lg py-3" disabled>
          <AlertTriangle className="mr-2 h-5 w-5" /> Not Available
        </Button>
      );
    }
    if (isInCart) {
      return (
        <Button size="lg" className="w-full bg-green-600 hover:bg-green-700 text-white text-lg py-3" onClick={() => navigate('/cart')}>
          <CheckCircle className="mr-2 h-5 w-5" /> In Cart - View Cart
        </Button>
      );
    }
    return (
      <Button 
        size="lg" 
        className="w-full bg-primary hover:bg-primary/90 text-primary-foreground text-lg py-3" 
        onClick={handleGetNow}
        disabled={!user}
      >
        <ShoppingCart className="mr-2 h-5 w-5" /> Get Now
      </Button>
    );
  };


  return (
    <div className="container mx-auto py-12 px-4 md:px-0">
      <Button variant="outline" className="btn-minimal mb-6" onClick={() => navigate(-1)}>
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Products
      </Button>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-card border border-border rounded-lg shadow-xl overflow-hidden"
      >
        <div className="md:flex">
          <div className="md:w-1/2 p-8 bg-gradient-to-br from-primary/10 to-background">
            <div className="flex items-center text-primary mb-4">
              {displayIcon}
              <h1 className="text-3xl md:text-4xl font-bold text-card-foreground ml-2">{product.agent_name}</h1>
            </div>
            <Badge variant="outline" className="mb-4 text-sm border-primary text-primary">{product.category}</Badge>
            <p className="text-muted-foreground text-lg mb-6">{product.description}</p>
            
            <div className="mb-6">
              <h3 className="text-xl font-semibold text-card-foreground mb-2">Key Features</h3>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                {(product.features || []).map((feature, index) => (
                  <li key={index}>{feature}</li>
                ))}
              </ul>
            </div>

             <div className="mb-6">
              <h3 className="text-xl font-semibold text-card-foreground mb-2">Benefits</h3>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                {(product.benefits || []).map((benefit, index) => (
                  <li key={index}>{benefit}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="md:w-1/2 p-8 flex flex-col justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-card-foreground mb-2">Product Overview</h2>
              <p className="text-muted-foreground mb-6 whitespace-pre-line">
                {product.long_description || "Detailed information about this agent will be available soon."}
              </p>
              
              {product.specifications && (
                <div className="mb-6">
                  <h3 className="text-xl font-semibold text-card-foreground mb-2">Specifications</h3>
                  <pre className="bg-muted p-4 rounded-md text-sm text-muted-foreground overflow-x-auto">
                    {JSON.stringify(product.specifications, null, 2)}
                  </pre>
                </div>
              )}
            </div>
            
            <div className="mt-auto">
              <div className="flex items-center justify-between mb-6">
                <p className="text-4xl font-bold text-primary">${product.price_one_time ? product.price_one_time.toFixed(2) : '0.00'}</p>
                <div className="flex items-center">
                  <Star className="h-5 w-5 text-yellow-400 mr-1" />
                  <span className="text-muted-foreground">{product.rating || "N/A"} ({product.reviews_count || 0} reviews)</span>
                </div>
              </div>
              
              {renderActionButton()}

              {!user && <p className="text-xs text-center mt-2 text-muted-foreground">Please <a href="/login" className="text-primary hover:underline">login</a> to get this agent.</p>}
              {user && !isPurchasable && !isOwned && (
                <p className="text-xs text-center mt-2 text-destructive">This agent is currently not available for purchase.</p>
              )}
            </div>
          </div>
        </div>
        
        {product.faqs && Object.keys(product.faqs).length > 0 && (
          <div className="p-8 border-t border-border">
            <h3 className="text-2xl font-semibold text-card-foreground mb-4">Frequently Asked Questions</h3>
            <div className="space-y-4">
              {Object.entries(product.faqs).map(([question, answer], index) => (
                <details key={index} className="group bg-muted/50 p-4 rounded-lg">
                  <summary className="font-medium text-card-foreground cursor-pointer list-none flex justify-between items-center">
                    {question}
                    <span className="text-primary transition-transform duration-200 group-open:rotate-180">▼</span>
                  </summary>
                  <p className="text-muted-foreground mt-2">{answer}</p>
                </details>
              ))}
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default ProductDetailPage;