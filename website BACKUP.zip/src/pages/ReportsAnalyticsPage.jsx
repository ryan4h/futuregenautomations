import React, { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { Download, Calendar, Filter, Info, TrendingUp, Target, Maximize2, BarChartHorizontal, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/lib/supabaseClient";

import DailyTasksLineGraph from "./reports-analytics/components/DailyTasksLineGraph";
import HoverablePieChart from "./reports-analytics/components/HoverablePieChart";
import MonthlyOverviewCard from "./reports-analytics/components/MonthlyOverviewCard";
import DateRangeDialog from "./reports-analytics/components/DateRangeDialog";
import FilterReportsDialog from "./reports-analytics/components/FilterReportsDialog";
import AnalyticsDetailDialog from "./reports-analytics/components/AnalyticsDetailDialog"; 

const ReportsAnalyticsPage = () => {
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [dailyTaskData, setDailyTaskData] = useState([]);
  const [aggregatedPerformanceData, setAggregatedPerformanceData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedMetricForDialog, setSelectedMetricForDialog] = useState(null); 
  const [activeAgents, setActiveAgents] = useState([]);

  const [isDateRangeDialogOpen, setIsDateRangeDialogOpen] = useState(false);
  const [isFilterDialogOpen, setIsFilterDialogOpen] = useState(false);
  const [isAnalyticsDetailOpen, setIsAnalyticsDetailOpen] = useState(false);

  const [currentDateRange, setCurrentDateRange] = useState("current_month");
  const [currentFilters, setCurrentFilters] = useState({ reportType: "overall_performance", agent: "all" });

  const getDateRangeForQuery = (rangeKey) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    let startDate, endDate = new Date();
    endDate.setHours(23, 59, 59, 999);

    switch (rangeKey) {
      case "today":
        startDate = new Date(today);
        break;
      case "current_week":
        startDate = new Date(today);
        startDate.setDate(today.getDate() - today.getDay()); // Start of week (Sunday)
        break;
      case "current_month":
        startDate = new Date(today.getFullYear(), today.getMonth(), 1);
        endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        endDate.setHours(23,59,59,999);
        break;
      case "last_month":
        startDate = new Date(today.getFullYear(), today.getMonth() - 1, 1);
        endDate = new Date(today.getFullYear(), today.getMonth(), 0);
        endDate.setHours(23,59,59,999);
        break;
      case "last_3_months":
        startDate = new Date(today.getFullYear(), today.getMonth() - 2, 1);
        endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        endDate.setHours(23,59,59,999);
        break;
      default: // Default to current month
        startDate = new Date(today.getFullYear(), today.getMonth(), 1);
        endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        endDate.setHours(23,59,59,999);
    }
    return { startDate: startDate.toISOString(), endDate: endDate.toISOString() };
  };

  const fetchAllData = useCallback(async (userId, dateRangeKey, filters) => {
    setIsLoading(true);
    const { startDate, endDate } = getDateRangeForQuery(dateRangeKey);

    try {
      const { data: taskLogs, error: taskLogError } = await supabase
        .from('zapier_task_data')
        .select('created_at, tasks_completed, leads_captured, emails_sent')
        .eq('user_id', userId)
        .gte('created_at', startDate)
        .lte('created_at', endDate);

      if (taskLogError) throw taskLogError;

      const dailyAggregated = {};
      taskLogs.forEach(log => {
        const day = new Date(log.created_at).toISOString().split('T')[0];
        if (!dailyAggregated[day]) {
          dailyAggregated[day] = { date: day, tasksCompleted: 0, leadsCaptured: 0, emailsSent: 0 };
        }
        dailyAggregated[day].tasksCompleted += (log.tasks_completed || 0);
        dailyAggregated[day].leadsCaptured += (log.leads_captured || 0);
        dailyAggregated[day].emailsSent += (log.emails_sent || 0);
      });
      
      const sortedDailyData = Object.values(dailyAggregated).sort((a, b) => new Date(a.date) - new Date(b.date));
      setDailyTaskData(sortedDailyData);

      const totalTasksCompleted = sortedDailyData.reduce((sum, day) => sum + day.tasksCompleted, 0);
      const totalLeadsGenerated = sortedDailyData.reduce((sum, day) => sum + day.leadsCaptured, 0);
      const totalEmailsSent = sortedDailyData.reduce((sum, day) => sum + day.emailsSent, 0);
      
      setAggregatedPerformanceData({
        tasksCompleted: totalTasksCompleted,
        leadsGenerated: totalLeadsGenerated,
        emailsSent: totalEmailsSent,
        customerFollowUps: totalTasksCompleted - totalEmailsSent - totalLeadsGenerated, // Example calculation
        totalTransactions: totalTasksCompleted, // Example placeholder
      });

    } catch (error) {
      toast({ title: "Error fetching performance data", description: error.message, variant: "destructive" });
      setDailyTaskData([]);
      setAggregatedPerformanceData(null);
    } finally {
      setIsLoading(false);
    }
  }, [toast]);


  const fetchActiveAgentsList = useCallback(async (userId) => {
    const { data, error } = await supabase
      .from('user_assigned_agents')
      .select('assigned_agent_id, agent_name')
      .eq('user_id', userId)
      .eq('status', 'active');
    if (error) console.error("Error fetching active agents:", error);
    else setActiveAgents(data || []);
  }, []);

  useEffect(() => {
    const getCurrentUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        setUser(session.user);
        fetchAllData(session.user.id, currentDateRange, currentFilters);
        fetchActiveAgentsList(session.user.id);
      } else {
        setIsLoading(false);
      }
    };
    getCurrentUser();
  }, [fetchAllData, fetchActiveAgentsList, currentDateRange, currentFilters]);

  const handleLineGraphPointClick = (metricName, metricValue, rawDetails) => {
    setSelectedMetricForDialog({ name: metricName, value: metricValue, details: rawDetails });
    setIsAnalyticsDetailOpen(true);
  };
  
  const handleDownloadPdf = (reportTitle) => {
    toast({ title: "Download Initiated (Mock)", description: `Preparing PDF for ${reportTitle}. This is a placeholder.`, variant: "info" });
  };
  
  const handleApplyDateRange = (range) => {
    setCurrentDateRange(range);
  };

  const handleApplyFilters = (filters) => {
    setCurrentFilters(filters);
  };

  const pieChartData = aggregatedPerformanceData ? [
    { key: "tasksCompleted", label: "Tasks Completed", value: aggregatedPerformanceData.tasksCompleted || 0, color: "hsl(262.1 83.3% 57.8%)" },
    { key: "leadsGenerated", label: "Leads Generated", value: aggregatedPerformanceData.leadsGenerated || 0, color: "hsl(221.2 83.2% 53.3%)" },
    { key: "emailsSent", label: "Emails Sent", value: aggregatedPerformanceData.emailsSent || 0, color: "hsl(142.1 76.2% 36.3%)" },
    { key: "customerFollowUps", label: "Follow-Ups", value: aggregatedPerformanceData.customerFollowUps > 0 ? aggregatedPerformanceData.customerFollowUps : 0, color: "hsl(322.2 83.0% 53.3%)" },
  ].filter(item => item.value > 0) : [];
  
  const dateRangeLabel = currentDateRange.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

  return (
    <div className="container py-8 bg-background text-foreground">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
          <h1 className="text-3xl font-bold">Reports & Analytics</h1>
          <div className="flex gap-2">
            <Button variant="outline" className="btn-minimal" onClick={() => setIsDateRangeDialogOpen(true)}>
              <Calendar className="mr-2 h-4 w-4" /> Date Range
            </Button>
            <Button variant="outline" className="btn-minimal" onClick={() => setIsFilterDialogOpen(true)}>
              <Filter className="mr-2 h-4 w-4" /> Filter Reports
            </Button>
          </div>
        </div>
        
        <Card className="mb-8 bg-card border-border">
          <CardHeader className="flex flex-row justify-between items-center">
            <div>
              <CardTitle className="text-card-foreground">Daily Activity Snapshot</CardTitle>
              <CardDescription className="text-muted-foreground">Visualizing daily task completions and overall metric distribution. Current range: <span className="capitalize font-semibold text-primary">{dateRangeLabel}</span></CardDescription>
            </div>
            <Button variant="ghost" size="sm" onClick={() => handleDownloadPdf("Daily Activity Overview")} className="text-muted-foreground hover:text-primary">
              <Download className="mr-2 h-4 w-4" /> Download Overview
            </Button>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="h-96 bg-muted rounded-md flex items-center justify-center">
                <Loader2 className="h-16 w-16 text-primary animate-spin" />
                <p className="ml-4 text-muted-foreground text-lg">Loading analytics dashboard...</p>
              </div>
            ) : (
              <div className="flex flex-col lg:flex-row justify-between items-stretch p-4 min-h-[350px] gap-6">
                <div className="flex-grow lg:w-2/3 h-[350px]">
                  <DailyTasksLineGraph data={dailyTaskData} dateRangeLabel={dateRangeLabel} />
                </div>
                <div className="flex-shrink-0 lg:w-1/3 flex flex-col items-center justify-center mt-6 lg:mt-0">
                   <h4 className="text-md font-semibold text-card-foreground mb-2 text-center">Metric Distribution</h4>
                  <HoverablePieChart data={pieChartData} />
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6 mt-10">
            <h2 className="text-2xl font-semibold text-foreground border-b border-border pb-2">Monthly Overviews</h2>
            <MonthlyOverviewCard title="Google Ads Overview" icon={<TrendingUp />} onDownload={() => handleDownloadPdf("Google Ads Overview")} />
            <MonthlyOverviewCard title="Meta Ads Overview" icon={<Target />} onDownload={() => handleDownloadPdf("Meta Ads Overview")} />
            <MonthlyOverviewCard title="Email Campaign Overview" icon={<Maximize2 />} onDownload={() => handleDownloadPdf("Email Campaign Overview")} />
        </div>

      </motion.div>
      <DateRangeDialog open={isDateRangeDialogOpen} onOpenChange={setIsDateRangeDialogOpen} onApply={handleApplyDateRange} />
      <FilterReportsDialog open={isFilterDialogOpen} onOpenChange={setIsFilterDialogOpen} onApply={handleApplyFilters} activeAgents={activeAgents}/>
      {selectedMetricForDialog && (
         <AnalyticsDetailDialog 
            open={isAnalyticsDetailOpen} 
            onOpenChange={setIsAnalyticsDetailOpen} 
            metricName={selectedMetricForDialog.name} 
            metricValue={selectedMetricForDialog.value} 
            details={selectedMetricForDialog.details}
            dateRange={currentDateRange}
          />
      )}
    </div>
  );
};

export default ReportsAnalyticsPage;