import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/lib/supabaseClient";
import { LogIn, Mail, Lock, AlertTriangle } from "lucide-react";

const LoginPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [supabaseError, setSupabaseError] = useState(false);
  const backgroundVideoUrl = "https://ryan4h.github.io/luxury-home-renovations/scifibackground.mp4";

  useEffect(() => {
    const queryParams = new URLSearchParams(location.search);
    if (queryParams.get('error') === 'supabase_disconnected' || !supabase) {
      setSupabaseError(true);
      if (supabase) { 
        toast({
          title: "Database Connection Issue",
          description: "There might be an issue connecting to the database. Please try again or contact support.",
          variant: "destructive",
          duration: 10000,
        });
      } else { 
         toast({
          title: "Database Not Connected",
          description: "The application is not connected to the database. Please check configuration or contact support.",
          variant: "destructive",
          duration: 10000,
        });
      }
    } else if (supabase) { 
        setSupabaseError(false);
    }
  }, [location.search, toast]);

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!supabase) {
      toast({
        title: "Login Unavailable",
        description: "Database connection is not configured. Cannot log in.",
        variant: "destructive",
      });
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (error) throw error;
      
      toast({
        title: "Login Successful",
        description: "Welcome back!",
      });
      navigate("/dashboard");
    } catch (error) {
      toast({
        title: "Login Failed",
        description: error.message || "Invalid credentials. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative flex items-center justify-center min-h-screen w-full bg-black text-foreground overflow-hidden">
      <video 
        autoPlay 
        loop 
        muted 
        playsInline
        className="video-background" 
        src={backgroundVideoUrl}
      >
        Your browser does not support the video tag.
      </video>
      <div className="absolute inset-0 bg-black/70 z-0"></div>

      <motion.div 
        className="relative z-10 w-full max-w-md p-8 sm:p-10 space-y-6 bg-card/80 backdrop-blur-md border border-white/20 rounded-xl shadow-2xl glassmorphism-card"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="text-center">
          <motion.h1 
            className="text-3xl font-bold text-white mb-2" 
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            Welcome Back
          </motion.h1>
          <p className="text-gray-300 text-sm">
            Sign in to access your AI automation dashboard.
          </p>
        </div>

        {supabaseError && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-destructive/20 border border-destructive text-destructive-foreground p-3 rounded-md text-sm flex items-center gap-2"
          >
            <AlertTriangle className="h-5 w-5" />
            <span>Database not connected. Login is disabled.</span>
          </motion.div>
        )}

        <form onSubmit={handleLogin} className="space-y-5">
          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            <Label htmlFor="email" className="text-gray-200 text-sm">Email Address</Label>
            <div className="relative mt-1">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
                className="pl-10 bg-white/10 border-white/30 text-white placeholder:text-gray-400 focus:border-primary focus:ring-primary py-2.5 text-sm"
                disabled={supabaseError}
              />
            </div>
          </motion.div>
          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.5 }}
          >
            <Label htmlFor="password" className="text-gray-200 text-sm">Password</Label>
            <div className="relative mt-1">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="pl-10 bg-white/10 border-white/30 text-white placeholder:text-gray-400 focus:border-primary focus:ring-primary py-2.5 text-sm"
                disabled={supabaseError}
              />
            </div>
          </motion.div>
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            <Button 
              type="submit" 
              variant="outline"
              className="w-full bg-transparent hover:bg-white/10 text-white border-white/70 hover:border-white text-base py-2.5" 
              disabled={loading || supabaseError}
            >
              {loading ? "Logging in..." : <><LogIn className="mr-2 h-4 w-4" /> Login</>}
            </Button>
          </motion.div>
        </form>
        <p className="text-center text-xs text-gray-300">
          Don't have an account?{" "}
          <a
            href="/signup"
            className={`font-medium ${supabaseError ? 'text-gray-400 cursor-not-allowed' : 'text-primary hover:underline'}`}
            onClick={(e) => { 
              if (supabaseError) {
                e.preventDefault();
                return;
              }
              e.preventDefault(); navigate("/signup");
            }}
          >
            Request Access
          </a>
        </p>
      </motion.div>
    </div>
  );
};

export default LoginPage;