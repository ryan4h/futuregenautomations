import React, { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { supabase } from "@/lib/supabaseClient";
import { useToast } from "@/components/ui/use-toast";
import { useNavigate } from "react-router-dom";
import ProfileHeader from "./profile/ProfileHeader";
import ProfileAvatarCard from "./profile/ProfileAvatarCard";
import ProfileForm from "./profile/ProfileForm";
import ProfileSecurity from "./profile/ProfileSecurity";
import ProfileNotifications from "./profile/ProfileNotifications";
import ProfileBilling from "./profile/ProfileBilling";
import { AlertTriangle } from "lucide-react";

const ProfilePage = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState({
    full_name: "",
    company_name: "",
    job_title: "",
    avatar_url: null,
    personal_phone: "",
    company_phone: "",
  });
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  // const [uploading, setUploading] = useState(false); // Avatar upload removed
  const [supabaseError, setSupabaseError] = useState(!supabase);


  const fetchUserData = useCallback(async () => {
    if (!supabase) {
      setLoading(false);
      setSupabaseError(true);
      return;
    }
    setSupabaseError(false);
    setLoading(true);
    const { data: { user: authUser } } = await supabase.auth.getUser();
    setUser(authUser);

    if (authUser) {
      const { data: userProfile, error } = await supabase
        .from("user_profiles")
        .select("*")
        .eq("user_id", authUser.id)
        .maybeSingle();

      if (error) {
        toast({ title: "Error fetching profile", description: error.message, variant: "destructive" });
      } else if (userProfile) {
        setProfile(prev => ({
          ...prev,
          ...userProfile,
          personal_phone: userProfile.personal_phone || "",
          company_phone: userProfile.company_phone || "",
        }));
      } else {
         setProfile(prev => ({
          ...prev,
          full_name: authUser.user_metadata?.full_name || authUser.email?.split('@')[0] || '',
          personal_phone: "", 
          company_phone: "",
        }));
      }
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    fetchUserData();
  }, [fetchUserData]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProfile(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    if (!user || !supabase) {
      toast({ title: "Error", description: "Not connected to database.", variant: "destructive" });
      return;
    }
    setLoading(true);

    const profileDataToSave = {
      user_id: user.id,
      full_name: profile.full_name,
      company_name: profile.company_name,
      job_title: profile.job_title,
      // avatar_url: profile.avatar_url, // Avatar URL is not changed here anymore
      personal_phone: profile.personal_phone,
      company_phone: profile.company_phone,
      updated_at: new Date().toISOString(),
    };
    
    // If avatar_url was fetched, include it, otherwise don't send it (to avoid overwriting with null if not edited)
    if (profile.avatar_url) {
        profileDataToSave.avatar_url = profile.avatar_url;
    }
    
    const { error } = await supabase
      .from("user_profiles")
      .upsert(profileDataToSave, { onConflict: 'user_id' });

    if (error) {
      toast({ title: "Error saving profile", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Profile Updated", description: "Your profile information has been saved." });
      setIsEditing(false);
      const { data: updatedProfile } = await supabase.from("user_profiles").select("*").eq("user_id", user.id).maybeSingle();
      if (updatedProfile) {
        setProfile(prev => ({
          ...prev,
          ...updatedProfile,
          personal_phone: updatedProfile.personal_phone || "",
          company_phone: updatedProfile.company_phone || "",
        }));
      }
    }
    setLoading(false);
  };
  

  if (loading && !profile.full_name && !user?.email && !supabaseError) {
    return <div className="container py-8 text-center">Loading profile...</div>;
  }

  return (
    <div className="container py-8 bg-background text-foreground">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {supabaseError && (
           <div className="mb-6 bg-destructive/20 border border-destructive text-destructive-foreground p-4 rounded-md text-sm flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 flex-shrink-0" />
            <span>Database is not connected. Profile features are disabled. Please complete Supabase integration or contact support.</span>
          </div>
        )}
        <ProfileHeader 
          isEditing={isEditing} 
          onEditToggle={() => setIsEditing(!isEditing)} 
          onSave={handleSave} 
          loading={loading} // Removed uploading state
          disabled={supabaseError}
        />

        <div className="grid md:grid-cols-3 gap-8">
          <div className="space-y-8">
            <ProfileAvatarCard 
              profile={profile}
              userEmail={user?.email}
              // isEditing={isEditing} // No longer needed for avatar card if upload is removed
              // onAvatarUpload={handleAvatarUpload} // Removed
              // uploading={uploading} // Removed
              disabled={supabaseError}
            />
            <ProfileBilling onManageBilling={() => navigate('/billing')} disabled={supabaseError} />
          </div>
          <div className="md:col-span-2">
            <ProfileForm 
              profile={profile}
              userEmail={user?.email}
              isEditing={isEditing}
              loading={loading}
              onInputChange={handleInputChange}
              disabled={supabaseError}
            />
            <div className="mt-8 grid sm:grid-cols-2 gap-6">
              <ProfileSecurity disabled={supabaseError}/>
              <ProfileNotifications disabled={supabaseError}/>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default ProfilePage;