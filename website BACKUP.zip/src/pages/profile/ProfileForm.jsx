import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Phone, Building, User as UserIcon, Mail } from "lucide-react"; // Added UserIcon and Mail

const ProfileForm = ({ profile, userEmail, isEditing, loading, onInputChange }) => {
  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-card-foreground">Personal Information</CardTitle>
        <CardDescription className="text-muted-foreground">Manage your personal details and account settings.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <Label htmlFor="full_name" className="text-card-foreground">Full Name</Label>
          <div className="relative mt-1">
            <UserIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              id="full_name" 
              name="full_name"
              value={profile.full_name || ""} 
              onChange={onInputChange}
              disabled={!isEditing || loading} 
              className="pl-10 bg-input border-border text-foreground placeholder:text-muted-foreground disabled:opacity-70" 
              placeholder="e.g., John Doe"
            />
          </div>
        </div>
        <div>
          <Label htmlFor="email" className="text-card-foreground">Email Address</Label>
          <div className="relative mt-1">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              id="email" 
              name="email"
              type="email" 
              value={userEmail || ""} 
              disabled 
              className="pl-10 bg-input border-border text-foreground placeholder:text-muted-foreground disabled:opacity-70" 
            />
          </div>
        </div>
        <div>
          <Label htmlFor="company_name" className="text-card-foreground">Company</Label>
          <div className="relative mt-1">
            <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              id="company_name" 
              name="company_name"
              value={profile.company_name || ""} 
              onChange={onInputChange}
              disabled={!isEditing || loading} 
              className="pl-10 bg-input border-border text-foreground placeholder:text-muted-foreground disabled:opacity-70" 
              placeholder="e.g., Future Gen Corp"
            />
          </div>
        </div>
        <div>
          <Label htmlFor="job_title" className="text-card-foreground">Role</Label>
          <Input 
            id="job_title" 
            name="job_title" // No icon typically needed for role, plain input is fine
            value={profile.job_title || ""} 
            onChange={onInputChange}
            disabled={!isEditing || loading} 
            className="mt-1 bg-input border-border text-foreground placeholder:text-muted-foreground disabled:opacity-70" 
            placeholder="e.g., CEO, Developer"
          />
        </div>
        <div>
          <Label htmlFor="personal_phone" className="text-card-foreground">Personal Phone</Label>
          <div className="relative mt-1">
            <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              id="personal_phone" 
              name="personal_phone"
              type="tel"
              value={profile.personal_phone || ""} 
              onChange={onInputChange}
              disabled={!isEditing || loading} 
              className="pl-10 bg-input border-border text-foreground placeholder:text-muted-foreground disabled:opacity-70" 
              placeholder="e.g., +1 555-123-4567"
            />
          </div>
        </div>
        <div>
          <Label htmlFor="company_phone" className="text-card-foreground">Company Phone</Label>
           <div className="relative mt-1">
            <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" /> 
            <Input 
              id="company_phone" 
              name="company_phone"
              type="tel"
              value={profile.company_phone || ""} 
              onChange={onInputChange}
              disabled={!isEditing || loading} 
              className="pl-10 bg-input border-border text-foreground placeholder:text-muted-foreground disabled:opacity-70" 
              placeholder="e.g., +1 555-987-6543"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProfileForm;