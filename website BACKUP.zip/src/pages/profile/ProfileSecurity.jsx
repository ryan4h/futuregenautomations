import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const ProfileSecurity = () => {
  const { toast } = useToast();

  const handleChangePassword = () => {
    toast({ title: "Feature Coming Soon", description: "Password change functionality will be available soon." });
  };

  const handleEnable2FA = () => {
     toast({ title: "Feature Coming Soon", description: "Two-Factor Authentication will be available soon." });
  };

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-card-foreground flex items-center"><Shield className="mr-2 h-5 w-5"/> Security</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <Button variant="outline" className="w-full btn-minimal" onClick={handleChangePassword}>Change Password</Button>
        <Button variant="outline" className="w-full btn-minimal" onClick={handleEnable2FA}>Enable Two-Factor Auth</Button>
      </CardContent>
    </Card>
  );
};

export default ProfileSecurity;