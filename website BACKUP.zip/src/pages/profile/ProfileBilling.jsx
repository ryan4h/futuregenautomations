import React from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CreditCard } from "lucide-react";

const ProfileBilling = ({ onManageBilling, disabled }) => {
  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-card-foreground">Billing Information</CardTitle>
        <CardDescription className="text-muted-foreground">
          Manage your subscription and payment methods.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-4">
          View your current plan, billing history, and update your payment details.
        </p>
        {/* Placeholder for some basic info if needed in future */}
        {/* <div className="space-y-2">
          <p className="text-sm"><span className="font-medium text-card-foreground">Current Plan:</span> Pro Tier</p>
          <p className="text-sm"><span className="font-medium text-card-foreground">Next Billing Date:</span> 2025-06-15</p>
        </div> */}
      </CardContent>
      <CardFooter>
        <Button 
          onClick={onManageBilling} 
          className="w-full btn-minimal"
          disabled={disabled}
        >
          <CreditCard className="mr-2 h-4 w-4" />
          Manage Billing
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ProfileBilling;