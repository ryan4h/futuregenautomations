import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const ProfileNotifications = () => {
  const { toast } = useToast();

  const handleManageNotifications = () => {
    toast({ title: "Feature Coming Soon", description: "Notification preferences will be available soon." });
  };

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-card-foreground flex items-center"><Bell className="mr-2 h-5 w-5"/> Notifications</CardTitle>
      </CardHeader>
      <CardContent>
        <Button variant="outline" className="w-full btn-minimal" onClick={handleManageNotifications}>Manage Notification Preferences</Button>
      </CardContent>
    </Card>
  );
};

export default ProfileNotifications;