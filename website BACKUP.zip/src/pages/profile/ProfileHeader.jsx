import React from "react";
import { Button } from "@/components/ui/button";
import { Edit3, Save } from "lucide-react";

const ProfileHeader = ({ isEditing, onEditToggle, onSave, loading }) => {
  return (
    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
      <h1 className="text-3xl font-bold">Profile</h1>
      {!isEditing ? (
        <Button variant="outline" className="btn-minimal" onClick={onEditToggle}>
          <Edit3 className="mr-2 h-4 w-4" /> Edit Profile
        </Button>
      ) : (
        <Button variant="outline" className="btn-minimal" onClick={onSave} disabled={loading}>
          <Save className="mr-2 h-4 w-4" /> {loading ? "Saving..." : "Save Changes"}
        </Button>
      )}
    </div>
  );
};

export default ProfileHeader;