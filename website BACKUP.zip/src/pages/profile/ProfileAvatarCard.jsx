import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
// Label and Input removed as avatar upload is disabled

const ProfileAvatarCard = ({ profile, userEmail }) => { // Removed isEditing, onAvatarUpload, uploading
  const getInitials = (name) => {
    if (!name) return "?";
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };
  
  const displayName = profile.full_name || userEmail || "User";
  const displayEmail = userEmail || "";

  return (
    <div className="md:col-span-1">
      <Card className="bg-card border-border">
        <CardContent className="p-6 text-center">
          <Avatar className="h-32 w-32 mx-auto mb-4 border-2 border-primary">
            <AvatarImage src={profile.avatar_url} alt={displayName} />
            <AvatarFallback className="text-4xl bg-muted text-muted-foreground">
              {getInitials(displayName)}
            </AvatarFallback>
          </Avatar>
          {/* Avatar upload UI removed */}
          <h2 className="text-2xl font-semibold text-card-foreground">{displayName}</h2>
          <p className="text-muted-foreground">{displayEmail}</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProfileAvatarCard;